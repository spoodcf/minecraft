#include <graphx.h>
#include <ti/screen.h>
#include <ti/getcsc.h>
#include <ti/vars.h>    
#include <keypadc.h>
#include <sys/util.h>
#include <sys/timers.h>
#include <debug.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>      
#include <stdio.h>     
#include <fileioc.h>

#include "gfx/gfx.h"

#include "textures.cpp"

#define AUTO_GENERATE_GLOBALS
#include <ctime>
#include <tice.h>
#include <algorithm>
#include <usbdrvce.h>
#include <cstdlib>



//mincraft /minecalc TInCEraft
/*

M  I  N  E  C  R  A  F  T
  T    84+^  E
 */
//made by imatree
//(imatree247) 
//also possibly imaTIrCEe but maybe not. still deciding on the name. 
//also deciding on name for this. MINcraft? like minimal mine craft? 
//but minecalc is good to.


//uint8_t vis_map[64][16][64];


//BEHOLD! the many many macros. Some you can change, some i highly reccomend you don't.
//if you change wx, wy, or wz make sure you update xws and yws which are the world shifts. xws is equal to log2(wy)+log2(wz) and yws = log2(wz) i think. they are all the same so it gets confusing.
#define WX 32
#define WY 32
#define WZ 32

#define XJ (WY*WZ)
#define YJ WZ
#define ZJ 1 //totally hardcoded everywhere btw
#define XWS 10
#define YWS 5

#define vis_map(x, y, z) world[((x) << XWS) + ((y) << YWS) + (z)]

#define VD 15
//view distance. i recommend between 8 and 20. is measured in taxicab (manhattan) distance from player.
#define res 5
//res must be divisible by 320 can be 1,2,4,5,8,10,16. ALSO, new thing, i kinda hardcoded it (sorry!) in the assembly (well not too sorry) so it is much faster (yeah not sorry).
#define AVERAGEFPS 7
//#define bg_color 191
uint8_t bg_color=125;


#define INTERACTD 6
#define FRACPOS 1      // 1 = fractional player position, 0 = old block-center rendering
#define MOVESHIFT 1    // walk step = 1/(1<<MOVESHIFT) block
//#define TREENUM 10
#define IRONNUM 75
#define DIAMONDNUM 20
#define REDSTONENUM 40
#define GOLDNUM 40
#define COALNUM 70
#define GRAVELNUM 7
#define OBSIDIANNUM 30
#define NETHERGOLDORENUM 50
#define TUNNELNUM 5
#define TUNNELWOBBLEF 10
#define TUNNELWOBBLEU 5
//#define SANDNUM 10
#define AIR 0
#define GRASS 1
#define STONE 2
#define WOOD 3
#define LEAF 4
#define BARRIER 5
#define UNLITLAMP 6
#define LITLAMP 7
#define UNLITBUTTON 8
#define LITBUTTON 9
#define SAND 10
#define WOOL 11
#define SNOWGRASS 12
#define SNOW 13
#define NETHERRACK 14
#define OBSIDIAN 15
#define WATERBLOCK 16
#define WATERFALL 17
#define IRONBLOCK 18
#define GOLDBLOCK 19
#define DIAMONDBLOCK 20
#define REDSTONEBLOCK 21

#define block_num 69
#define reg_block_num 22
#define item_num 26
#define RECIPIENUM 27

#define invenblocknum (TEXTURENUM+reg_block_num+FLOORNUM)

#define WOODPIC (invenblocknum+1)
#define STONEPIC (invenblocknum+2)
#define GOLDPIC (invenblocknum+3)
#define IRONPIC (invenblocknum+4)
#define DIAMONDPIC (invenblocknum+5)
#define NETHERITEPIC (invenblocknum+6)
#define STICK (invenblocknum+7)
#define WOODSWORD (invenblocknum+8)
#define STONESWORD (invenblocknum+9)
#define GOLDSWORD (invenblocknum+10)
#define IRONSWORD (invenblocknum+11)
#define DIAMONDSWORD (invenblocknum+12)
#define IRONINGOT (invenblocknum+13)
#define GOLDINGOT (invenblocknum+14)
#define RAWMUTTON (invenblocknum+15)
#define COOKEDMUTTON (invenblocknum+16)
#define ROTTENFLESH (invenblocknum+17)
#define DIAMONDITEM (invenblocknum+18)
#define COALITEM (invenblocknum+19)
#define FLINTANDSTEEL (invenblocknum+20)//chicken jockeeeeyyy, the nettherrr, FLINT AND STEEEEEEELLLL ender peaarrll
#define FLINT (invenblocknum+21)
#define BUCKET (invenblocknum+22)
#define WATERBUCKET (invenblocknum+23)
#define RAWPORKCHOP (invenblocknum+24)
#define COOKEDPORKCHOP (invenblocknum+25)

#define FLOORNUM 5
#define FLOORVOXELS reg_block_num                 // last id that is NOT a floor voxel (15)

#define SNOWCARPET (FLOORVOXELS+1)                // 16
#define REDSTONEDUSTUNLIT (FLOORVOXELS+2)          // 17
#define REDSTONEDUSTLIT (FLOORVOXELS+3)            // 18
												// don't trust these indeicies ^ ^ ^ i change blocks all the time so they are probsbly not correct
												//that goes for every other index. I literally asked ai to change one thing and they
												//decided to annotate a bunch of my code.
												//same goes for stuff.asm
#define WATERFLOOR (FLOORVOXELS+4) 

#define WATERSLAB (FLOORVOXELS+5)
#define SLABSTART WATERSLAB

#define FLOORVOXELSEND WATERSLAB            // last floor id (18)
static uint8_t floorcolorsconst[]={255,96,224,30,28};
uint8_t* floorcolors=floorcolorsconst-(FLOORVOXELS+1);

#define CRAFTTABLE (FLOORVOXELSEND+1)              // 19
#define FURNACE (FLOORVOXELSEND+2)
#define PLANKS (FLOORVOXELSEND+3)
#define BEDTOP (FLOORVOXELSEND+4)
#define GLASS (FLOORVOXELSEND+5)
#define DOORTOPOPEN (FLOORVOXELSEND+6)
#define DOORBOTTOMOPEN (FLOORVOXELSEND+7)
#define DOORTOPCLOSED (FLOORVOXELSEND+8)
#define DOORBOTTOMCLOSED (FLOORVOXELSEND+9)
#define MAGMABLOCK (FLOORVOXELSEND+10)
#define FIRE (FLOORVOXELSEND+11)
#define SANDSTONE (FLOORVOXELSEND+12)
#define CACTUS (FLOORVOXELSEND+13)                 // 31
#define IRON (FLOORVOXELSEND+14) 
#define GOLD (FLOORVOXELSEND+15) 
#define DIAMOND (FLOORVOXELSEND+16) 
//#define GRASS IRON
#define REDSTONE (FLOORVOXELSEND+17) 
#define COAL (FLOORVOXELSEND+18) 
#define TNT (FLOORVOXELSEND+19)
#define LITTNT (FLOORVOXELSEND+20)
#define SMOKE (FLOORVOXELSEND+21)
#define GRAVEL (FLOORVOXELSEND+22)
#define NETHERPORTAL (FLOORVOXELSEND+23)
#define NETHERGOLDORE (FLOORVOXELSEND+24)
#define TEXTURENUM 24
/*
#define GRASS PLANKS
#define STONE CRAFTTABLE
#define WOOD CACTUS
#define LEAF MAGMABLOCK
//debug to test texture speed ^ ^ ^
*/






#define SKELETOPZ (reg_block_num+FLOORNUM+TEXTURENUM+1)
#define SKELETOPX (reg_block_num+FLOORNUM+TEXTURENUM+2)
#define SKELEBOTTOM (reg_block_num+FLOORNUM+TEXTURENUM+3)

#define SHEEPFACEX (reg_block_num+FLOORNUM+TEXTURENUM+4)
#define SHEEPFACEZ (reg_block_num+FLOORNUM+TEXTURENUM+5)
#define SHEEPBACKX (reg_block_num+FLOORNUM+TEXTURENUM+6)
#define SHEEPBACKZ (reg_block_num+FLOORNUM+TEXTURENUM+7)

#define ZOMBIETOPX (reg_block_num+FLOORNUM+TEXTURENUM+8)
#define ZOMBIETOPZ (reg_block_num+FLOORNUM+TEXTURENUM+9)
#define ZOMBIELEGS (reg_block_num+FLOORNUM+TEXTURENUM+10)

#define PIGFACEX  (reg_block_num+FLOORNUM+TEXTURENUM+11)
#define PIGFACEZ  (reg_block_num+FLOORNUM+TEXTURENUM+12)
#define PIGBACKX  (reg_block_num+FLOORNUM+TEXTURENUM+13)
#define PIGBACKZ  (reg_block_num+FLOORNUM+TEXTURENUM+14)

#define PIGLINTOPX (reg_block_num+FLOORNUM+TEXTURENUM+15)
#define PIGLINTOPZ (reg_block_num+FLOORNUM+TEXTURENUM+16)
#define PIGLINLEGS (reg_block_num+FLOORNUM+TEXTURENUM+17)

#define MOBNUM (17)
#define MOBSTART SKELETOPZ

#define SHEEPNUM 5
#define ZOMBIENUM 5
#define NETHERBGCOLOR 192

//static uint8_t noninventory_blocks={DOORBOTTOMCLOSED,DOORBOTTOMOPEN,DOORTOPCLOSED,SKELEBOTTOM,SKELETOPX,SKELETOPZ,SHEEPFACEX,SHEEPFACEZ,SHEEPBACKX,SHEEPBACKZ}
//Error with reg block num  +1 to ^ ^ ^
static uint8_t* world;//[WX*WY*WZ];
static uint8_t blockspritebuffer[(reg_block_num+1)<<8];   // 16 ids * 256B (16x16) = 4096B
static uint8_t texturespritebuffer[TEXTURENUM<<6];     // 13 ids * 64B  (8x8)  = 832B
//static uint8_t* world =(uint8_t*)0xD0087C;
static unsigned short* world_changes[MOBSTART];//array of short*. each array of short* is block moved.
static int inventory[block_num+item_num]={};
//static unsigned short* prev_world_changes[MOBSTART];//prev
int focal_length=200;//??? guess with this one ;) it works tho. Can't make it to low or will see serious fisheye!
// smaller = bigger fov but bigger distortion. BEWARE OF THE FISHEYE!!!
//also, if you change this, have to update inv_table as well
uint8_t realm=0;//0 is overworld, 1 will be nether. If i add the end (which I probably wont DONT get your hopes up it will be 3
void make_block_fall(uint8_t* block,uint8_t);
void add_update(uint8_t* block,uint8_t optionaldata=0);
void use_tnt(uint8_t* block);
void add_updates_fully(uint8_t* block);
int break_block(uint8_t* block);
void break_portal(uint8_t*block);
__attribute__((optnone)) bool iswater(uint8_t value);//umm... without that tag the compiler crashes
void address2coords(uint8_t* block, uint8_t&x,uint8_t&y,uint8_t&z )
{
	int nblock = block - world;
	z = nblock & (WZ-1);
	nblock >>= YWS;
	y = nblock & (WY-1);
	nblock >>= YWS;
	x = nblock;
}
void explode(uint8_t* block,uint8_t r)//this makes an explosion
{
	int nblock = block - world;
	uint8_t z = nblock & (WZ-1);
	nblock >>= YWS;
	uint8_t y = nblock & (WY-1);
	nblock >>= YWS;
	uint8_t x = nblock;
	for (int dx = -r; dx <= r; ++dx)
	{
		int nx = x + dx;
		if ((unsigned)nx >= WX) continue;
		for (int dy = -r; dy <= r; ++dy)
		{
			int ny = y + dy;
			if ((unsigned)ny >= WY) continue;
			for (int dz = -r; dz <= r; ++dz)
			{
				int nz = z + dz;
				if ((unsigned)nz >= WZ) continue;
				if (dx*dx + dy*dy + dz*dz <= r*r)
				{
					auto bl=&vis_map(nx,ny,nz);
					auto temp=*bl;
					if(temp==OBSIDIAN||temp==BARRIER||iswater(temp))
						continue;//these blocks are blast proof. So, can't break and they block explosions. 
					if(temp==NETHERPORTAL)
					{
						break_portal(bl);
						continue;
					}
					//in THOERY should never be able to explode barrier, but just to be safe I added that...
					
					if(temp!=TNT)
					{
						if(!(temp==LITTNT||temp>MOBSTART-1))//these blocks aren't blast proof but also shouldn't be turned into smoke
						{
							if(temp!=0&&temp!=SMOKE)
								break_block(bl);
							if(randInt(0,1))
							{
								*bl = SMOKE;
								
							}
							add_updates_fully(bl);
						}
					}
					else
					{
						*bl=LITTNT;
						add_update(bl);
					}
					
				}
			}
		}
	}
}
uint8_t countblockstaxi(uint8_t* block,uint8_t value)//start of the water code
{
	uint8_t someblock=0;
	if(*(block+XJ)==value)
		someblock+=1;
	if(*(block-XJ)==value)
		someblock+=1;
	if(*(block+1)==value)
		someblock+=1;
	if(*(block-1)==value)
		someblock+=1;
	return someblock;
}
void wateronespread(uint8_t* block, uint8_t value)
{
	uint8_t below=*(block-YJ);
	if(*block==0 && (below==WATERSLAB||below==WATERFLOOR))
	{
		*(block-YJ)=WATERFALL;
		*block=AIR;
		add_update((block-YJ));
		
		return;
	}
	if(below==WATERBLOCK)
		return;
	if(countblockstaxi(block,WATERBLOCK))
	{
		value=WATERSLAB;
		if(countblockstaxi(block,WATERBLOCK)>1)
		{
			value=WATERBLOCK;
			if(*block==WATERSLAB)
			{
				*block=WATERBLOCK;
				add_update(block);
			}
		}
		if(*block==WATERFLOOR||*block==0)
		{
			*(block)=value;
			add_update(block);
			return;
		}
	}
	
	if(*(block)==0)
	{
		*(block)=value;
		add_update(block);
	}
	
}
__attribute__((optnone)) bool iswater(uint8_t value)//umm... without that tag the compiler crashes
{
    switch (value) {
        case WATERFALL:
        case WATERBLOCK:
        case WATERSLAB:
        case WATERFLOOR:
            return true;
        default:
            return false;
    }
}
void waterplusspread(uint8_t* block, uint8_t value)
{
	wateronespread(block+XJ,value);
	wateronespread(block-XJ,value);
	wateronespread(block+1,value);
	wateronespread(block-1,value);
}
void liquidblockspread(uint8_t* block,uint8_t)
{
	if(*(block-YJ)==0)
	{
		*(block-YJ)=WATERFALL;
		add_update((block-YJ));
	}
	waterplusspread(block,WATERSLAB);
}
void liquidslabspread(uint8_t* block,uint8_t)
{
	if(*(block-YJ)==0)
	{
		*(block-YJ)=WATERFALL;
		add_update((block-YJ));
	}
	
	uint8_t someblock=countblockstaxi(block,WATERFALL);
	uint8_t someblock2=countblockstaxi(block,WATERBLOCK);
	
	someblock+=someblock2;
	if(!someblock)
	{
		*block=AIR;
		add_updates_fully(block);
		return;
	}
	if(someblock2>1)
	{
		*block=WATERBLOCK;
		add_update(block);
		return;
	}
	waterplusspread(block,WATERFLOOR);
}
void liquidfloorspread(uint8_t* block,uint8_t)
{
	if(*(block-YJ)==0)
	{
		*(block-YJ)=WATERFALL;
		add_update((block-YJ));
	}
	uint8_t someblock=countblockstaxi(block,WATERSLAB);	
	
	if(!someblock)
	{
		*block=AIR;
		add_updates_fully(block);
	}
}
void liquidfallspread(uint8_t* block,uint8_t)
{
	uint8_t below=*(block-YJ);
	if(below==AIR||below==WATERFLOOR||below==WATERSLAB)
	{
		*(block-YJ)=WATERFALL;
		add_update((block-YJ));
	}
	uint8_t above=*(block+YJ);
	if(!iswater(above))
	{
		*block=AIR;
		add_updates_fully(block);
		return;
	}
	if(!iswater(below)&&below!=AIR)
	{
		waterplusspread(block,WATERSLAB);
	}
	
}
void update_lit_tnt(uint8_t* block,uint8_t ttl)
{
	
	if(*(block-YJ)==0)//yes I did copy/paste this from make block fall and just change like 2 things. No I do not feel bad. 
	{
		*block=0;
		add_updates_fully(block);
		block-=YJ;
		*block=LITTNT;
		add_updates_fully(block);
	}
	if(ttl==0)//uninitialized
	{
		ttl=20;
		add_update(block,ttl);
		
	}
	else if(ttl>1)//not dead yet!
	{
		ttl--;
		add_update(block,ttl);
	}
	else
	{
		*block=AIR;
		explode(block,3);
	}
}
void update_fire(uint8_t* block,uint8_t ttl)
{
	if(ttl==0)//uninitialized
	{
		ttl=20;
		add_update(block,ttl);
	}
	else if(ttl>1)//not dead yet!
	{
		uint8_t blw=*(block-YJ);//block id below
		if(blw==WOOD||blw==PLANKS||blw==CRAFTTABLE||blw==NETHERRACK)
			ttl=20;
		else
		{
			ttl--;
			add_update(block,ttl);
		}
	}
	else
	{
		*block=AIR;
		add_updates_fully(block);
	}
}

void update_smoke(uint8_t* block,uint8_t ttl)
{
	if(ttl==0)//uninitialized
	{
		ttl=4;//like 1 second
		add_update(block,ttl);
	}
	else if(ttl>1)//not up yet
	{
		ttl--;
		add_update(block,ttl);
	}
	else
	{
		*block=AIR;//disappear
		add_updates_fully(block);
	}
}
struct block2update
{
	short block;//well block-world
	//void (*bfunction)(uint8_t*);
	uint8_t data=0;
};
struct id2func
{
	uint8_t block;
	void (*bfunction)(uint8_t*, uint8_t);
	id2func(uint8_t first_val, void (*second_val)(uint8_t*,uint8_t)) : block(first_val), bfunction(second_val) {}
};
static block2update bstack[2048];//good high number. 2048 is officially max number of blocks to update at one moment.
#define UPDATENUM 9
static id2func block_updates[UPDATENUM]={id2func(SAND,make_block_fall),id2func(GRAVEL,make_block_fall),id2func(FIRE,update_fire),id2func(LITTNT,update_lit_tnt),id2func(SMOKE,update_smoke),id2func(WATERBLOCK,liquidblockspread),id2func(WATERSLAB,liquidslabspread),id2func(WATERFLOOR,liquidfloorspread),id2func(WATERFALL,liquidfallspread)};
//if updates size here update size in update_block future me!
int bstacktop=0;

void make_block_fall(uint8_t* block,uint8_t)
{	
	//makes sand/other stuff eventually fall
	if(*(block-YJ)==0)
	{
		uint8_t id =*block;
		*block=0;
		add_updates_fully(block);
		block-=YJ;
		*block=id;
		add_updates_fully(block);
	}
}

void call_update();
static bool canupdatecleanup=true;
void add_update(uint8_t* block,uint8_t optionaldata)
{
	canupdatecleanup=true;
	if(block>=world&&block<world+32768)
	{
		if(bstacktop>2046)
		{
			call_update();   // safe now — no-op if we're already inside one
		}
		if(bstacktop<2048)   // hard cap, since a reentrant call_update() may have declined to trim
		{
			for(int i=0; i<UPDATENUM; ++i)
			{
				if(block_updates[i].block==*block)
				{
					dbg_printf("added update for %d, block_updates block %d\n",*block,block_updates[i].block);
					bstack[bstacktop].block=block-world;
					bstack[bstacktop].data=optionaldata;
					bstacktop++;
					return;
				}
			}
		}
	}
}
void add_updates_fully(uint8_t* block)
{
	add_update(block);
	//now will update blocks around it. (6 others)
	add_update(block-XJ);
	add_update(block+XJ);
	
	add_update(block-YJ);
	add_update(block+YJ);
	
	add_update(block+1);//no zj because zj is 1
	add_update(block-1);
}
static bool updating_blocks = false;
void update_cleanup()//this for what happens when run out of updates
{
	auto end=&world[WX*WY*WZ-1];
	for(auto w=world;w<end;++w)
	{
		uint8_t block=*w;
		if(block==SMOKE)
			*w=AIR;
		else if(block==LITTNT)
			*w=AIR;
		//thought about doing same thing for fire but decided against it.
	}
}

void call_update()
{
	if(updating_blocks)
	{
		if(canupdatecleanup)
		{
			update_cleanup();
			dbg_printf("Too many updates! cleaning up...");
			canupdatecleanup=false;
		}
		return;   // already running further up the call stack — do nothing
	}
	updating_blocks = true;
	canupdatecleanup=true;
	int countmax=bstacktop;
	int count=0;
	bstacktop=countmax;   // new pushes from add_update() go AFTER the region we're reading, not on top of it

	while(count<countmax)
	{
		dbg_printf("calling update! %d\n",bstacktop);
		auto temp=bstack[count];
		uint8_t curid = world[temp.block];
		for(int i=0; i<UPDATENUM;++i)
		{
			if(block_updates[i].block==curid)
			{
				block_updates[i].bfunction(world+temp.block,temp.data);
				break;
			}
		}
		count++;
	}

	// slide any newly-queued updates (pushed during this pass) down to the front,
	// so they're properly deferred to next frame instead of lost or re-run early
	int newcount = bstacktop - countmax;
	if(newcount>0)
		memmove(bstack, bstack+countmax, newcount*sizeof(block2update));
	bstacktop = newcount;

	updating_blocks = false;
}

/**
Ok, how block updates work is minecraft java style. (idk how bedrock does it).
Every time you mine/break/interact with a block, it updates the blocks around it (taxicab, no funny diagonal buisness.
If the block is in block_updates, it adds the function
**/




int wseed=0;
bool superstop=false;
#define shift_by 9
struct flint//like float plus int
{       
	/** beautiful fixed precision class! I wrote first half, got really bored, and AI wrote the second half of this class!
	shift_by has to be 9 because anything lower and, ummm, random lines and things start appearing on the screen (impresicion in raycast screen)
	Believe me, if I could make it 8, i would.**/
	flint() {}                 // default
	flint(const flint& other) = default;
    flint(int other) { data = other << shift_by; } // from int
    flint(float other) { data = (int)(other * (1 << shift_by)); } // from float
	int data=0;// prob 24 bits. 4 digit in decimal, 5 in int 100000.10010 +10000 -> 10000010010
	
    inline flint& operator+=(int other) {
        data+=other<<shift_by;
		return *this;
    }
	inline flint& operator+=(flint other) {
        data+=other.data;
		return *this;
    }
	
	inline flint& operator-=(int other) {
        data-=other<<shift_by;
		return *this;
    }
	
	inline flint& operator-=(flint other) {
        data-=other.data;
		return *this;
    }
	
	inline flint& operator*=(int other) {
        data*=other;
		return *this;
    }
	inline flint& operator*=(flint other) {
        //long temp= (long)data*other.data;
		//data=(int)(temp>>shift_by);
		data=data*other.data>>shift_by;
		return *this;
    }
	inline flint& operator/=(int other) {
        data/=other;
		return *this;
    }
	inline flint& operator/=(flint other) {
        long temp= (long)data<<shift_by;
		data=(int)(temp/other.data);
		return *this;
    }
	inline flint& operator=(int other) {
        data=other<<shift_by;
		return *this;
    }
	inline flint& operator=(flint other) {
        data=other.data;
		return *this;	
    }
	inline operator int() const
	{
		return data>>shift_by;
	}
	inline operator float() const
	{
		return (float)(data)/(1<<shift_by);//WARNING THIS IS EVEN SLOWER!
	}
	
	inline bool operator>(flint other) const { return data > other.data; }
	inline bool operator<(flint other) const { return data < other.data; }
	inline bool operator==(flint other) const { return data == other.data; }
	inline bool operator>=(flint other) const { return data >= other.data; }
	inline bool operator<=(flint other) const { return data <= other.data; }
	inline bool operator!=(flint other) const { return data != other.data; }
	
	// Shift the int UP, don't shift the flint DOWN
	inline bool operator>(int other) const { return data > (other << shift_by); }
	inline bool operator<(int other) const { return data < (other << shift_by); }

	inline bool operator==(int other) const { return (data>>shift_by) == other; }
	inline bool operator>=(int other) const { return (data>>shift_by) >= other; }
	inline bool operator<=(int other) const { return (data>>shift_by) <= other; }
	inline bool operator!=(int other) const { return (data>>shift_by) != other; }
	inline void float2flint(const float other)
	{
		data = (int)(other * (1 << shift_by) + (other >= 0 ? 0.5f : -0.5f));//WARNING THIS IS SLOW!
		//return *this;
	}
	inline flint flint_abs() const {flint temp; temp.data=abs(data);return temp;}
	inline flint& self_abs() {data=abs(data);return *this;}
	inline int decimal_part() const {return (data<<(24-shift_by))>>(24-shift_by);}
	inline flint operator+(flint other) const { flint result = *this; return result += other; }
    inline flint operator-(flint other) const { flint result = *this; return result -= other; }
    inline flint operator*(flint other) const { flint result = *this; return result *= other; }
    inline flint operator/(flint other) const { flint result = *this; return result /= other; }

	inline flint operator-() const {flint o; o.data=-data;return o; }
		
	inline flint operator<<(int other) const { flint result = *this; result.data <<= other; return result;}
	inline flint operator>>(int other) const { flint result = *this; result.data >>= other; return result;}

    inline flint operator+(int other) const { flint result = *this; return result += other; }
    inline flint operator-(int other) const { flint result = *this; return result -= other; }
    inline flint operator*(int other) const { flint result = *this; return result *= other; }
    inline flint operator/(int other) const { flint result = *this; return result /= other; }

	
	
};
flint focal_inv;
flint half=.5f;
/**Lots of caching! xdir and y dir are ray directions for each pixel! (by ray and column, NOT always equal distance from orgin)**/
static flint cached_x_dir[320];//direction to ray trace from. picture direction from camera line to screen. o-._|
static flint cached_y_dir[240];// same thing but for y

/** inv versions are 1/direction in the above arrays**/
//static flint cached_x_dir_inv[320];
//static flint cached_y_dir_inv[240];

/**faster sine/cosine for speed purposes in raycast screen. There are 64 x and y rotations for the camera 
(although i decided it was too slow for the x so now it increments by 2 [so really 32] ) so it is perfect length! (still 64 in y, though)**/
static flint cached_sin_rot[64];
static flint cached_cos_rot[64];

/** for saving purposes, see update_changes_fully for more detail**/
//static int prev_world_changes_sizes[MOBSTART];
static int world_changes_sizes[MOBSTART];


int cached_x_signs[320];

inline int sign(int n) {
    return 1 | (n >> 23);
}
flint dist_from_one(flint x)
{
	return (x-(int)(x+half*sign(x.data))).flint_abs();
}
inline void rot_point_2d(flint& x1,flint&y1,flint x2, flint y2,int angle)//angle between 0 and 32.
{
	flint nx;nx=x1-x2;
	flint ny;ny=y1-y2;
	x1=x2+(cached_cos_rot[angle]*nx-cached_sin_rot[angle]*ny);
	y1=y2+(cached_sin_rot[angle]*nx+cached_cos_rot[angle]*ny);
}
/*
inline void thick_line(int x0,int y0, int x1, int y1, int width)
{
	for(int i=0; i<width; ++i)
	{
		gfx_Line(x0,y0+i,x1,y1+i);
	}
}
inline void draw_pickaxe(int x, int y, uint8_t color)//draws a pickaxe
{
	//items are 30 by 30
	gfx_SetColor(64);
	thick_line(x,y+24,x+29,y,5);//hilt
	gfx_SetColor(color);
	gfx_FillRectangle(x+8,y,x+29,y+5);//first part of... head? (or whatever its called)
	gfx_FillRectangle(x+24,y,x+29,y+21);
}
inline void draw_sword(int x, int y, uint8_t color)//draws a sword
{
	gfx_SetColor(65);
	thick_line(x,y+13,x+13,y,5);//hilt
	thick_line(x,y+14,x+13,y+25,5);//hilt (but cross part)
	gfx_SetColor(color);
	thick_line(x+13,y+25,x+29,y+29,5);
}
*/
inline void rot_point_3d(flint&x1,flint&y1,flint&z1,flint cosanglexz, flint sinanglexz, flint cosangleyz,flint sinangleyz)
{
	/** more relics from a past slower raycast screen function**/
	//flint foo;foo=z1;
	//rot_point_2d(x1,z1,x2,z2,anglexz);
	//rot_point_2d(y1,foo,y2,z2,angleyz);
	flint ny;ny=y1;
	flint nz;nz=z1;
	y1=(cosangleyz*ny-sinangleyz*nz);	
	nz=(sinangleyz*ny+cosangleyz*nz);//yz
	
	flint nx;nx=x1;
	x1=(cosanglexz*nx-sinanglexz*nz);
	z1=(sinanglexz*nx+cosanglexz*nz);//xz
}

flint point01;
flint one=1;
flint small=.001f;
const flint step_divide=1;

static flint inv_tabler[1500];
extern "C"
{
	flint* inv_table;
}

/*
volatile int foo;// I forget what these do. Maybe temporary variables?
volatile int foo1;
volatile int foo2;
*/
int o;
flint plx=1;
flint ply=WY-4;
flint plz=1;
int rotxz=0;
int rotyz=0;
extern "C" { extern uint8_t fr_kxp, fr_kxn, fr_kzp, fr_kzn;
             extern int fr_ofxp, fr_ofxn, fr_ofyp, fr_ofyn, fr_ofzp, fr_ofzn; }
int frx=8, fry=8, frz=8;   // 1..15 (1/16 blocks)
#define FRB 4                      // fraction bits: 4 = 1/16 ... 8 = 1/256 (max 8)
#define FRN (1<<FRB)
#define KSEL(f,d) (((d)>0)?FRN-(f):(f))
#define KMUL(delta,k) ((int)(((long)(delta)*(k))>>FRB))   // 32-bit multiply, no overflow
static inline int frac4(flint v){ int f=(v.data>>(9-FRB))&(FRN-1); return f<1?1:f; }
void update_frac()
{
#if FRACPOS
	frx=frac4(plx); frz=frac4(plz);
#else
	frx=frz=FRN/2;
#endif
	fry=frac4(ply);                    // eye height stays mid-block (y fix from before)
	fr_kxp=(FRN-frx)<<(8-FRB); fr_kxn=frx<<(8-FRB);   // asm wants k*(256/FRN), one byte
	fr_kzp=(FRN-frz)<<(8-FRB); fr_kzn=frz<<(8-FRB);
	fr_ofxp=frx<<(10-FRB); fr_ofxn=(FRN-frx)<<(10-FRB);   // texture origin, 1024 per block
	fr_ofyp=fry<<(10-FRB); fr_ofyn=(FRN-fry)<<(10-FRB);
	fr_ofzp=frz<<(10-FRB); fr_ofzn=(FRN-frz)<<(10-FRB);
}
#define fast_abs(x) std::abs((int)x)
/*
inline int fast_abs(int x)//suuuper speeedddyyyy abs
{
	
	int mask = x >> 23;// fills with sign bit
	return (x ^ mask) - mask;// does 2's compliment if negative.
	// if mask is 0 x^0 is x, if mask is all 1's x^0=!x. and x-all ones is x--1 or x+1.

}
inline int fast_abs(int x)
{
	return (x < 0) ? -x : x;
}

inline __attribute__((always_inline)) int24_t fast_abs(int24_t input_val) {
    // 1. Force the compiler to place 'input_val' into the 24-bit DE register
    register int24_t de_reg __asm__("de") = input_val;
    int24_t result;

    __asm__ volatile (
        "ld hl, 0       \n\t"   // Clear HL
        "add hl, de     \n\t"   // Copy DE into HL
        "add hl, hl     \n\t"   // Shift HL left; pushes sign bit into Carry
		"ex hl, de \n\t"
        "jp nc, 1f      \n\t"   // If positive, skip to label 1 (HL already matches DE)
        "ex hl, de \n\t"
        // If negative, negate DE into HL
        "ld hl, 0       \n\t"   // Clear HL to 0
        "or a, a        \n\t"   // Clear the Carry flag
        "sbc hl, de     \n\t"   // HL = 0 - DE (Negation complete!)
        
        "1:             \n\t"   // Local label
        "ld %0, hl      \n\t"   // Move the final positive value from HL into 'result'
        : "=r" (result)         // %0: Output variable (compiler will assign a register)
        : "r" (de_reg)          // %1: Input variable (forced to be 'de')
        : "cc", "hl"      // Clobber list: Flags, HL, and AF are modified
    );

    return result;
}
*/


//const int end_world=(int)world+WX*WY*WZ;
inline int fast_copysign_pos(int val, int src) {
	/**is a fast copy sign but only for positive numbers... I only use it for positive numbers though so it works.**/
    int mask=src>>23;//basically turns it into all 1s if pos, all 0s if neg
	return (val^mask)-mask;// inverts it if negitive (the xor) and then does --1 (if the flag was -1 it would be inverted). (+1) so 2's compliment
	
}
uint8_t * cross_hair_pt(uint8_t*& blockbefore,bool countwaterblock=0,bool countallwater=0)// pl is player, p is point rayracing.
{
	/** basically raycast point function below but gets the block (and previous block) where the crosshair is.
	block where the crosshair is pointing is used for using and breaking, block before is used to for placing blocks**/
	update_frac();
	int ix=plx;
	int iy=ply;
	int iz=plz;
    // Get directions from cache
    flint dx = cached_x_dir[160];
    flint dy = cached_y_dir[120];
    flint dz = 1; // Looking forward
	flint cosxz=cached_cos_rot[rotxz];
	flint sinxz=cached_sin_rot[rotxz];
	
	flint cosyz=cached_cos_rot[rotyz];
	flint sinyz=cached_sin_rot[rotyz];

	rot_point_3d(dx,dy,dz,cosxz,sinxz,cosyz,sinyz);
	//rot_point_3d(idx,idy,one,0,0,0,anglexz,angleyz);
	flint idx = inv_table[fast_abs(dx.data)];//dx.data is << by 13. inv_table is >>7. 13-7=6
	
    flint idy = inv_table[fast_abs(dy.data)];
	
	flint idz = inv_table[fast_abs(dz.data)];
	
	//idy=-idy;
	
	flint deltax=idx;// dx is (how much dist)for (1 unit), idx is (1 unit) for (how much length)
	flint deltay=idy;//same with idy,idz
	flint deltaz=idz;
	
	int signdx=fast_copysign_pos(XJ,dx.data);
	int signdy=fast_copysign_pos(YJ,dy.data);
	int signdz=fast_copysign_pos(1,dz.data);
	flint tmaxx,tmaxy,tmaxz;
	tmaxx.data=KMUL(deltax.data,KSEL(frx,dx.data));
	tmaxy.data=KMUL(deltay.data,KSEL(fry,dy.data));
	tmaxz.data=KMUL(deltaz.data,KSEL(frz,dz.data));

	uint8_t *curr_block = world+((ix) << XWS) + ((iy) << YWS) + (iz);
	for (int i=0; i<INTERACTD; ++i)
	{
		blockbefore=curr_block;//kinda slow, i know. don't really use this fucntion much tho
		if (tmaxx<tmaxy){
			if (tmaxx<tmaxz){//tmaxx is smallest
				curr_block+=signdx;
				tmaxx+=deltax;
			}
			else
			{//tmaxx ___ tamxy, so tmaxz
				curr_block+=signdz;
				tmaxz+=deltaz;
			}
		}
		else{ 
			if (tmaxy<tmaxz){//tmaxx is smallest
				curr_block+=signdy;
				tmaxy+=deltay;
			}
			else{
				curr_block+=signdz;
				tmaxz+=deltaz;
			}
		}

		if(countallwater||((countwaterblock||*curr_block!=WATERBLOCK)&&(*curr_block!=WATERSLAB&&*curr_block!=WATERFLOOR)))
		{
			if (*curr_block!= 0){
				return curr_block;
				
			}
		}
	}
	return NULL;// if no block
}
inline int ray_trace_point(const int pixelx,const int pixely, uint8_t* w, flint cosanglexz, flint sinanglexz, flint cosangleyz, flint sinangleyz)// pl is player, p is point rayracing.
{
	/** old function i used to draw stuff before i manually inlined it into raycast screen (so it would be faster), but still am keeping it for some reason... maybe i will need it later**/
    // Get directions from cache
    flint dx = cached_x_dir[pixelx];
    flint dy = cached_y_dir[pixely];
    flint dz = 1; // Looking forward
	
	rot_point_3d(dx,dy,dz,cosanglexz,sinanglexz,cosangleyz,sinangleyz);
	//rot_point_3d(idx,idy,one,0,0,0,anglexz,angleyz);
	flint deltax= inv_table[fast_abs(dx.data)];	
    flint deltay= inv_table[fast_abs(dy.data)];// had idx,idy,idz before
	flint deltaz = inv_table[fast_abs(dz.data)];
	
	flint tmaxx=deltax;// dist to next line *deltax. start on int coord, so dist to next line is 1
	flint tmaxy=deltay;
	flint tmaxz=deltaz;
	
	//flint deltax=idx;// dx is (how much dist)for (1 unit), idx is (1 unit) for (how much length)
	//flint deltay=idy;//same with idy,idz
	//flint deltaz=idz;
	unsigned int signdx=fast_copysign_pos(XJ,dx.data);
	unsigned int signdy=fast_copysign_pos(YJ,dy.data);
	unsigned int signdz=fast_copysign_pos(1,dz.data);


	uint8_t* curr_block = w;
	int dlocal=0;
	#pragma clang loop unroll(full)
	for (int i=0; i<VD; ++i)
	{
		if (tmaxx<tmaxy){
			if (tmaxx<tmaxz){//tmaxx is smallest
				curr_block+=signdx;
				tmaxx+=deltax;
				dlocal=0;//0<<8;
			}
			else
			{//tmaxx ___ tamxy, so tmaxz
				curr_block+=signdz;
				tmaxz+=deltaz;
				dlocal=2<<8;
			}
		}
		else{ 
			if (tmaxy<tmaxz){//tmaxx is smallest
				curr_block+=signdy;
				tmaxy+=deltay;
				dlocal=256;//1<<8;
			}
			else{
				curr_block+=signdz;
				tmaxz+=deltaz;
				dlocal=512;//2<<8;
			}
		}
		//asm("ld a,b\n "
		//"ld (_ix), a");

		//if ((uint24_t)(curr_block - base_world) < WX*WY*WZ)//saying if <0, wrap to big val and if to big is not <
			if (*curr_block){// if it is not 0
				return (int)(*curr_block)|(dlocal);
			}
	}
    return 0;
}
/** colors for solid blocks**/
//                                              NONE,grass,stone,wood,leaf,border,obsidian,iron,gold,diamond,sand,wool,snowgrass,snow,netherack,water,water
static const uint8_t hardness[block_num]=
{
	/*id 0-15, reg blocks*/  0,1,2,1,0,255,1,1,1,1,1,1,1,1,2,5,255,255,3,4,4,4,
	/*id 16, gap*/           0,
	/*id 17-19, floor*/      0,0,0,255,255,
	/*id 20-36, textures*/   1,2,1,1,1,1,1,1,1,2,0,2,1, /*crafttable..cactus*/  3,4,4,4,2,1,255,0,1,0,2, /*iron,gold,diamond,redstone,coal,tnt,lit_tnt smoke,gravel,netherportal,nthrgldore*/
	/*id 37-46, mobs*/       255,255,255,255,255,255,255,255,255,255
};
extern "C" {uint8_t colors[(reg_block_num + 1) << 2] = {
    /* Block ID:            0    1    2    3    4    5    6      7      8       9        10   11   12    13   14   15 */
    /* Block Name:        none grss stne wood leaf barr unlmp litlmp unbtn litbtn sand wool sgrs snow nthr obsd,   wterwrt irn gld dmnd rdstn*/

    /* Channel 0 (x)drkst */  0, 130, 106,  65,   6, bg_color,   0,   0,   0,   0, 205, 140, 130, 215,  64,   0,   25,25,139,  229,30,160,0,
    /* Channel 1 (y)light */  0,   5, 172, 238, 103, bg_color,   0,   0,   0,   0, 239, 247, 255, 255, 128,  74,   27,27,222,231,159,224,0,
    /* Channel 2 (z)drker */ 0, 131, 139,  97,   7, bg_color,   0,   0,   0,   0, 238, 181, 131, 247,  96,  1,   25,27,  213,230,31,192,0
};
}
void change_bg(uint8_t color)
{
	bg_color=color;
	colors[5]=color;
	colors[5+reg_block_num+1]=color;//changing color of barrier block
	colors[5+2*(reg_block_num+1)]=color;
}
/** beautiful textures! I designed them in ms paint then put them in textures.cpp to be used here! ik they are upside down here 
that is because the renderer flips all the textures in the y as a byproduct. it is slightly faster.**/

// this v v v  is an array storing what sides of texture blocks go with what textures ^ ^ ^
const uint8_t* texturedata[]={
	clear,clear,clear,clear,  clear,clear,clear,clear,  clear,clear,clear,clear,clear,clear,clear,clear, waterslabside,clear,waterslabside,clear, /*id 16-18: snowcarpet, redstonedustunlit, redstonedustlit - side/bottom transparent, top handled by floorcolors[]*/
//                  crafting table                                             furnace                                             planks                                                               bed top                         glass                               doortopopen                               doorbottomeopen             doortopclosed                         doorbottomclosed                   magmablock                                        fire                             sandstone                                                  cactus                       iron                              gold                                            diamond                            redstone                                                           coal                        tnt             lit tnt(will toggle texture in main loop to flash)                   explosion                                 gravel                                    netherportal texture (the purple stuff)                    nether gold ore                                               skeletontopx                           skeletontopz                    skeletonbottom                                  sheepfacex                    sheepfacez                      sheepbackx                      sheepbackz                                           zombietopx                                                zombietopz                                            zombielegs                  
	planksdarker,craftingtabletop,plankslighter,planksnorm,   furnacefront,cobblestone,furnacefront,cobblestone,  planksdarker,plankslighter,planksnorm,plankslighter, bedsidetop,bedtop,bedsidefront,bedtop,   glass, glass,glass,glass,  doorarch,brown,doorfronttop,brown,    doorbottomarch,clear,brown,brown, doorfronttop,brown,doorarch,brown, brown,clear,doorbottomarch,brown, magmablockx,magmablocky,magmablockx,magmablocky,       fire,firetop,fire,firetop, sandstonesidedarker,sandstonetop,sandstoneside,sandstonetop,     cactusside,cactustop,cactusside,cactustop ,ironorex,ironorey,ironorez,ironorey, goldorex,goldorey,goldorez,goldorey,    diamondorex,diamondorey,diamondorez,diamondorey, redstoneorex,redstoneorey,redstoneorez,redstoneorey,   coalorex,coalorey,coalorez,coalorey,   tntxz,tnty,tntxz,tnty,  tntxz,tnty,tntxz,tnty,                        explosionxyz,explosionxyz,explosionxyz,explosionxyz, graveltxt,graveltxt,graveltxt,graveltxt,   netherportaltxt,netherportaltxt,netherportaltxt,netherportaltxt,nethergoldorex,nethergoldorey,nethergoldorez,nethergoldorey,
//mobs
    skeletope,grey,skeletopf,clear,  skeletopf,grey,skeletope,clear,   skelebottom,skelebottom,skelebottom,skelebottom,   sheepface,grey,sheepside,grey,   sheepside,grey,sheepface,grey,     sheepback,grey,sheepside,grey,  sheepside,grey,sheepback,grey,     zombieface,zombieheadtop,zombiehead,zombieheadtop,     zombiehead,zombieheadtop,zombieface,zombieheadtop,      zombielegs,zombieheadtop,zombielegs,zombieheadtop  ,          pigface,pigtop,pigfrontside,pigtop,   pigfrontside,pigtop,pigface,pigtop,      pigback,pigtop,pigbackside,pigtop,    pigbackside,pigtop,pigback,pigtop,      piglinface,pigtop,piglintopside,pigtop,    piglintopside,pigtop,piglinface,pigtop,       piglinlegs,pigtop,piglinlegs,pigtop};
static flint cache [640]={};
bool is_in_crafting_table=false;

//void update_changes(int id, uint8_t* block);//see compiler, this function does exist! (i make it below and didn't feel like ctrl+x ing all of this below it v v v 
inline void draw_item(int temp,int x,int y,int show_num);
bool keyup(int key)
{
	if(kb_IsDown(key)){
		while(kb_IsDown(key))
			kb_Scan();
		return true;
	}
	return false;
}
void draw_arrow_nfull(int x,int y,int w,int h,int howfull)
{
	
	gfx_SetColor(74);
	int w2=w>>1;
	int h2=h>>1;
	
	gfx_FillRectangle_NoClip(x,y+(h2>>1),w2,h2);//1/2 of arrow is going to be rect	

	//now drawing triangle!
	
	//int th=h;//triangle line height = height
	
	//gfx_SetColor(1);
	gfx_SetColor(255);
	for(int x2=0;x2<w2;x2++)//y=mx+b. h=-x+y
	{
		if(howfull<x2+w2)
			gfx_SetColor(74);
		//dbg_printf("    x2: %d, x2+w2: %d\n",x2,x2+w2);
		gfx_VertLine(x+x2+w2,y+(x2>>1),h-x2);
	}
	gfx_SetColor(255);
	//dbg_printf("howfull: %d\n",howfull);
	if(howfull>w2)
		howfull=w2;
	gfx_FillRectangle_NoClip(x,y+(h2>>1),howfull,h2);
}
int updatehotbar=2;
/** yeah, i am not gonna explain these in detail v v v Basically just does stuff when the player uses that block**/
void use_craftingtable(uint8_t*)
{
	is_in_crafting_table=true;// goes into crafting table mode
}
// these open and close doors v v v 
void use_doorto(uint8_t* block)// if clicked on top open door block
{
	 //update_changes(*block+2,block);
	 *block+=2;//closes top door
	 block-=YJ;//down one in y
	 //update_changes(*block+2,block);
	 *block+=2;
}
void use_doortc(uint8_t* block)//if clicked on top closed door block
{
	 //update_changes(*block-2,block);
	 *block-=2;//opens top door
	 block-=YJ;//down one in y
	 //update_changes(*block-2,block);
	 *block-=2;//opens
}
void use_doorbo(uint8_t* block)// if clicked on bottom open door block
{
	 //update_changes(*block+2,block);
	 *block+=2;//closes bottom door
	 block+=YJ;//up one in y
	 //update_changes(*block+2,block);
	 *block+=2;//closes top
}
void use_doorbc(uint8_t* block)//if clicked on bottom closed door block
{
	 //update_changes(*block-2,block);
	 *block-=2;//opens top door
	 block+=YJ;//up one in y
	 //update_changes(*block-2,block);
	 *block-=2;//opens
}

static const uint8_t fuels[]={WOOD,PLANKS,CRAFTTABLE,WOODPIC,WOODSWORD,STICK,COALITEM};
//fuel times are out of 50, where 50 is one item smelted
static const int fueltimes[]={   75,   75,     75,      50,       50,25,     405};
static const int smeltable[]={SAND,IRON,GOLD,RAWMUTTON,RAWPORKCHOP};
static const int resulttable[]={GLASS,IRONINGOT,GOLDINGOT,COOKEDMUTTON,COOKEDPORKCHOP};
gfx_sprite_t **flames;
void decrease_item(int id);
void furnace_stuff(uint8_t*)//uint8_t* block)//need block because of syntax for array
{
	gfx_SwapDraw();
	flint howfull=0;//you know that arrow in the furnace screen? well this is howfull it is (out of 50).
	uint8_t fuelb=0;//fuel block
	uint8_t cookedb=0;//block that is being cooked
	uint8_t resultb=0;//block that is made as a result
	int cursor=1;
	//uint8_t cursorblock=0;
	uint8_t cursorcolor=230;
	int fuel=0;
	int frame=0;
	int fuelid=0;
	int smeltid=0;
	int scroll=0;
	int totalfuel=1;
	//40 items per screen
	while(true){
		gfx_SwapDraw();
		gfx_Wait();
		gfx_FillScreen(107);
		gfx_SetDrawBuffer();
		kb_Scan();
		//drawing stuff!
		int x=2;//r. 23. 23/2 = 11.5
		int y=98;
		int c=0;
		//inventory[DIAMONDPIC]=1;
		for(int i=scroll+1; i<invenblocknum+item_num; ++i)//looping through inventory (inventory is an int[inven_block_num+item_num])
		{
			if(c>35)
				break;
			c++;
			int foo=inventory[i];
			if(cursor==i)
			{
				gfx_SetColor(cursorcolor);
				gfx_FillRectangle(x-2,y-2,36,36);
			}
			if (foo>0&&i!=fuelb && i!=cookedb && i!=resultb)
				draw_item(i,x,y,1);//item/block,x,y,showtext
			else
				draw_item(0,x,y,1);
			x+=35;//r 23.
			if(x>320-30)
			{
				x=2;
				y+=35;
			}
		}
		//dbg_printf("howfull l: %d\n",howfull);
		draw_arrow_nfull(130,30,50,25,howfull);
		
		
		gfx_SetColor(140);		
		gfx_FillRectangle_NoClip(60,0,36,36);
		draw_item(cookedb,63,3,1);
		
		gfx_SetColor(140);
		gfx_FillRectangle_NoClip(60,60,36,36);
		draw_item(fuelb,63,63,1);
		
		gfx_SetColor(140);
		
		gfx_FillRectangle_NoClip(210,25,36,36);
		draw_item(resultb,213,28,1);
		int foo=(fuel*6)/totalfuel;//(fuel+15)>>4;
		if(foo>5)
			foo=5;
		if(foo<0)
			foo=0;
		gfx_Sprite_NoClip(flames[foo],68,38);
		if(cursor-scroll<37)
			scroll-=9;
		if(cursor-scroll>36)
			scroll+=9;
		if(scroll<0)
			scroll=0;
		resultb=0;
		if(howfull>0)
			resultb = resulttable[smeltid];
		if(frame==0)
		{
			
			if(cookedb!=0)
			{
				
				if(fuel>0){
					howfull+=1;
					
				}
				else if(fuelb!=0&&inventory[fuelb]>0)// if fuel is out
				{
					
					fuel=fueltimes[fuelid];
					totalfuel=fuel;
					decrease_item(fuelb);
				}
			}
			if(howfull>49)//finished smelting block
			{
				inventory[resulttable[smeltid]]++;
				howfull=1;
				
				decrease_item(cookedb);
			}
			if(fuel>0)
			{
				fuel--;
			}
			else if(cookedb!=0)
			{
				fuelid=0;
				fuelb=0;
			}
		}
		if(inventory[cookedb]<=0)
			cookedb=0;
		frame++;
		frame%=5;
		//msleep(100);
		//key stuff!
		if(kb_IsDown(kb_KeyClear))
		{
			superstop=true;
			return;
		}
		if(kb_Data[3] & kb_GraphVar){//xton
			while(kb_Data[3] & kb_GraphVar)
				kb_Scan();// waits till u release it until ending, so doesen't spawn you in crafting menu
			updatehotbar=2;
			return;
		}
		//length is 9
		if(keyup(kb_KeyRight)){
			cursor++;
		}
		if(keyup(kb_KeyLeft))
			cursor--;
		if(keyup(kb_KeyUp))
		{
			cursor-=9;
		}
		if(keyup(kb_KeyDown))
		{
			cursor+=9;
		}
		if(cursor>invenblocknum+item_num-1)
			cursor=invenblocknum+item_num-1;
		if(cursor<1)
			cursor=1;
		

		if(keyup(kb_Key2nd))
		{
			cookedb=0;
			smeltid=0;
			howfull=0;
			if(inventory[cursor]>0)
			{
				for (int i=0; i<5; ++i)//how many possible blocks can smelt
				{
					if(smeltable[i]==cursor){
						cookedb=cursor;
						smeltid=i;
						break;
					}
				}
			}
		}
		if(keyup(kb_KeyAlpha))
		{
			fuelb=0;
			fuelid=0;
			if(inventory[cursor]>0)
			{
				for (int i=0; i<7; ++i)
				{
					if(fuels[i]==cursor)
					{
						fuelb=cursor;
						//fuel=fueltimes[i];
						fuelid=i;
						break;
					}
				}
			}
		}		
	}
}
//ZOMBIETOPX
//ZOMBIETOPZ
//ZOMBIELEGS
int8_t playerhp=20;
int8_t playerhunger=20;

uint8_t ghotbar[8]={};
int hotbarblock=0;

// for reverence v v v 
//const static gfx_sprite_t *item_imgs[]={woodpic,stonepic,goldpic,ironpic,diamondpic,/*netheritepic*/NULL,stick,woodsword,stonesword,goldsword,ironsword,diamondsword,ironingot,goldingot,rawmutton,    cookedmutton,    rottenflesh}, diamonditem    coalitem,     flint and steel   flint, bucket, water_bucket, pork pork

const static uint8_t attack_damage[item_num]  =   {2,        3,       2,       4,        5,           6,              1,       4,      5,         4,      6,           7,           1,        1,       1,          1,                  1,     1,                1,         1,            1,     1,       1 ,       1,     1};

/**disclamer: I wrote the sheep and zombie classes at first then asked claude to turn them into genral hmob and vmob classes so this is like half vibe-coded**/
void add2hotbar(int id)
{
	updatehotbar=2;
	for (int i=0; i<8;++i)
	{
		if(ghotbar[i]==id)
		{
			return;//it is already in hotbar; do nothing			
		}
	}
	//ok, so now time to try to find place for it
	for (int i=0; i<8;++i)
	{
		if(ghotbar[i]==0)
		{
			ghotbar[i]=id;//empty space
			return;			
		}
	}
}
/*
    DYNAMIC MOB LIST
    ================
    Goal: no more fixed "always exactly SHEEPNUM sheep, always exactly
    ZOMBIENUM zombies" -- instead, a variable-length list of active mobs.

    Important reality check for this hardware: a truly unbounded list
    (malloc-per-mob) risks the same RAM fragmentation you already guard
    against elsewhere in your code (world_changes realloc, the "YOU ARE
    LOW ON RAM" messages). So this uses an *object pool* instead:
    fixed backing storage (no allocation, no fragmentation), but the
    number of ACTIVE mobs drawn from that storage varies at runtime --
    you're no longer locked into exactly N sheep existing at all times.

    Mob is now fully polymorphic: clear/draw/update/at/hurt are all
    virtual, so one generic loop drives every mob regardless of type,
    and adding a new mob type later is just a new subclass -- no
    changes needed to the list/pool/hurt-dispatch code below.
*/

#include <cstdint>

// ============================================================
// Mob -- common interface every mob type implements
// ============================================================
struct Mob
{
    bool active=false;
    uint8_t x=0,y=0,z=0;
    int8_t hp=0;

    virtual void clear()=0;
    virtual void draw()=0;
    virtual void update()=0;
    virtual bool at(uint8_t* block)=0;
    virtual void hurt(int amount)=0;
    virtual ~Mob(){}
};

#define MAX_MOBS 24
Mob* mob_list[MAX_MOBS];
int mob_count=0;

bool add_mob(Mob* m)
{
    if(mob_count>=MAX_MOBS) return false;
    mob_list[mob_count++]=m;
    m->active=true;
    return true;
}
void remove_mob(Mob* m)
{
    for(int i=0;i<mob_count;++i)
        if(mob_list[i]==m)
        {
            mob_list[i]=mob_list[mob_count-1];
            mob_count--;
            break;
        }
    m->active=false;
}
void despawn_mob(Mob* m){ m->clear(); remove_mob(m); }
void update_all_mobs(){ for(int i=0;i<mob_count;++i) mob_list[i]->update(); }

void hurtmob_at(uint8_t* block)
{
    int amount=1;
    int hblock=ghotbar[hotbarblock];
    if(hblock>invenblocknum)
        amount=attack_damage[hblock-invenblocknum-1];
    for(int i=0;i<mob_count;++i)
        if(mob_list[i]->at(block))
        {
            mob_list[i]->hurt(amount);
            return;
        }
}

// sign that returns 0 for 0 (your sign() returns 1)
inline int8_t sgn(int n){ return (n>0)-(n<0); }

// ===================== HMob =====================
struct HMob : public Mob
{
    int8_t facingx=0, facingz=0;
    int8_t base_hp=8;
    uint8_t faceX=0, backX=0, faceZ=0, backZ=0;
    uint8_t drop1id=0, drop1cnt=0, drop2id=0, drop2cnt=0;

    void setup(uint8_t fx,uint8_t bx,uint8_t fz,uint8_t bz,int8_t hp_,
               uint8_t d1id=0,uint8_t d1cnt=0,uint8_t d2id=0,uint8_t d2cnt=0)
    {
        faceX=fx; backX=bx; faceZ=fz; backZ=bz;
        base_hp=hp_; hp=hp_;
        drop1id=d1id; drop1cnt=d1cnt; drop2id=d2id; drop2cnt=d2cnt;
    }
    inline void fall_down()
    {
        bool nothitair=1;
        while((vis_map(x,y-1,z)==0&&vis_map(x-facingx,y-1,z-facingz)==0)||nothitair)
        {
            y--;
            if(vis_map(x,y,z)==0&&vis_map(x-facingx,y,z-facingz)==0)
                nothitair=0;
            if(y<1) break;
        }
    }
    inline void fall()
    {
        if(vis_map(x,y-1,z)==0&&vis_map(x-facingx,y-1,z-facingz)==0)
            y--;
    }
    void spawn()
    {
        x=randInt(2,WX-2);
        z=randInt(1,WZ-2);
        y=WY-1;
        facingx=1; facingz=0;
        hp=base_hp;
        fall_down();
        draw();
    }
    void clear() override
    {
        vis_map(x,y,z)=0;
        vis_map(x-facingx,y,z-facingz)=0;
    }
    void draw() override
    {
        if(facingx!=0)
        {
            vis_map(x,y,z)=faceX;
            vis_map(x-facingx,y,z)=backX;
        }
        else
        {
            vis_map(x,y,z)=faceZ;
            vis_map(x,y,z-facingz)=backZ;
        }
    }
    void move()
    {
        clear();
        x+=facingx;
        if(vis_map(x,y,z)!=0)
        {
            y++;
            if(vis_map(x,y,z)!=0||vis_map(x-facingx,y,z)!=0||y>WY-1)
            { y--; x-=facingx; }
        }
        z+=facingz;
        if(vis_map(x,y,z)!=0)
        {
            y++;
            if(vis_map(x,y,z)!=0||vis_map(x,y,z-facingz)!=0||y>WY-1)
            { y--; z-=facingz; }
        }
        fall();
        draw();
    }
    void randturn()
    {
        clear();
        switch(randInt(0,10))
        {
            case 0: if(vis_map(x-1,y,z)==0){facingx=1;facingz=0;} break;
            case 1: if(vis_map(x+1,y,z)==0){facingx=-1;facingz=0;} break;
            case 2: if(vis_map(x,y,z-1)==0){facingx=0;facingz=1;} break;
            case 3: if(vis_map(x,y,z+1)==0){facingx=0;facingz=-1;} break;
        }
        draw();
    }
    void update() override
    {
        if(randInt(0,AVERAGEFPS)==0){ move(); randturn(); }
    }
    bool at(uint8_t* block) override
    {
        return &(vis_map(x,y,z))==block || &(vis_map(x-facingx,y,z-facingz))==block;
    }
    void hurt(int amount) override
    {
        hp-=amount;
        if(hp<=0)
        {
            if(drop1id){inventory[drop1id]+=drop1cnt; add2hotbar(drop1id);}
            if(drop2id){inventory[drop2id]+=drop2cnt; add2hotbar(drop2id);}
            despawn_mob(this);
        }
    }
};

// ===================== VMob =====================
struct VMob : public Mob
{
    uint8_t facing=0;          // 0 is x, 1 is z
    uint8_t playerinsight=0;
    int8_t  base_hp=20;
    uint8_t cooldown=0;
    uint8_t damage=1;
    uint8_t legs=0, topX=0, topZ=0;
    uint8_t drop1id=0, drop1cnt=0, drop2id=0, drop2cnt=0;

    void setup(uint8_t legs_,uint8_t topX_,uint8_t topZ_,int8_t hp_=20,uint8_t dmg=1,
               uint8_t d1id=0,uint8_t d1cnt=0,uint8_t d2id=0,uint8_t d2cnt=0)
    {
        legs=legs_; topX=topX_; topZ=topZ_;
        base_hp=hp_; hp=hp_; damage=dmg;
        drop1id=d1id; drop1cnt=d1cnt; drop2id=d2id; drop2cnt=d2cnt;
    }
    void draw() override
    {
        vis_map(x,y,z)=legs;
        vis_map(x,y+1,z)=facing?topZ:topX;
    }
    void clear() override
    {
        vis_map(x,y,z)=0;
        vis_map(x,y+1,z)=0;
    }
    void spawn()
    {
        x=randInt(1,WX-2);
        z=randInt(2,WZ-2);
        y=WY-1;
        hp=base_hp;
        bool nothitair=1;
        while(vis_map(x,y-1,z)==0||nothitair)
        {
            y--;
            if(vis_map(x,y,z)==0) nothitair=0;
            if(y<1) break;
        }
        draw();
    }
    // one step along one axis (one of sx/sz is +-1, other 0). Climbs 1 block.
    // Call between clear() and draw().
    bool step(int8_t sx,int8_t sz)
    {
        if(sx==0&&sz==0) return false;
        if(vis_map(x+sx,y+1,z+sz)!=0) return false;
        x+=sx; z+=sz;
        if(vis_map(x,y,z))
        {
            if(vis_map(x,y+2,z)==0&&y<WY-1) y++;
            else { x-=sx; z-=sz; return false; }
        }
        return true;
    }
    void move()
    {
        clear();
        if(playerinsight)
        {
            int iplx=(int)plx, iplz=(int)plz;
            int8_t sx=sgn(iplx-x), sz=sgn(iplz-z);
            bool xfirst = fast_abs(x-iplx)>fast_abs(z-iplz);
            if(xfirst ? step(sx,0) : step(0,sz))
                facing=!xfirst;
            else if(xfirst ? step(0,sz) : step(sx,0))
                facing=xfirst;
        }
        else if(randInt(0,3)==0)
        {
            facing=!facing;
            int dist=fast_abs((int)plx-x)+fast_abs((int)plz-z);
            if(dist<12) playerinsight=1;
        }
        if(vis_map(x,y-1,z)==0) y--;
        draw();
    }
    void update() override
    {
        uint8_t prevx=x, prevy=y, prevz=z;
        move();
        if(cooldown) cooldown--;
        if((int)plx==x && (int)plz==z && fast_abs((int)ply-1-y)<2)
        {
            if(cooldown==0)
            {
                playerhp-=damage;
                cooldown=AVERAGEFPS;
                updatehotbar=2;
            }
            // undo move (clear/draw so the map matches)
            clear(); x=prevx; y=prevy; z=prevz; draw();
        }
    }
    bool at(uint8_t* block) override
    {
        return &(vis_map(x,y,z))==block || block==&(vis_map(x,y+1,z));
    }
    void hurt(int amount) override
    {
        int8_t prevhp=hp;
        hp-=amount;
        if(hp<1&&prevhp>0)
        {
            if(drop1id){inventory[drop1id]+=drop1cnt; add2hotbar(drop1id);}
            if(drop2id){inventory[drop2id]+=drop2cnt; add2hotbar(drop2id);}
            despawn_mob(this);
        }
    }
};

// ===================== Skeleton =====================
struct Skeleton : public VMob
{
    void update() override
    {
        clear();
        int dx=(int)plx-x, dz=(int)plz-z;
        int adx=fast_abs(dx), adz=fast_abs(dz);
        int dist=adx+adz;
        facing = adz>=adx;
        if(cooldown) cooldown--;

        if(dist<=14)
        {
            int8_t sx=0, sz=0;
            if(adx>adz) sx=sgn(dx); else sz=sgn(dz);
            if(dist>8)       step(sx,sz);        // approach
            else if(dist<4)  step(-sx,-sz);      // back off
            else if(randInt(0,3)==0)             // strafe
                step(sz?1:0, sx?1:0);

            if(dist<=10 && cooldown==0 && randInt(0,2)==0)
            {
                playerhp-=damage;                // hitscan arrow
                cooldown=AVERAGEFPS*2;
                updatehotbar=2;
            }
        }
        if(vis_map(x,y-1,z)==0) y--;
        draw();
    }
};

// ===================== Pools =====================
#define HMOB_POOL_SIZE 16
#define VMOB_POOL_SIZE 16
#define SKEL_POOL_SIZE 8
static HMob hmob_pool[HMOB_POOL_SIZE];
static VMob vmob_pool[VMOB_POOL_SIZE];
static Skeleton skel_pool[SKEL_POOL_SIZE];

HMob* spawn_hmob(uint8_t fx,uint8_t bx,uint8_t fz,uint8_t bz,int8_t hp,
                 uint8_t d1id=0,uint8_t d1cnt=0,uint8_t d2id=0,uint8_t d2cnt=0)
{
    for(int i=0;i<HMOB_POOL_SIZE;++i)
        if(!hmob_pool[i].active)
        {
            hmob_pool[i].setup(fx,bx,fz,bz,hp,d1id,d1cnt,d2id,d2cnt);
            hmob_pool[i].spawn();
            if(!add_mob(&hmob_pool[i])){ hmob_pool[i].clear(); return NULL; }
            return &hmob_pool[i];
        }
    return NULL;
}
VMob* spawn_vmob(uint8_t legs,uint8_t topX,uint8_t topZ,int8_t hp=20,uint8_t dmg=1,
                 uint8_t d1id=0,uint8_t d1cnt=0,uint8_t d2id=0,uint8_t d2cnt=0)
{
    for(int i=0;i<VMOB_POOL_SIZE;++i)
        if(!vmob_pool[i].active)
        {
            vmob_pool[i].setup(legs,topX,topZ,hp,dmg,d1id,d1cnt,d2id,d2cnt);
            vmob_pool[i].spawn();
            if(!add_mob(&vmob_pool[i])){ vmob_pool[i].clear(); return NULL; }
            return &vmob_pool[i];
        }
    return NULL;
}
Skeleton* spawn_skeleton()
{
    for(int i=0;i<SKEL_POOL_SIZE;++i)
        if(!skel_pool[i].active)
        {
            skel_pool[i].setup(SKELEBOTTOM,SKELETOPX,SKELETOPZ,12,2,STICK,2);
            skel_pool[i].spawn();
            if(!add_mob(&skel_pool[i])){ skel_pool[i].clear(); return NULL; }
            return &skel_pool[i];
        }
    return NULL;
}

template<class T>
void manage_nocturnal_vmobs(T* pool,int poolsize,int wtime,int sun_damage)
{
    for(int i=0;i<poolsize;++i)
    {
        T& m=pool[i];
        if(!m.active) continue;
        if(sun_damage&&wtime<10&&m.hp>0) m.hp-=sun_damage;
        if(m.hp<1){ m.clear(); remove_mob(&m); }
    }
}

#define spawn_sheep() spawn_hmob(SHEEPFACEX,SHEEPBACKX,SHEEPFACEZ,SHEEPBACKZ,8, WOOL,2,RAWMUTTON,1);
#define spawn_pig() spawn_hmob(PIGFACEX,PIGBACKX,PIGFACEZ,PIGBACKZ,8,RAWPORKCHOP,1);
#define spawn_zombie() spawn_vmob(ZOMBIELEGS,ZOMBIETOPX,ZOMBIETOPZ,20,1,ROTTENFLESH,2);
VMob* spawn_piglin()
{
	 auto s=spawn_vmob(PIGLINLEGS,PIGLINTOPX,PIGLINTOPZ,20,1,RAWPORKCHOP,1,GOLDINGOT,1);
	 
	 if(s==NULL)
	 	return NULL;
	 s->clear();
	
	 if(randInt(0,1)&&s->y>15)
	 {
		 s->y--;
		 s->y--;//so head is in a solid
		while(vis_map(s->x,s->y,s->z)||vis_map(s->x,s->y+1,s->z))//keep falling if head OR feet are in a solid
		{
			s->y--;
			if(s->y<2)
			{
				remove_mob(s);
				return NULL;//unable to find a suitable spawn
			}
		}
	 }
	 s->draw();
	 return s;
}
int32_t* gstarttime;
uint32_t offsettime=(uint32_t)(3932160/2)*(uint32_t)2;//2 minutes in ticks.

int respawnx=1;
int respawny=WY-1;
int respawnz=1;
uint8_t chunkx=32;
uint8_t chunkz=32;
uint8_t respawnchunkx=32;
uint8_t respawnchunkz=32;

void use_bed(uint8_t* block)
{
	if(realm==1)//nether
	{
		explode(block,3);//everyone's favorite mechanic!
		return;
	}
	respawnx=plx;
	respawny=ply;
	respawnz=plz;
	respawnchunkx=chunkx;
	respawnchunkz=chunkz;
	uint32_t temps=clock()-*gstarttime;//global start time
	temps+=offsettime;
	uint32_t elapsed_seconds=(unsigned int)(temps>>15);
	elapsed_seconds=(elapsed_seconds * 17477) >> 19;//now in minutes
	int wtime=((int)elapsed_seconds)%20;//world time. world resets every 20 minutes
	dbg_printf("Tried to use bed: witme %d\n",wtime);
	if(wtime>9)//night
	{
		//time to sleep
		gfx_SetDrawBuffer();
		gfx_FillScreen(0);
		gfx_PrintStringXY("Sleeping...",116,110);
		gfx_SwapDraw();
		msleep(3000);
		//we will skip backwards instead of forwards to delay overflow in the time variable
		uint32_t timetoskip=22-wtime;//in world time
		timetoskip=timetoskip*30;//now in minutes. should be *60 but made cycle 2x speed
		timetoskip=timetoskip<<15;
		offsettime+=timetoskip;
	}
}



void use_tnt(uint8_t* block)
{
	dbg_printf("used tnt!\n");
	if(ghotbar[hotbarblock]==FLINTANDSTEEL)
	{
		*block=LITTNT;
		add_updates_fully(block);
		dbg_printf("lit tnt!\n");
	}
}

// indexed by (id - (reg_block_num+1)), covers ids SNOWCARPET(16)..ZOMBIELEGS(41)
static void (*block_is_usable[])(uint8_t*) ={
	NULL, NULL, NULL, NULL,NULL,                                                 // 16-18: snowcarpet,redstonedustunlit,redstonedustlit,waterfloor,waterslab
	use_craftingtable, furnace_stuff, NULL, use_bed, NULL,             // 19-23: crafttable,furnace,planks,bedtop,glass
	use_doorto, use_doorbo, use_doortc, use_doorbc,                    // 24-27: doors
	NULL, NULL, NULL, NULL,NULL,NULL,NULL,NULL,NULL,NULL/*calls use_tnt by other methods*/,NULL,NULL,NULL,NULL, // 28-31: magmablock,fire,sandstone,cactus + ores. tnt, lit tnt, smoke,gravel,netherportal
	NULL, NULL, NULL,NULL,                                                  // 32-34: skeletopx,skeletopz,skelebottom (unimplemented)
	 hurtmob_at, hurtmob_at, hurtmob_at, hurtmob_at,                        // 35-38: sheepfacex,sheepfacez,sheepbackx,sheepbackz
	 hurtmob_at, hurtmob_at, hurtmob_at,                                // 39-41: zombietopx,zombietopz,zombielegs
	 hurtmob_at, hurtmob_at, hurtmob_at, hurtmob_at,
	 hurtmob_at, hurtmob_at, hurtmob_at
};
void noinven(uint8_t* block)
{
	*block=0;//break it.
	return;
}
void donothing(uint8_t*)//does absolutely nothing
{
}

void draw_trans_rect_fake(int x,int y, int w, int h,int color)
{
	/** draws a transparent rectangle using dithering (or however you spell that). used for
	the greyed/grayed out portion of the crafting table and nothing else (so far!)**/
	uint8_t* buff=(uint8_t*)gfx_vbuffer;
	for (int i=x;i<w+x;++i)
	{
		int temp=i&1;
		for (int j=y+temp;j<y+h;j+=temp+1)
		{
			buff[j*320+i]=color;
		}
	}

}
void draw_trans_rect_fake_less_dark(int x,int y, int w, int h,int color)
{
	/** draws a transparent rectangle using dithering (or however you spell that). used for
	the greyed/grayed out portion of the crafting table and nothing else (so far!)**/
	uint8_t* buff=(uint8_t*)gfx_vbuffer;
	for (int i=x;i<w+x;i+=2)
	{
		for(int j=y;j<y+h;j+=2)
		{
			buff[j*320+i]=color;
		}
	}

}

extern "C" uint8_t ASM_DDA_FULL(uint8_t quadrant);
extern "C" int* getddadeltax();
extern "C" int* getddadeltay();
extern "C" int* getddadeltaz();
extern "C" uint8_t** getddacurrblock();

int* ddadeltax = getddadeltax();
int* ddadeltay = getddadeltay();
int* ddadeltaz = getddadeltaz();
uint8_t** ddacurrblock = getddacurrblock();

extern "C" int* getddatmaxx();
extern "C" int* getddatmaxy();
extern "C" int* getddatmaxz();
extern "C" int fast_mul16(int x, int y);

int* ddatmaxx = getddatmaxx();
int* ddatmaxy = getddatmaxy();
int* ddatmaxz = getddatmaxz();



#define CONCAT_(a,b) a##b
#define CONCAT(a,b) CONCAT_(a,b)

#define RUN_DDA_LOOP_P(stepx,stepy,stepz,pastenum)\
	 _Pragma("clang loop unroll_count(2)")\
	for (; i<VD;++i)\
	{\
		if (tmaxx<tmaxy){\
			if (tmaxx<tmaxz){\
				curr_block+=stepx;\
				tmaxx.data+=deltax.data;\
				if (*curr_block){\
				CONCAT(d,pastenum)=0;\
				goto CONCAT(blocky_stuff,pastenum);\
				}\
			}\
			else\
			{\
				curr_block+=stepz;\
				tmaxz.data+=deltaz.data;\
				if (*curr_block){\
				CONCAT(d,pastenum)=2*(reg_block_num+1);\
				goto CONCAT(blocky_stuff,pastenum);\
				}\
			}\
		}\
		else{\
			if (tmaxy<tmaxz){\
				curr_block+=stepy;\
				tmaxy.data+=deltay.data;\
				if (*curr_block){\
				CONCAT(d,pastenum)=(reg_block_num+1);\
				goto CONCAT(blocky_stuff,pastenum);\
				}\
			}\
			else{\
				curr_block+=stepz;\
				tmaxz.data+=deltaz.data;\
				if (*curr_block){\
				CONCAT(d,pastenum)=2*(reg_block_num+1);\
				goto CONCAT(blocky_stuff,pastenum);\
				}\
			}\
		}\
	}

extern "C" int dda_deltax, dda_deltay, dda_deltaz;
extern "C" int dda_tmaxx, dda_tmaxy, dda_tmaxz;
extern "C" int DX, DY, DZ;
extern "C" uint8_t* dda_currblock;
extern "C" int fracmul_c(int delta, uint8_t k16);
#define TRACE_COLUMN(pastenum,CONTMACRO)\
	flint dx;dx.data=((*cx).data-sinxztdz.data);\
	flint dz;dz.data=((*cz).data+cosxztdz.data);\
	deltax= inv_tablel[dx.data];\
	deltaz = inv_tablel[dz.data];\
	\
	tmaxx.data = fracmul_c(deltax.data, (dx.data>0) ? fr_kxp : fr_kxn);\
	tmaxz.data = fracmul_c(deltaz.data, (dz.data>0) ? fr_kzp : fr_kzn);\
	tmaxy.data = tmaxy0;\
	\
	uint8_t quadrant = (dx.data>0) + tdy_bit + ((dz.data > 0)<<2);\
	\
		uint8_t* curr_block = w;\
	static uint8_t CONCAT(d,pastenum);\
	cx+=res*2;\
	cz+=res*2;\
	dda_deltax=deltax.data;\
	dda_deltay=deltay.data;\
	dda_deltaz=deltaz.data;\
	dda_tmaxx=tmaxx.data;\
	dda_tmaxy=tmaxy.data;\
	dda_tmaxz=tmaxz.data;\
	DX=dx.data;\
	DY=tdy.data;\
	DZ=dz.data;\
	/*CONCAT(start_loop,pastenum):*/\
	*ddacurrblock=curr_block;\
	CONCAT(d,pastenum)=ASM_DDA_FULL(quadrant);\

	
//#define mlt32(a, b) ((int) ( ( (int32_t)(a.data) * (int32_t)(b.data) ) >> shift_by) )
#define mlt32(a,b) a*b
//#define mlt32(a,b) ([&]{ flint r; r.data=(int)(((int32_t)(a).data*(int32_t)(b).data)>>shift_by); return r; }())
extern "C" void rect_8x8(int x, uint8_t y, uint8_t color, uint8_t* screenaddr);
extern "C" { extern int row_sin,row_cos,row_tmaxy,row_w,col_cx,col_cz,DY;
                  extern uint8_t row_tdybit;  void raycast_cols_A(); }
extern "C" uint8_t* getscratch3();
extern "C" uint8_t** getrectaddr();
extern "C" void optomized_raycast_rect_8x8();
extern "C" void optomized_raycast_rect_5x5();
extern "C" void optomized_raycast_rect_5x5_no2();
extern "C" int PX, PY, PZ;

extern "C" void notfullfillscreen(uint8_t color,uint8_t* screenaddr);
extern "C" void rect8x8complete(uint8_t* screenaddr);



//__attribute__((section(".ramfunc"), noinline))
extern "C" {
	const uint8_t** ltexturedata = (texturedata - ((reg_block_num+1) << 2));//the typing was a const uint8_t*[].
}
// ---- pass A column loop lives in stuff.asm (_raycast_cols_A). These are its per-row inputs.
// (3-byte values are int on the eZ80.)  inv_table must be a NON-static global pointer (asm reads _inv_table).
extern "C" {
	extern int row_sin, row_cos, row_tmaxy, row_w, col_cx, col_cz;
	extern uint8_t row_tdybit;
	void raycast_cols_A();
	void save_shadow_bc();
	void restore_shadow_bc();
}
extern "C" void raycast_cols_B();
extern "C" void raycast_cols_A2();
void raycast_screen()
{
	/** this draws everything. This is kinda complicated, because it needs to be fast. It uses raycasting, but instead of being 2.5d it is 
	fully 3d (you can look up and down in addition to looking left and right). I cache a lot of stuff to make it faster. Basically, what happens, 
	is i get the ray direction from the x,y of the pixel, rotate it by	the players rotation (rotxz and rotyz) then use the dda algorithm to tell 
	when hit a block. DDA algorithm in a nutshell is instead of taking a bunch of really small steps we take a little bit of smart steps. 
	(we basiclally jump across on the grid lines of the block to tell when we hit one instead of moving a little bit at a time and seeing if we hit one 
	(what step raycasters do)) Look it up if you want more detail. there are 2 types of blocks. Solid blocks (like	grass, stone, or leaves) and textured blocks 
	(like glass or a crafting table). Textured blocks are a lot slower. Expecially if they are clear.like a door frame. That will tank your frame rate ;). 
	I try to avoid too many of those blocks. Anyways, Textured blocks are just blocks whose sides have 8x8 pictures on them instead of a solid color.
	Hard to represent a crafting table with one color. If it is a colored block, i can just get the color of the side. If it is a textured block, however, i have to use 
	some semi-broken-but-still-usable logic i saw on a wikipedia page (let me be clear: broken in my code, not theirs) to find the color of the exact block. If the color is 26, 
	which i treat as clear, it just skips the block goes back and keeps looking for another block. That is why doors look funky from the inside -- you can't see a block from the inside.
	
	Anyways, this part works. I promise the rotation logic is there, despite it being spread across the universe (again speed) I will admit, although AI did not write
	most of this, i did ask it to look through and see if it could make it faster. And it did help, despite many halluciations. For some reason, it
	could not seem to understand my rotation logic ;). It also kept suggesting things that made it slower so I had to double check everything. Like I said,
	AI DID NOT WRITE ANY FUNDAMENTAL LOGIC, I DID THAT!!! ME!!! although it did help with that branching in the dda loop and proably increased the overall speed by 20%
	Another thing: I didn't copy/paste really any ai code (mostly because it wasn't going to work, and with an exception for like one or two uncomplicated lines) so really i wrote almost all of
	this code. If you count AI suggestions (like using less variables), those probably made it 1.5x as fast, even though it was me who wrote the code. And not a stare at it's code and "write" it -- I actually wrote the logic.**/
	__asm__ volatile ("di");//get rid of instruction stalling maybe
	save_shadow_bc();//the asm DDA uses b' as its step counter
	update_frac();
	PX=(int)plx;
	PY=(int)ply;
	PZ=(int)plz;
	uint8_t** tempval1=getrectaddr();
	auto& tempval=*tempval1;
	tempval=&gfx_vbuffer[0][0];
	uint8_t* colortorect=getscratch3();
	int tempx=(int)plx;
	int tempy=(int)ply;
	int tempz=(int)plz;
	uint8_t* w= world+(tempx << XWS) + (tempy << YWS) + tempz;
	
	//flint *cache =  (flint*)((uint8_t*)gfx_vbuffer+ (200 * 320));//screen where hotbar is (drawbuffer)
	
	flint cosxz=cached_cos_rot[rotxz];
	flint sinxz=cached_sin_rot[rotxz];
	
	flint cosyz=cached_cos_rot[rotyz];
	flint sinyz=cached_sin_rot[rotyz];
	
	flint* cacheaddr=&cache[0];
	flint * cacheaddr320=cacheaddr+320;
	//dbg_printf("\n\n\n");
	/* My version v v v
	for(int i=0; i<320;i+=res)
	{
		flint nx=cached_x_dir[i];
		(*cacheaddr).data=(cosxz.data*nx.data)>>shift_by;
		(*(cacheaddr320)).data=(sinxz.data*nx.data)>>shift_by;
		//dbg_printf("cos: %d, sin: %d, nx: %d\n",cosxz.data,sinxz.data,nx.data);
		cacheaddr+=res;
		cacheaddr320+=res;
	}
	*/
	// claude's version v v v  (asked it to optimize my version.
	flint dnx = cached_x_dir[res] - cached_x_dir[0];      // constant step in nx
	flint dcos; dcos.data = (cosxz.data * dnx.data) >> shift_by;  // 1 mult
	flint dsin; dsin.data = (sinxz.data * dnx.data) >> shift_by;  // 1 mult

	flint valcos; valcos.data = (cosxz.data * cached_x_dir[0].data) >> shift_by;
	flint valsin; valsin.data = (sinxz.data * cached_x_dir[0].data) >> shift_by;

	for(int i=0; i<320; i+=res)
	{
		(*cacheaddr).data = valcos.data;
		(*cacheaddr320).data = valsin.data;
		valcos.data += dcos.data;
		valsin.data += dsin.data;
		cacheaddr+=res;
		cacheaddr320+=res;
	}
	//dbg_printf("\n\n\n");
	

	flint* inv_tablel=&inv_table[0];
	//int y=200;
	const uint8_t* lcolors=colors;
	
	//-reg_block_num+1 because otherwise i'd have to say -reg_block_num+1 for every texture thing to convert the id for the array
	//<<2 because do id <<2
	
	
	flint tmaxx;// dist to next line *deltax. start on int coord, so dist to next line is 1
	static flint tmaxy;//for some reason, when i declare some variables as static it gets much faster
	static flint tmaxz;
	static flint deltax;
	static flint deltay;
	flint deltaz;//but not all variables
	//basically, i made one x and one z not static because only two variables not being static holds up
	//the best performance, but i didn't want looking in one direction to be slower so i tried to split it
	//looking up and down are slower, but not as much, because there is often less to see (like a bottom of a hole)
	//also, nobody is going to walk around looking up at the sky. als, the fps drop is by about .3 fps for direction with statics.
	for (unsigned int y=0; y<184;y+=res*2){
		flint tdy = cached_y_dir[y];	
		flint ny;ny=tdy;
		tdy=(cosyz*ny-sinyz);//dz is 1 so don't mult yet
		flint tdz=(sinyz*ny+cosyz);//yz
		deltay= inv_tablel[tdy.data];
		
		flint sinxztdz;sinxztdz.data=(sinxz.data*tdz.data)>>shift_by;
		flint cosxztdz;cosxztdz.data=(cosxz.data*tdz.data)>>shift_by;
		flint *cx = &cache[0];
		flint *cz = &cache[320];
		//dbg_printf("y: %d, addr: %p\n",y, tempval);
		//#pragma clang loop unroll_count(5)
		uint8_t tdy_bit=((tdy.data>0)<<1);
		auto temp=tempval;
		#define NOTHING ;
		// pass A (x = 0,10,..310) runs entirely in asm. It computes dx/dz, deltax/z, tmax, quadrant,
		// sets _DX/_DZ and _dda_deltax/z itself, and advances rectaddr (tempval) by 10 per column.
		row_sin=sinxztdz.data;
		row_cos=cosxztdz.data;
		int tmaxy0=KMUL(deltay.data,KSEL(fry,tdy.data));
		row_tmaxy=tmaxy0;
		row_tdybit=tdy_bit;
		row_w=(int)w;
		col_cx=(int)&cache[0];
		col_cz=(int)&cache[320];
		dda_deltay=deltay.data;
		
		DY=tdy.data;
		raycast_cols_A();
		auto temp2=tempval;                  // = row start + 320 after raycast_cols_A
		tempval=temp+res;
		col_cx=(int)&cache[res];
		col_cz=(int)&cache[320+res];
		raycast_cols_A2();                   // 32 columns, rectaddr += 320
		tempval=temp2;
		tempval+=(320*(res-1))+320*res;
	}
	tempval=&gfx_vbuffer[res][0];	
	for (unsigned int y=res; y<184;y+=res*2){
		flint tdy = cached_y_dir[y];	
		flint ny;ny=tdy;
		tdy=(cosyz*ny-sinyz);//dz is 1 so don't mult yet
		flint tdz=(sinyz*ny+cosyz);//yz
		deltay= inv_tablel[tdy.data];
		//claude look at this v v v is this right? i guessed with this bcs was not compiling
		int tmaxy0=KMUL(deltay.data,KSEL(fry,tdy.data));
		row_tmaxy=tmaxy0;
		flint sinxztdz;sinxztdz.data=(sinxz.data*tdz.data)>>shift_by;
		flint cosxztdz;cosxztdz.data=(cosxz.data*tdz.data)>>shift_by;
		flint *cx = &cache[0];
		flint *cz = &cache[320];
		//dbg_printf("y: %d, addr: %p\n",y, tempval);
		//#pragma clang loop unroll_count(5)
		uint8_t tdy_bit=((tdy.data>0)<<1);

		row_sin=sinxztdz.data;
		row_cos=cosxztdz.data;
		row_tmaxy=tmaxy0;
		row_tdybit=tdy_bit;
		row_w=(int)w;
		col_cx=(int)&cache[0];
		col_cz=(int)&cache[320];
		dda_deltay=deltay.data;
		DY=tdy.data;
		raycast_cols_B();                       // 64 columns, advances rectaddr by 320
		tempval+=(320*(res-1))+320*res;
		
	}

	restore_shadow_bc();
	__asm__ volatile ("ei");

}
void draw_tree(int x, int y, int z)
{
	for(int xo=-2;xo<=2;xo++){// tree leaves are 5 by 5
		for(int zo=-2;zo<=2;zo++){//drawing bottom leaves
			vis_map(x+xo,y+2,z+zo)=LEAF;
		}
	}
	
	for(int xo=-1;xo<=1;xo++){
		for(int zo=-1;zo<=1;zo++){//drawing top leaves
			vis_map(x+xo,y+3,z+zo)=LEAF;
		}
	}
	vis_map(x,y,z)=WOOD;
	vis_map(x,y+1,z)=WOOD;//trunk
	vis_map(x,y+2,z)=WOOD;//more trunk
}
void outline_world_with_barrier()
{
	int x=0;
	for (int y=0; y<WY;y++){
		memset(world+((x) << XWS) + ((y) << YWS),5,WZ);
	}
	
	x=WX-1;
	for (int y=0; y<WY;y++){
		memset(world+((x) << XWS) + ((y) << YWS),5,WZ);
	}
	int z=0;
	for (int x=0;x<WX;x++){
		for (int y=0;y<WY;y++)
			vis_map(x,y,z)=5;
	}/*
	z=WZ-1;
	for (int x=0;x<WX;x++){
		for (int y=0;y<WY;y++)
			vis_map(x,y,z)=5;
	}
	*/
	//good ol under/overflow^^^ 
	int y=0;
	for (int x=0; x<WX;x++)
		memset(world+((x) << XWS) + ((y) << YWS),5,WZ);//roof/floor
}
#define hmap(x,z) hmap[((x) * (WZ + 4)) + (z)]
void generate_terrain(uint8_t surfblock, uint8_t underblock,uint8_t bottom,uint8_t top,uint8_t range)
{
	//hmap is grass terrain height. grass from y level 8 to 14.
	uint8_t kernel[5][5] = {//gausian stuff
    {1,  4,  7,  4, 1},
    {4, 16, 26, 16, 4},
    {7, 26, 41, 26, 7},
    {4, 16, 26, 16, 4},
    {1,  4,  7,  4, 1}
	};
	/**#define kernel_sum 273**/
	//uint8_t* hmap= (uint8_t*)malloc((WX+4)*(WZ+4));
	uint8_t *hmap = (uint8_t*)gfx_vbuffer;//this is screen's ram back buffer. nothing should appear.
	int tmr=top-range;
	for (uint8_t x=0;x<WX+4;x++){
		for (uint8_t z=0;z<WZ+4;z++){// filling array with random values.
			hmap(x,z)=randInt(tmr,top);
		}
	}
	//now time to blur.
	for (uint8_t x=0;x<WX;x++){
		for (uint8_t z=0;z<WZ;z++){
			int total=0;
			for (int xo=0;xo<5;xo++){
				for (int zo=0;zo<5;zo++){// would say -2 but have to +2 anyways so 0
					total+=kernel[xo][zo]*hmap(x+xo,z+zo);
				}
			}
			//newhmap[x][z]=total/kernel_sum;
			//273 is kernel sum. magic numbers!
			
			vis_map(x,(uint8_t) ((total* 241) >> 16),z)=surfblock;
		}
	}
	//now time to fill in under grass
	for (uint8_t x=0;x<WX;x++){
		for (uint8_t z=0;z<WZ;z++){
			int yflag=0;
			for (int8_t y=top;y>=bottom;y--)
			{
				if(yflag==0)
				{
					if (vis_map(x,y,z)==surfblock)
						yflag=1;
				}
				else
				{
					vis_map(x,y,z)=surfblock;
					yflag++;				
				}
				if(yflag>4)
					vis_map(x,y,z)=underblock;//stone
			}
		}
	}
}
uint8_t biome=0;
void spawn_random_cluster(uint8_t block,uint8_t x,uint8_t y,uint8_t z,uint8_t minsize,uint8_t maxsize)
{
	uint8_t xlen=randInt(minsize,maxsize);
	uint8_t ylen=randInt(minsize,maxsize);
	uint8_t zlen=randInt(minsize,maxsize);
	
	for(int xo=0;xo<xlen;++xo)
	{
		for(int yo=0;yo<ylen;++yo)
		{
			for(int zo=0;zo<zlen;++zo)
			{
				if(x+xlen>WX) xlen=WX-x;
				if(y+ylen>WY) ylen=WY-y;
				if(z+zlen>WZ) zlen=WZ-z;
				vis_map(x+xo,y+yo,z+zo)=block;
			}
		}
	}
}
void generate_world_underground()
{
	
	// now time to add some minerals!
	for (int i=0; i<IRONNUM;++i)
	{
		uint8_t x=randInt(0,WX-1);
		uint8_t y=randInt(4,12);
		uint8_t z=randInt(0,WZ-1);
		spawn_random_cluster(IRON,x,y,z,1,3);
	}
	for (int i=0; i<GOLDNUM;++i)
	{
		uint8_t x=randInt(0,WX-1);
		uint8_t y=randInt(2,10);
		uint8_t z=randInt(0,WZ-1);
		spawn_random_cluster(GOLD,x,y,z,1,3);
	}
	for (int i=0; i<DIAMONDNUM;++i)
	{
		uint8_t x=randInt(0,WX-1);
		uint8_t y=randInt(1,5);
		uint8_t z=randInt(0,WZ-1);
		spawn_random_cluster(DIAMOND,x,y,z,1,2);
	}
	for (int i=0; i<REDSTONENUM;++i)
	{
		uint8_t x=randInt(0,WX-1);
		uint8_t y=randInt(1,7);
		uint8_t z=randInt(0,WZ-1);
		spawn_random_cluster(REDSTONE,x,y,z,1,3);
	}
	for (int i=0; i<COALNUM;++i)
	{
		uint8_t x=randInt(0,WX-1);
		uint8_t y=randInt(6,17);
		uint8_t z=randInt(0,WZ-1);
		spawn_random_cluster(COAL,x,y,z,2,3);
	}
	for(int i=0; i<OBSIDIANNUM;++i)
	{
		uint8_t x=randInt(0,WX-1);
		uint8_t y=randInt(1,3);
		uint8_t z=randInt(0,WZ-1);
		spawn_random_cluster(OBSIDIAN,x,y,z,1,2);
	}
	for (int i=0; i<GRAVELNUM;++i)
	{
		uint8_t x=randInt(0,WX-4);
		uint8_t y=randInt(4,17);
		uint8_t z=randInt(0,WZ-4);
		spawn_random_cluster(GRAVEL,x,y,z,2,4);
	}
	
	
	//now time for.... tunnels!

	for (int i=0; i<TUNNELNUM;++i)
	{
		next:
		if(i>TUNNELNUM)
			break;
		flint tx=(int)randInt(0,WX-1);
		flint ty=(int)randInt(4,12);
		flint tz=(int)randInt(0,WZ-1);
		int ay=(int)randInt(0,63);//direction forward
		int az=(int)randInt(-5,5);//direction up
		az=(64+az)&63;//mod 64
		//angle->vector2d is (x*cos(angle),y*sin(angle))
		
		//3d (where have angles y and z) is x=cos(y)*cos(z),   y=sin(z),    z=sin(y)*cos(z)
		// y angle is xz, z angle is xy
		
		flint p5=.5f;
		int ix=tx;//+p5;
		int iy=ty;//+p5;
		int iz=tz;//+p5;
		int length=0;
		//dbg_printf("ntunnel,%d   %d,%d,%d\n",i,ix,iy,iz);
		while(length<40)//vis_map(ix,iy,iz)!=0||
		{
			length++;
			//getting vectors...
			
			flint vx = cached_cos_rot[ay] * cached_cos_rot[az];
			flint vy = cached_sin_rot[az];
			flint vz = cached_sin_rot[ay] * cached_cos_rot[az];
			/*
			flint vx=cached_cos_rot[ay];
			flint vy=0;
			flint vz=cached_sin_rot[az];
			*/
			//adding vectors...
			tx+=vx;
			ty+=vy;
			tz+=vz;
			
			//now rounding coords...
			ix=(int)(tx+p5);
			iy=(int)(ty+p5);
			iz=(int)(tz+p5);
			
			//vis_map(ix,iy,iz)=255;
			for (int px=-1; px<2; ++px)
			{
				for(int py=-1; py<2;++py){
					for(int pz=-1;pz<2;++pz)
					{
						unsigned int ox=ix+px;//+randInt(-1,1);
						unsigned int oy=iy+py;//+randInt(-1,1);
						unsigned int oz=iz+pz;//+randInt(-1,1);
						if(ox>WX-1||oy>WY-1||oz>WZ-1)
						{
							i++;
							goto next;
						}
						vis_map(ox,oy,oz)=0;//255;
						if(!randInt(0,40*(1<<MOVESHIFT)))
						{
							vis_map(ox,oy,oz)=WATERBLOCK;
							add_update(&vis_map(ox,oy,oz));
						}
					}
				}
			}
			
			//now time to wobble the tunnel!
			ay+=randInt(-TUNNELWOBBLEF,TUNNELWOBBLEF);
			az+=randInt(-TUNNELWOBBLEU,TUNNELWOBBLEU);//how wiggly/wobbley the tunnels are
			ay&=63;
			az=az&63;
			if(az<0)
				az=0;
			if(az>5&&az<30)
				az=5;
			if(az>30&&az<59)
				az=59;
			
		}
	}
	/*
	for (int b=0; b<WX*WY*WZ; ++b)
	{
		if(world[b]==255)
			world[b]=0;
	}
	*/
}
void generate_trees(int numtrees)
{
	for (uint8_t i=0;i<numtrees;i++){
		uint8_t x=randInt(3,WX-3);// don't want tree too close to edge of map...
		uint8_t z=randInt(3,WZ-3);
		int8_t y;
		for (y=WY-1;y>=0;y--){
			if (vis_map(x,y,z)&&vis_map(x,y,z)!=LEAF&&vis_map(x,y,z)!=WOOD)
				break;
		}
		y++;//brings from grass to space above grass
		if (y<WY-4){//if enough space to draw tree
			//draw tree!
			draw_tree(x,y,z);
			
		}
	}
}
void generate_cacti(int numcacti)
{
	for(int i=0; i<numcacti;++i)
	{
		uint8_t x=randInt(1,WX-1);
		uint8_t z=randInt(1,WZ-1);
		int8_t y;
		for (y=WY-1;y>=0;y--){
			if (vis_map(x,y,z)==SAND)
				break;
		}
		vis_map(x,y+1,z)=CACTUS;
		vis_map(x,y+2,z)=CACTUS;
		vis_map(x,y+3,z)=CACTUS;
	}
}
void draw_house(int hx, int y, int hz)
{
	//draws house from bottom left corner
	
	//drawing floor and roof...
	for(int x=hx;x<hx+6;++x)
	{
		for(int z=hz;z<hz+6;++z)
		{
			vis_map(x,y,z)=PLANKS;
			vis_map(x,y+4,z)=PLANKS;
		}
	}
	//drawing x walls...
	for(int x=hx;x<hx+6;++x)
	{
			vis_map(x,y+1,hz)=PLANKS;
			vis_map(x,y+2,hz)=PLANKS;
			vis_map(x,y+3,hz)=PLANKS;
			
			vis_map(x,y+1,hz+5)=PLANKS;
			vis_map(x,y+2,hz+5)=PLANKS;
			vis_map(x,y+3,hz+5)=PLANKS;
	}
	//drawing z walls...
	for(int z=hz;z<hz+6;++z)
	{
			vis_map(hx,y+1,z)=PLANKS;
			vis_map(hx,y+2,z)=PLANKS;
			vis_map(hx,y+3,z)=PLANKS;
			
			vis_map(hx+5,y+1,z)=PLANKS;
			vis_map(hx+5,y+2,z)=PLANKS;
			vis_map(hx+5,y+3,z)=PLANKS;
	}
	vis_map(hx+2,y+1,hz)=DOORBOTTOMOPEN;
	vis_map(hx+2,y+2,hz)=DOORTOPOPEN;
}
void generate_nether();
void generate_world(){
	/** generates the world (from a seed you set before calling. first, generates a heightmap (hmap) full of random values.
	Then, 5x5 gaussian blurs it to look more natural. I ain't doing no perlin noise with this calculator! 
	
	Then, it puts the heightmap on to the world array (puts a grass block at the world index [x][hmap[x][z]][z].
	
	Puts grass at each height on the hmap in world. Then, puts 3 grass blocks under each grass block, then fills with stone till bottom.
	
	Then, makes some trees (picks random block that isn't too high and then plops a tree on it)
	
	Then, puts random ore/minerals randomly in random locations based on y level. Like diamonds close to bottom and iron higher up.
	
	Then makes some tunnels in the ground. (or caves, whatever you prefer). Basically, picks random coords then picks random 
	z and y angles then trots off in that direction destroying blocks, with each step adding a new random value to the angle (within bounds for y
	to avoid loop de loops) so the tunnels look more wobbley (through the macros TUNNELWOBBLEF and TUNNELWOBBLEU, which control the wobbleyness).
	
	Then, surrounds the world in barrier blocks (the same color as bg color so can't really tell).
	Overflow/underflow means i don't actually have to fill in everything (because my array is flattened)**/
	memset(world,0,WX*WY*WZ);
	
	if(realm==1)//if is nether
	{
		generate_nether();//generate nether
		return;//and skip generating normal world
	}
	
	
	//realm==0:
	
	biome=randInt(0,4);//0 is grassland, 1 is snowy grassland 2 is desert,3 is forest 4 is snowy forest
	//now time to add random parts of snow for snow biome
	
	
	

	switch(biome)
	{
		case 0://grassland
			generate_terrain(GRASS,STONE,0,26,6);
			generate_trees(3);
			break;
		case 1://snowy grassland
			generate_terrain(SNOWGRASS,STONE,0,26,6);
			generate_trees(3);
			break;
		case 2://desert
			generate_terrain(SAND,SANDSTONE,0,26,6);
			generate_cacti(15);
			break;
		case 3://forest
			generate_terrain(GRASS,STONE,0,26,6);
			generate_trees(30);
			break;
		case 4:
			generate_terrain(SNOWGRASS,STONE,0,26,6);
			generate_trees(30);
			break;
	}
	if(biome==1||biome==4)
	{
		for (int i=0; i<15;++i)
		{
			uint8_t xs=randInt(3,WX-4);
			uint8_t zs=randInt(3,WZ-4);
			uint8_t temp=xs+randInt(1,3);
			for (uint8_t x=xs-randInt(1,3);x<temp;++x)
			{
				uint8_t temp2=zs+randInt(1,3);
				for (uint8_t z=zs-randInt(1,3);z<temp2;++z)
				{
					for(int8_t y=WY;y>=0;y--)
					{
						if(vis_map(x,y,z)==SNOWGRASS)
						{
							vis_map(x,y,z)=SNOW;
							break;
						}
					}
				}
			}
		}
	}
	generate_world_underground();
	outline_world_with_barrier();
	
}
void spawn_fire()
{
	for(int x=0; x<WX;++x)
	{
		for(int z=0; z<WZ;++z)
		{
			for (int y=28;y>0; --y)
			{
				if(vis_map(x,y,z))
				{
					if(randInt(0,64)==0)
						vis_map(x,y+1,z)=FIRE;
					break;
				}
			}
		}
	}
}
void generate_nether()
{
	/*Chicken jockeeyyy, the Nethaa, flint and steel enderpearrrlll*/
	/** plan for nether: 2 hmaps. One for top nether, one for bottom. just to be a pain.
	floor should be 4 netherack, roof should be 4. that leaves 28 for world. 14 for each half. with guasian, 
	will have hmap vary between 10 and 14. Then will apply bitmap of whether there should be a hole. 
	**/
	for(int x=0; x<WX;++x)
	{
		for(int z=0; z<WZ;++z)
		{
			vis_map(x,0,z)=MAGMABLOCK;
			vis_map(x,1,z)=MAGMABLOCK;//no lava but there are magmablocks!
			
			vis_map(x,31,z)=NETHERRACK;
			vis_map(x,30,z)=NETHERRACK;//nether roof
			vis_map(x,29,z)=NETHERRACK;
		}
	}
	generate_terrain(NETHERRACK,NETHERRACK,6,21,10);//lower section
	
	spawn_fire();
	generate_terrain(NETHERRACK,NETHERRACK,20,25,2);
	spawn_fire();
	for(int j=0; j<2;++j)
	{
		for(int i=0; i<NETHERGOLDORENUM;++i)
		{
			uint8_t x=randInt(1,WX-2);
			uint8_t y;
			if(j==0) y=randInt(6,21);
			else y=randInt(20,25);
			uint8_t z=randInt(1,WZ-2);
			if(vis_map(x,y,z))
			{
				vis_map(x,y,z)=NETHERGOLDORE;

				if(vis_map(x+1,y,z))
					vis_map(x+1,y,z)=NETHERGOLDORE;
				if(vis_map(x-1,y,z))
					vis_map(x-1,y,z)=NETHERGOLDORE;

				if(vis_map(x,y+1,z))
					vis_map(x,y+1,z)=NETHERGOLDORE;
				if(vis_map(x,y-1,z))
					vis_map(x,y-1,z)=NETHERGOLDORE;

				if(vis_map(x,y,z+1))
					vis_map(x,y,z+1)=NETHERGOLDORE;
				if(vis_map(x,y,z-1))
					vis_map(x,y,z-1)=NETHERGOLDORE;
			}
		}
		outline_world_with_barrier();
	}
}
	
/*
#define hmap(x,z) hmap[((x) * (16 + 4)) + (z)]
#define cx 16
#define cy 16
#define cz 16
#define chunk_map(x,y,z) chunk[((x)<<8)+((y)<<4)+(z)]
//chunk dimensions ^ ^ ^
void generate_chunk(uint8_t* chunk,int thischunkx,int thischunkz){*/
	/** generates the chunk (from a seed you set before calling. first, generates a heightmap (hmap) full of random values.
	Then, 5x5 gaussian blurs it to look more natural. I ain't doing no perlin noise with this calculator! 
	
	Then, it puts the heightmap on to the chunk array (puts a grass block at the chunk index [x][hmap[x][z]][z].
	
	Puts grass at each height on the hmap in chunk. Then, puts 3 grass blocks under each grass block, then fills with stone till bottom.
	
	Then, makes some trees (picks random block that isn't too high and then plops a tree on it)
	
	Then, puts random ore/minerals randomly in random locations based on y level. Like diamonds close to bottom and iron higher up.
	
	Then makes some tunnels in the ground. (or caves, whatever you prefer). Basically, picks random coords then picks random 
	z and y angles then trots off in that direction destroying blocks, with each step adding a new random value to the angle (within bounds for y
	to avoid loop de loops) so the tunnels look more wobbley (through the macros TUNNELWOBBLEF and TUNNELWOBBLEU, which control the wobbleyness).
	
	Then, surrounds the chunk in barrier blocks (the same color as bg color so can't really tell).
	Overflow/underflow means i don't actually have to fill in everything (because my array is flattened)**/
	/*
	//generating chunk seed...
	wseed+=thischunkx+(thischunkz<<16);//world can't be more than 65535x65535 blocks with this setup,
	//but already the limit is in the integer max value for saving (caps at 512x128x512 max blocks for int24)
	srand(wseed);//sets the seed
	//hmap is grass terrain height. grass from y level 8 to 14.
	int kernel[5][5] = {//gausian stuff
    {1,  4,  7,  4, 1},
    {4, 16, 26, 16, 4},
    {7, 26, 41, 26, 7},
    {4, 16, 26, 16, 4},
    {1,  4,  7,  4, 1}
	};
	int kernel_sum = 273;
	//uint8_t* hmap= (uint8_t*)malloc((cx+4)*(cz+4));
	uint16_t *hmap = (uint16_t*)gfx_vbuffer;//this is screen's ram. some noise will appear, but not too much

	for (int x=0;x<cx+4;x++){
		for (int z=0;z<cz+4;z++){// filling array with random values.
			hmap(x,z)=randInt(8,14);
		}
	}
	//now time to blur.
	for (int x=0;x<cx;x++){
		for (int z=0;z<cz;z++){
			int total=0;
			for (int xo=0;xo<5;xo++){
				for (int zo=0;zo<5;zo++){// would say -2 but have to +2 anyways so 0
					total+=kernel[xo][zo]*hmap(x+xo,z+zo);
				}
			}
			//newhmap[x][z]=total/kernel_sum;
			chunk_map(x,total/kernel_sum,z)=1;
		}
	}
	//now time to fill in under grass
	for (int x=0;x<cx;x++){
		for (int z=0;z<cz;z++){
			int yflag=0;
			for (int y=cy-1;y>=0;y--)
			{
				if (chunk_map(x,y,z)==1&&yflag==0)
					yflag=1;
				if(yflag>0){
					chunk_map(x,y,z)=1;//grass
					yflag++;
				}
				if(yflag>3)
					chunk_map(x,y,z)=2;//stone
			}
		}
	}
	//now time to add random parts of sand!
	for (int i=0; i<SANDNUM;++i)
	{
		int xs=randInt(3,cx-4);
		int zs=randInt(3,cz-4);
		int temp=xs+randInt(1,3);
		for (int x=xs-randInt(1,3);x<temp;++x)
		{
			int temp2=zs+randInt(1,3);
			for (int z=zs-randInt(1,3);z<temp2;++z)
			{
				for(int y=15;y>=0;y--)
				{
					if(chunk_map(x,y,z)==GRASS)
					{
						chunk_map(x,y,z)=SAND;
						break;
					}
				}
			}
		}
	}
	//now time to add trees!
	for (int i=0;i<TREENUM;i++){
		int x=randInt(3,cx-3);// don't want tree too close to edge of map...
		int z=randInt(3,cz-3);
		int y;
		for (y=cy-1;y>=0;y--){
			if (chunk_map(x,y,z)==1)
				break;
		}
		y++;//brings from grass to space above grass
		if (y<12){//if enough space to draw tree
			//draw tree!
			chunk_map(x,y,z)=WOOD;
			chunk_map(x,y+1,z)=WOOD;//trunk
			for(int xo=-2;xo<=2;xo++){// tree leaves are 5 by 5
				for(int zo=-2;zo<=2;zo++){//drawing bottom leaves
					chunk_map(x+xo,y+2,z+zo)=LEAF;
				}
			}
			
			for(int xo=-1;xo<=1;xo++){
				for(int zo=-1;zo<=1;zo++){//drawing top leaves
					chunk_map(x+xo,y+3,z+zo)=LEAF;
				}
			}
			chunk_map(x,y+2,z)=WOOD;//more trunk
			
		}
	}
	// now time to add some minerals!
	for (int i=0; i<IRONNUM;++i)
	{
		int x=randInt(0,cx-1);
		int y=randInt(2,6);
		int z=randInt(0,cz-1);
		chunk_map(x,y,z)=IRON;
	}
	for (int i=0; i<GOLDNUM;++i)
	{
		int x=randInt(0,cx-1);
		int y=randInt(1,5);
		int z=randInt(0,cz-1);
		chunk_map(x,y,z)=GOLD;
	}
	for (int i=0; i<DIAMONDNUM;++i)
	{
		int x=randInt(0,cx-1);
		int y=randInt(0,3);
		int z=randInt(0,cz-1);
		chunk_map(x,y,z)=DIAMOND;
	}
	//now time for.... tunnels!

	for (int i=0; i<TUNNELNUM;++i)
	{
		next:
		if(i>TUNNELNUM)
			break;
		flint tx=(int)randInt(0,cx-1);
		flint ty=(int)randInt(2,6);
		flint tz=(int)randInt(0,cz-1);
		int ay=(int)randInt(0,63);//direction forward
		int az=(int)randInt(-5,5);//direction up
		az=(64+az)%64;
		//angle->vector2d is (x*cos(angle),y*sin(angle))
		
		//3d (where have angles y and z) is x=cos(y)*cos(z),   y=sin(z),    z=sin(y)*cos(z)
		// y angle is xz, z angle is xy
		
		flint p5=.5f;
		int ix=tx+p5;
		int iy=ty+p5;
		int iz=tz+p5;
		int length=0;
		//dbg_printf("ntunnel,%d   %d,%d,%d\n",i,ix,iy,iz);
		while(length<40)//chunk_map(ix,iy,iz)!=0||
		{
			length++;
			//getting vectors...
			
			flint vx = cached_cos_rot[ay] * cached_cos_rot[az];
			flint vy = cached_sin_rot[az];
			flint vz = cached_sin_rot[ay] * cached_cos_rot[az];

			//adding vectors...
			tx+=vx;
			ty+=vy;
			tz+=vz;
			
			//now rounding coords...
			ix=(int)(tx+p5);
			iy=(int)(ty+p5);
			iz=(int)(tz+p5);
			
			//chunk_map(ix,iy,iz)=255;
			for (int px=-1; px<2; ++px)
			{
				for(int py=-1; py<2;++py){
					for(int pz=-1;pz<2;++pz)
					{
						unsigned int ox=ix+px;//+randInt(-1,1);
						unsigned int oy=iy+py;//+randInt(-1,1);
						unsigned int oz=iz+pz;//+randInt(-1,1);
						if(ox>=cx||oy>=cy||oz>=cz)
						{
							i++;
							goto next;
						}
						chunk_map(ox,oy,oz)=255;
					}
				}
			}
			
			//now time to wobble the tunnel!
			ay+=randInt(-TUNNELWOBBLEF,TUNNELWOBBLEF);
			az+=randInt(-TUNNELWOBBLEU,TUNNELWOBBLEU);//how wiggly/wobbley the tunnels are
			if(ay<0)
				ay=64-az;
			if(ay>63)
				ay=63;
			az=az%64;
			if(az<0)
				az=0;
			if(az>5&&az<30)
				az=5;
			if(az>30&&az<59)
				az=59;
			
		}
	}
	for (int b=0; b<cx*cy*cz; ++b)
	{
		if(chunk[b]==255)
			chunk[b]=0;
	}
	//now time to add the border!
	//border is 5
	
	
	gfx_FillScreen(bg_color);
}
*/
void decrease_item(int id)
{
	if(inventory[id]>0)
	{
		inventory[id]--;
		if(inventory[id]==0)
		{
			for (int i=0;i<8;++i)
			{
				if(ghotbar[i]==id)
				{
					ghotbar[i]=0;
					break;
				}
			}
		}
	}
	
}
void use_rawmutton()
{
	playerhunger+=2;
	if(playerhunger>20)
		playerhunger=20;
	decrease_item(RAWMUTTON);
	
}
void use_cookedmutton()
{
	playerhunger+=8;
	if(playerhunger>20)
		playerhunger=20;
	decrease_item(COOKEDMUTTON);
}
void use_rawpork()
{
	playerhunger+=3;
	if(playerhunger>20)
		playerhunger=20;
	decrease_item(RAWPORKCHOP);
	
}
void use_cookedpork()
{
	playerhunger+=6;
	if(playerhunger>20)
		playerhunger=20;
	decrease_item(COOKEDPORKCHOP);
}
void use_rottenflesh()
{
	playerhunger+=3;
	if(playerhunger>20)
		playerhunger=20;
	decrease_item(ROTTENFLESH);
}
bool try_light_portal(uint8_t bx, uint8_t by, uint8_t bz);
void spawn_nether_portal(uint8_t x,uint8_t& y,uint8_t z);
void light_fire()
{
	keyup(kb_KeyStat);//just so don't make tons of fires
	uint8_t* block;
	uint8_t* temp=cross_hair_pt(block);
	if(temp!=NULL)
	{
		if(*temp==OBSIDIAN)
		{
			int nblock = temp - world;
			uint8_t z = nblock & (WZ-1);
			nblock >>= YWS;
			uint8_t y = nblock & (WY-1);
			nblock >>= YWS;
			uint8_t x = nblock;
			if(try_light_portal(x,y,z))
				return;
		}
		if(*temp!=TNT)
		{
			*block=FIRE;
			add_updates_fully(block);
		}
		else
			use_tnt(temp);
	}
}
void use_bucket()
{
	uint8_t* block;
	uint8_t* temp=cross_hair_pt(block,1);//turning on include water as block so we can interact with it
	if(temp!=NULL)
	{
		if(*temp==WATERBLOCK)
		{
			*temp=0;
			add_updates_fully(temp);
			decrease_item(BUCKET);
			inventory[WATERBUCKET]++;
			add2hotbar(WATERBUCKET);
		}
	}
}
void use_waterbucket()
{
	uint8_t* block;
	uint8_t* temp=cross_hair_pt(block);
	if(temp!=NULL)
	{
		if(*block==0)//don't need to include other ids bcs include water is off by default
		{
			*block=WATERBLOCK;
			add_updates_fully(block);
			decrease_item(WATERBUCKET);
			inventory[BUCKET]++;
			add2hotbar(BUCKET);
		}
	}
}
gfx_sprite_t ** item_imgs;//            ={woodpic,stonepic,goldpic,ironpic,diamondpic,/*netheritepic*/NULL,stick,woodsword,stonesword,goldsword,ironsword,diamondsword,ironingot,goldingot,rawmutton,    cookedmutton,    rottenflesh, diamond, coal, flint and steel}, flint,bucket, waterbcket;              rawpork,    cooked pork
static void (*use_item[])(       ){      NULL,    NULL,  NULL,   NULL,     NULL,            NULL,        NULL, NULL,       NULL,      NULL,   NULL,       NULL,       NULL,       NULL, use_rawmutton,use_cookedmutton,use_rottenflesh, NULL ,NULL, light_fire,        NULL,   use_bucket,  use_waterbucket, use_rawpork,use_cookedpork};
//                                  crafting table   furnace    planks   bed top glass   doortop   doorbottom magmablock  fire cacti, sandstone    irndmrdgldcl  tnt, tntlit, smoke gravel nthrprtl nthrgld
const static uint8_t recog_text_side[]={1,            2,         2,        1,    0,       2        ,0,0,0,         1,     0,    0,           0,     0,0,0,0, 0,   0,    0,      0,   0 ,    0,    0};
//const static uint8_t unmirror[]={3,2,1,0,7,6,5,4};
// this is based off of an array that goes {0,1,2,3,4,5,6,7,8} and shows what the mirroring does (used in unmirroring for draw_item
//because i mirrored all my textures so they don't look mirrored in the game.

// what side of the texture is most recognizable for the item label
extern "C" void Sprite_8x8to32x32(uint8_t* sprite, uint8_t* screenstart);
extern "C" void Sprite_16x16to32x32(uint8_t* sprite, uint8_t* screenstart);
inline void draw_item(int temp,int x,int y,int show_num)
{
	switch(temp)
	{
		case REDSTONEDUSTUNLIT:
			gfx_Sprite_NoClip(redstonedust,x,y);
			break;
			
		default:
			if(temp<reg_block_num+1)//solid block, 16x16-cached icon
			{
				Sprite_16x16to32x32(&blockspritebuffer[temp<<8],&gfx_vbuffer[y][x]);
			}
			else if(temp<=FLOORVOXELSEND)//floor block, flat diamond icon
			{
				gfx_SetColor(floorcolors[temp]);
				gfx_FillTriangle(x+7,y+7,x+2,y+28,x+28,y+7);
				gfx_FillTriangle(x+2,y+28,x+28,y+28,x+28,y+7);
			}
			else if(temp<invenblocknum+1)//textured block, 8x8-cached icon
			{
				Sprite_8x8to32x32(&texturespritebuffer[(temp-CRAFTTABLE)<<6],&gfx_vbuffer[y][x]);
			}
			else//if item
			{
				//dbg_printf("item! %d",temp);
				gfx_Sprite_NoClip(item_imgs[temp-invenblocknum-1], x, y);
			}
	}
	if (show_num&&inventory[temp]>0)
	{
		//gfx_SetColor(255); 
		gfx_SetTextXY(x+20, y+20);
		gfx_PrintInt(inventory[temp],0);
	}	
	
}


inline void draw_itemnobuffer(int temp,int x,int y)
{
	//draws the item (like what you see in the hotbar or inventory or such)

	if(temp<reg_block_num+1)//if block
	{
		/*
		gfx_SetColor(block_colors_y[temp]);
		gfx_FillRectangle_NoClip(x,y,30,30);
		*/
		gfx_SetColor(0);
		gfx_FillRectangle_NoClip(x,y,30,30);
		gfx_SetColor(colors[temp]);
		gfx_FillTriangle(x+2,y+6, x+15,y+13, x+15,y+28);
		gfx_FillTriangle(x+2,y+23, x+2,y+6, x+15,y+28);
		
		gfx_SetColor(colors[temp+(reg_block_num+1)]);
		gfx_FillTriangle(x+2,y+6, x+15,y+2, x+15,y+13);
		gfx_FillTriangle(x+28,y+6, x+15,y+2, x+15,y+13);
		
		gfx_SetColor(colors[temp+2*(reg_block_num+1)]);
		gfx_FillTriangle(x+15,y+13, x+15,y+28, x+28,y+23);
		gfx_FillTriangle(x+15,y+13, x+28,y+6, x+28,y+23);
		

	}
	
	else if(temp<=FLOORVOXELSEND)//floor block, flat diamond icon
	{
		gfx_SetColor(floorcolors[temp]);
		gfx_FillTriangle(x+7,y+7,x+2,y+28,x+28,y+7);
		gfx_FillTriangle(x+2,y+28,x+28,y+28,x+28,y+7);
	}
	else if(temp<invenblocknum+1)
	
	{
		//dbg_printf("drawing: %d",temp);
		int ptemp=temp;
		int texidx=temp-CRAFTTABLE;          // 0-based texture index for recog_text_side[]
		int side=recog_text_side[texidx];    //side
		int id=((temp-(reg_block_num+1))<<2)+side;   // texturedata[] is anchored at id16 (floor rows included)
		//dbg_printf("id : %d, temp: %d, side:%d\n",id,temp,side);
		for(int x2=0; x2<8;++x2)
		{
			for(int y2=0;y2<8;++y2)
			{
				int color=texturedata[id][x2+(y2<<3)];
				if (color!=26){
					gfx_SetColor(color);
					gfx_FillRectangle_NoClip((x2<<2)+x, y+((7-y2)<<2), 4, 4);
				}
			}
		}
		temp=ptemp;
		
	}
	else//if item
	{
		//dbg_printf("item! %d",temp);
		gfx_Sprite_NoClip(item_imgs[temp-invenblocknum-1], x, y);
	}
}
//all the recipies you can make in a crafting table
int recipies[RECIPIENUM][3][3]={
	    { //planks
        {WOOD,0,0},
        {0,0,0},
        {0,0,0}
    },
    { //stick
        {PLANKS,0,0},
        {PLANKS,0,0},
        {0,0,0}
    },
	{ //wooden picaxe
        {PLANKS,PLANKS,PLANKS},
        {0,		STICK,0},
        {0,		STICK,0}
    },
	{ //stone pic
        {STONE,STONE,STONE},
        {0,		STICK,0},
        {0,		STICK,0}
    },
	{ //iron pic
        {IRONINGOT,IRONINGOT,IRONINGOT},
        {0,	STICK,0},
        {0,	STICK,0}
    },
	{ //diamond pic
        {DIAMONDITEM,DIAMONDITEM,DIAMONDITEM},
        {0,	STICK,0},
        {0,	STICK,0}
    },
	{ //wood sword
        {0,PLANKS,0},
        {0,	PLANKS,0},
        {0,	STICK,0}
    },
	{ //stone sword
        {0,STONE,0},
        {0,	STONE,0},
        {0,	STICK,0}
    },
	{ //iron sword
        {0,IRONINGOT,0},
        {0,	IRONINGOT,0},
        {0,	STICK,0}
    },
	{ //diamond sword
        {0,DIAMONDITEM,0},
        {0,	DIAMONDITEM,0},
        {0,	STICK,0}
    },
	{ //crafting table
        {PLANKS,PLANKS,0},
        {PLANKS,PLANKS,0},
        {0,	0,0}
    },
	{ //door
        {PLANKS,PLANKS,0},
        {PLANKS,PLANKS,0},
        {PLANKS,PLANKS,0}
    },
	{//furnace
		{STONE,STONE,STONE},
        {STONE,  0  ,STONE},
        {STONE,STONE,STONE}
	},
	{ //bed 
        {WOOL,WOOL,WOOL},
        {PLANKS,PLANKS,PLANKS},
        {0     ,0,     0}
    },
	{//gold pickaxe
        {GOLDINGOT,GOLDINGOT,GOLDINGOT},
        {0        ,STICK    ,0},
        {0        ,STICK,    0}
    },
	{
		//gold sword
        {0,GOLDINGOT,0},
        {0,GOLDINGOT,0},
        {0   ,STICK, 0}
    },
	{
		//flint and steel
        {IRONINGOT, 0, 0},
        {0, FLINT, 0},
        {0, 0, 0}
    },
	{
		//tnt (temporary until add gunpowder)
       {COALITEM, SAND, COALITEM},
       {SAND, COALITEM, SAND},
       {COALITEM, SAND, COALITEM}
    },
	{
		//bucket
		{IRONINGOT, 0, IRONINGOT},
		{0, IRONINGOT, 0},
		{0, 0, 0}
	},
	{
		//ironblock
		{IRONINGOT, IRONINGOT, IRONINGOT},
		{IRONINGOT, IRONINGOT, IRONINGOT},
		{IRONINGOT, IRONINGOT, IRONINGOT},
	},
	{
		//goldblock
		{GOLDINGOT, GOLDINGOT, GOLDINGOT},
		{GOLDINGOT, GOLDINGOT, GOLDINGOT},
		{GOLDINGOT, GOLDINGOT, GOLDINGOT},
	},
	{
		//diamond block
		{DIAMONDITEM, DIAMONDITEM, DIAMONDITEM},
		{DIAMONDITEM, DIAMONDITEM, DIAMONDITEM},
		{DIAMONDITEM, DIAMONDITEM, DIAMONDITEM},
	},
	{//redstone block
		{REDSTONEDUSTUNLIT, REDSTONEDUSTUNLIT, REDSTONEDUSTUNLIT},
		{REDSTONEDUSTUNLIT, REDSTONEDUSTUNLIT, REDSTONEDUSTUNLIT},
		{REDSTONEDUSTUNLIT, REDSTONEDUSTUNLIT, REDSTONEDUSTUNLIT},
	},
	{
		//ironingot
		{0, 0,0},
		{0, IRONBLOCK, 0},
		{0, 0, 0}
	},
	{
		//goldingot
		{0, 0,0},
		{0, GOLDBLOCK, 0},
		{0, 0, 0}
	},
	{
		//diamonditem
		{0, 0,0},
		{0, DIAMONDBLOCK, 0},
		{0, 0, 0}
	},
	{
		//redstoneitem
		{0, 0,0},
		{0, REDSTONEBLOCK, 0},
		{0, 0, 0}
	},
};// index of the recipie to id
int recipie_to_id_array[RECIPIENUM]=   {PLANKS,STICK,WOODPIC,STONEPIC,IRONPIC,DIAMONDPIC,WOODSWORD,STONESWORD,IRONSWORD,DIAMONDSWORD, CRAFTTABLE, DOORTOPOPEN,FURNACE,BEDTOP,GOLDPIC, GOLDSWORD,FLINTANDSTEEL, TNT,BUCKET, IRONBLOCK, GOLDBLOCK, DIAMONDBLOCK, REDSTONEBLOCK,IRONINGOT, GOLDINGOT, DIAMONDITEM, REDSTONEDUSTUNLIT};
int num_items_from_recipie[RECIPIENUM]={4,       4      ,1,      1,      1,       1,          1,        1,        1,       1,               1,          3,       1,      1,    1,        1,            1,       1,  1,        1,         1,           1,           1,           9,        9,           9,         9,};
// this ^ ^ ^ is how much of the item you get when you craft it.
inline int recipie_to_id(int craftingtable[3][3][2], int &num)
{
	/**you give it a recipie and it sees if it can craft it. used in crafting screen**/
	for(int i=0; i<RECIPIENUM;++i)
	{
		int flag=1;
		for(int x=0; x<3;++x)
		{
			for(int y=0;y<3;++y)
			{
				if(craftingtable[x][y][0]!=recipies[i][y][x]){// long story short all were sideways
					flag=0;//if crafting table item is not in the recipie in right spot, not craftable
				}
			}
		}
		if(flag){//if craftable
			
			int id =recipie_to_id_array[i];
			num=num_items_from_recipie[i];
			return id;
		}
	}
	return -1;
}
char* int_to_chr(int x, int min)
{
	/**int ->string (or really char*). probs should have named int_to_string but too late now!**/
	 char* buffer = new char[min];
	for (int i=min-1; i>=0; --i){// so reverse
		buffer[i]=x%10;
		x/=10;
	}
	return buffer;
}
int menu(const char** options,int size)
{
	/** makes a menu. you give it number of options and options it returns what the user chose**/
	int choice=0;
	int scroll=0;
	const int VISIBLE_ROWS=12;
	while(1){
		kb_Scan();
		gfx_SwapDraw();
		gfx_FillScreen(255);
		gfx_SetDrawBuffer();
		int end=scroll+VISIBLE_ROWS;
		if(end>size)
			end=size;
		for(int i=scroll;i<end;i++){
			if (choice==i)
				gfx_SetTextBGColor(24);
			else
				gfx_SetTextBGColor(255);
			gfx_SetTextXY(1,(i-scroll)*20);
			gfx_PrintString(options[i]);
		}
		if(kb_IsDown(kb_KeyUp)){
			while(kb_IsDown(kb_KeyUp)){
				kb_Scan();
			}
			choice--;
		}
		if(kb_IsDown(kb_KeyDown)){
			while(kb_IsDown(kb_KeyDown)){
				kb_Scan();
			}
			choice++;
		}
		if(choice<0)
			choice=0;
		if(choice>=size)
			choice=size-1;
		if(choice<scroll)
			scroll=choice;
		if(choice>=scroll+VISIBLE_ROWS)
			scroll=choice-VISIBLE_ROWS+1;
		//dbg_printf("choice: %d\n",choice);
		if(kb_IsDown(kb_KeyEnter))
		{
			gfx_SetTextBGColor(255);
			return choice;
		}
		if(kb_IsDown(kb_KeyClear))//exit
		{
			gfx_End();
			//free(world);
			return -1;
		}
		
	}
	
}
/*
void update_changes(int id, uint8_t* block)
{*/
	/**So, what does this do? this is basically used for saving. The world structure is basically a seed and then a list
	of all the changes the player has made. This, updates that list of changes. There are two lists it updates: world_changes
	and prev_world_changes. world_changes is all the changes the player has made (like placing a block) while prev_world_changes
	is what the block was before the player touched it. I need that so if a player breaks a grass block but then immediatly places it again,
	I can remove the change rather than adding a new one. prev_world_changes is not saved to the file and is calculated at the beginning of
	the program by comparing world_changes to the world generated by the seed. prev_world_changes_sizes and world_changes_sizes
	(I know, bad names) are the sizes of the arrays in the array of world_changes and prev_world_changes. I will explain 
	that really quickly. world_changes and prev_world_changes are a static array full of malloced arrays. the syntax is
	world_changes[id][whateverchangenumber]. Each malloced array corresponds to a different block id. That way, you can
	mine 1000 stone blocks and only mine like 1 diamond and not have your memory explode. If the memory gets to fragmented, this
	function will try to fit the change in as seen below and then will tell the user it is exiting and the exit and save the changes
	(either gonna be everything except the last block changed or just evrything although probably everything). id is the thing to change block to.**/
	/*
	if(block==NULL)return;
	//id is block to put, *block is block there.
	
	//3 options: puts block where it used to be, puts block where not suposed to be, puts block where prev block 
	//not supposed to be was
	
	unsigned short b=block-world;
	
	for(int i=0; i<prev_world_changes_sizes[id];++i)
	{
		if (prev_world_changes[id][i]==b)//block was one player already placed and alignes with seed
		{			
			dbg_printf("seed align\n");
			for(int j=0; j<world_changes_sizes[*block];++j)
			{
				
				if (world_changes[*block][j]==b)//if is block player prev placed there
				{
					world_changes[*block][j]=65535;
					for(int k=j+1;k<world_changes_sizes[*block]; k++)
					{
						world_changes[*block][k-1]=world_changes[*block][k];
					}
					world_changes[*block][world_changes_sizes[*block]-1]=65535;
					break;
				}
			}
			
			prev_world_changes[*block][i]=65535;//deletes
			return;//work is done
		}
	}
	//now if not aligned with seed
	
	//clearing if prevoius block placed was there
	for(int i=0; i<world_changes_sizes[*block];++i)
	{
		if(world_changes[*block][i]==b)//if was block prev placed there.
		{
			dbg_printf("block prev placed there\n");
			for(int k=i+1;k<world_changes_sizes[*block]; k++)
			{
				world_changes[*block][k-1]=world_changes[*block][k];
			}
			world_changes[*block][world_changes_sizes[*block]-1]=65535;
			break;
		}
	}
	//now assigning block to world changes
	bool flag=true;
	assign_changes:
	for(int i=0; i<world_changes_sizes[id];++i)
	{
		if(world_changes[id][i]==65535)//open space!
		{
			dbg_printf("new\n");
			world_changes[id][i]=b;
			flag=false;
			break;
		}
	}
	if(flag)//not enough space
	{
		dbg_printf("not enough space! resizing worldchanges\n");
		int size=20;
		unsigned short* temp=NULL;
		while(temp==NULL&&size>0){
			temp = (unsigned short*)realloc(world_changes[id], (world_changes_sizes[id]+size) * sizeof(unsigned short));
			size--;
		}
		if (size<15||temp==NULL)
		{
			gfx_SetTextXY(20,100);
			gfx_SetTextFGColor(224);
			gfx_SetTextBGColor(255);
			gfx_PrintString("YOU ARE LOW ON RAM!!! Quitting now to resolve changes.\nThis happens due to ram fragmentation, so if you restart you should be fine...");
			gfx_SetTextFGColor(0);
			gfx_SwapDraw();
			msleep(3000);
			gfx_SwapDraw();
			superstop=true;
			return;
		}
		if(temp!=NULL)
		{
			world_changes[id]=temp;
			memset(world_changes[id]+world_changes_sizes[id],65535,size*sizeof(unsigned short));
			world_changes_sizes[id]+=size;
			
			goto assign_changes;
		}
	}
	//prev_world_changes. gets seed of block previously there.
	for(int j=0; j<MOBSTART;++j)
	{
		for(int i=0; i<prev_world_changes_sizes[j]; ++i)
		{
			if(prev_world_changes[j][i]==b)//if it is already in prev worldchanges
				return;
		}
	}
	assign_prevworldchanges:
	for(int i=0; i<prev_world_changes_sizes[*block]; ++i)
	{
		if(prev_world_changes[*block][i]==65535)
		{
			prev_world_changes[*block][i]=b;
			return;//assign prev_world_changes
		}
	}
	//only here if prev_world_changes ran out of space.
	dbg_printf("prevworlchanges resizing\n");
	unsigned short* temp=NULL;
	int size=20;
	while(temp==NULL&&size>0){
			temp = (unsigned short*)realloc(prev_world_changes[*block], (prev_world_changes_sizes[*block]+size) * sizeof(unsigned short));
			size--;
		}
		if (size<15||temp==NULL)
		{
			gfx_SetTextXY(20,100);
			gfx_SetTextFGColor(224);
			gfx_SetTextBGColor(255);
			gfx_PrintString("YOU ARE LOW ON RAM!!! Quitting now to resolve changes.\nThis happens due to ram fragmentation, so if you restart you should be fine...");
			gfx_SetTextFGColor(0);
			gfx_SwapDraw();
			msleep(3000);
			gfx_SwapDraw();
			superstop=true;
			return;
		}
		if(temp!=NULL)
		{
			prev_world_changes[*block]=temp;
			memset(prev_world_changes[*block]+prev_world_changes_sizes[*block],65535,size*sizeof(unsigned short));
			prev_world_changes_sizes[*block]+=size;
			goto assign_prevworldchanges;
		}
}

void chunk2world(int chx,int chz,int wherex,int wherez)
{
	wherex<<=4;
	wherez<<=4;
	static uint8_t tempchunk[16*16*16]={};
	generate_chunk(tempchunk,chx,chz);
	//dbg_printf("xo: %d, zo: %d\n",xo,zo);
	for(int x=0; x<16;++x)
	{
		for(int y=0; y<16;++y)
		{
			for(int z=0; z<16;++z)
			{
				vis_map(x+wherex,y,z+wherez)=tempchunk[(x<<8)+(y<<4)+z];
			}
		}
	}
}
void flipworldx()
{
	for(int x=1; x<WX/2-1;++x)
	{
		for(int y=0; y<WY-1;++y)
		{
			for(int z=1; z<WZ-1;++z)
			{
				uint8_t temp=vis_map(x,y,z);
				vis_map(x,y,z)=vis_map(x+16,y,z);
				vis_map(x+16,y,z)=temp;
			}
		}
	}
}
void flipworldz()
{
	for(int x=1; x<WX-1;++x)
	{
		for(int y=0; y<WY-1;++y)
		{
			for(int z=1; z<WZ/2;++z)
			{
				uint8_t temp=vis_map(x,y,z);
				vis_map(x,y,z)=vis_map(x,y,z+16);
				vis_map(x,y,z+16)=temp;
			}
		}
	}
}
*/
//                                              day                          night
static const uint8_t bg_colors[]={106,170,125,95,127,159,127,95,125,170, 106,73,41,8,0,0,0,8,41,73};
ti_var_t foo67;
#define set_archive(slotname,archived)\
{\
 		foo67 = ti_Open(slotname, "r");\
		if(!ti_SetArchiveStatus(archived, foo67)) \
		{superstop=true;dbg_printf("failed to set archive :(\n");}\
        ti_Close(foo67);\
}

char wname[9]={};
char origwname[9]={};
bool is_chunk=false;

char number2char(uint8_t num)
{
	if(num<10)//0-9 - digits
		return num+'0';
	if(num<36)//10-36 - A-Z
		return num+55;
	if(num<62)//36-62 - a-z
		return num+61;
	return 0;
}
uint8_t char2number(char c)
{
	if(c<='9')
		return c-'0';
	if(c<='Z')
		return c-'A'+10;
	if(c<='z')
		return c-'a'+36;
	return 0;
}
bool appvar_exists(const char* name) {
    ti_var_t slot = ti_Open(name, "r");
    
    if (slot != 0) {
        ti_Close(slot);
        return true;
    }
    
    return false;
}
void srandchunkseed(unsigned short seed)
{
	unsigned int loadseed=seed&0xFFF;
	loadseed|=chunkx<<12;
	loadseed|=chunkz<<18;
	srand(loadseed);
	dbg_printf("seed: %d,chunkx: %d, chunkz: %d,loadseed %d\n",seed,chunkx,chunkz,loadseed);
}
/*
void clear_changes()
{
	for (int i=0; i<MOBSTART;++i)
	{
		for (int b=0; b<world_changes_sizes[i];++b)
			world_changes[i][b]=65535;
	}
}
*/
uint8_t* update_changes_fully()
{
    if((uint8_t*)gfx_vbuffer != (uint8_t*)0xD40000)
        gfx_SwapDraw();
    
    uint8_t* realworld = (uint8_t*)0xD40000 + 1300;//0xD40000 is screen start, and hmap in generate world usises that + 1294 bytes, so do +1300
    memcpy(realworld, world, WX * WY * WZ);
    
    dbg_printf("wseed: %d,chunkx: %d, chunkz: %d\n", wseed, chunkx, chunkz);
    
    srandchunkseed(wseed);
    generate_world();
    
    memset(world_changes_sizes, 0, sizeof(world_changes_sizes));
    
    size_t size = WX * WY * WZ;
    uint8_t *ptr = realworld;
    uint8_t *ptr2 = world;
    
    do {
		if(*ptr > MOBSTART-1)//if mob
			*ptr=0;//turn all mobs into air. don't use .clear() in case mob isn't spawned (like zombie in day)
        if(*ptr != *ptr2)
            world_changes_sizes[*ptr]++; 
        ptr++;
        ptr2++;
    } while (--size); 
    
    for(int i = 0; i < MOBSTART; ++i)
        world_changes_sizes[i]++;
    
    uint16_t* nextaddr = (uint16_t*)(0xD40000 + 1310 + WX * WY * WZ);
    for(int i = 0; i < MOBSTART; ++i)
    {
        world_changes[i] = nextaddr;
        nextaddr += world_changes_sizes[i];
        world_changes[i][world_changes_sizes[i] - 1] = 65535;
    }
    
    uint8_t* realw = realworld;
    uint8_t* genw = world;
    size = WX * WY * WZ;
    
    int next[block_num];
    memset(next, 0, sizeof(next));
    
    do {
        if(*realw != *genw)
        {
            uint8_t temp = *realw;
            if(temp < MOBSTART)
            {
                world_changes[temp][next[temp]] = (uint16_t)(realw - realworld);
                next[temp]++;
                dbg_printf("change of %d at %d\n", temp, (int)(realw - realworld));
            }
        }
        realw++;
        genw++;
    } while (--size);
	return (uint8_t*)nextaddr;
}
uint8_t tchunkx=32;
uint8_t tchunkz=32;
void archiveallchunks(char* name);
#include <fileioc.h>
#include <string.h>

/** generated by gemini flash v v v**/
void clear_file_contents(uint8_t slot) {
    uint16_t size;
    uint16_t bytes_written = 0;
    uint8_t zero_buffer[32]; // Small buffer to speed up writing
    
    // 1. Get the current total size of the file
    size = ti_GetSize(slot);
    if (size == 0) return; 

    // 2. Move file pointer to the very beginning
    ti_Rewind(slot);

    // Initialize our cleaning buffer to zeros
    memset(zero_buffer, 0, sizeof(zero_buffer));

    // 3. Overwrite the entire file size with zeros
    while (bytes_written < size) {
        uint16_t to_write = size - bytes_written;
        if (to_write > sizeof(zero_buffer)) {
            to_write = sizeof(zero_buffer);
        }
        
        ti_Write(zero_buffer, to_write, 1, slot);
        bytes_written += to_write;
    }

    // 4. Rewind again so your next operations start at byte 0
    ti_Rewind(slot);
}

void save_world(char* wname,uint8_t nrealm=0)
{
	//memset(world,255,WX*WY*WZ);
	/**IMPORTANT COMMENT FOR PEOPLE READING THIS CODE!!!**/
	/*the ti 84 plus ce has 153600 of vram. graphx uses that to make two buffers.
	basically what I do is start writing to the beginning in the back buffer, so it doesn't appear on the scrren
	but if I need more ram, it will spill over the first buffer and enter the visible screen. The worst case scenario
	of memory is under 153600 (3000 for hmap)+(32768 for world) + (58000 for all the changes) + (58000 again, but this is for the back up of file)
	is under 153600 (it is 150400 around).*/
	update_cleanup();
	switch(realm)
	{
		case 0:
			wname[2]='O';
			break;
		case 1:
			wname[2]='N';
			break;
	}
	dbg_printf("saveworld wname: %s\n",wname);
	unsigned short tempseedshort;
	if(appvar_exists(wname))
	{
		set_archive(wname,false);
	}
	uint8_t* nextaddr=update_changes_fully();	
	
	dbg_printf("wname: %s\n",wname);
	ti_var_t worldslot=ti_Open(wname,"r");
	auto oldsize=ti_GetSize(worldslot);
	
	ti_Read(nextaddr, sizeof(uint8_t),oldsize, worldslot);
	ti_Close(worldslot);
	worldslot=ti_Open(wname,"w");
	unsigned short sizes[MOBSTART]={};
	int sum=0;
	for(int i=0; i<MOBSTART; ++i)
	{
		sizes[i]=world_changes_sizes[i];
		sum+=world_changes_sizes[i];
	}
	int i=sizeof(int)*(block_num+item_num);
	if (is_chunk)
		i=0;
	//safe
	bool rflag=1;
	dbg_printf("sum*2: %d\n", sum*2);
	resize:
	int totalsize=	  32
	+ 66
	+ sum*2
	+ sizeof(int)
	+ i
	+ 8
	+ sizeof(int)*3
	+ sizeof(uint32_t)
	+ sizeof(int)*3
	+ 15;
	
	bool test=ti_Resize(totalsize,worldslot);
	if(!test)
	{
		//gfx_FillScreen(bg_color);
		gfx_SetDrawScreen();
		gfx_SetTextFGColor(224); // Assuming 224 is Red in your palette
		gfx_SetTextXY(0, 230);
		gfx_PrintString("NOT ENOUGH RAM!!! Archiving some stuff...");
		gfx_SetDrawBuffer();
		msleep(1000);
		ti_Close(worldslot);
		superstop=true;
		if(rflag)
		{
			archiveallchunks(origwname);
			set_archive(origwname,true);
			set_archive(wname,false);
			if(world!=NULL)
				free(world);
			world=NULL;
			worldslot=ti_Open(wname,"w");
			rflag=0;
			goto resize;
		}
		//ok, now everything is screwed because can't save world.
		//gfx_FillScreen(bg_color);
		gfx_SetDrawScreen();
		gfx_SetTextFGColor(224); // Assuming 224 is Red in your palette
		gfx_SetTextXY(0, 230);
		gfx_PrintString("Unable to save world");
		gfx_SetDrawBuffer();
		worldslot=ti_Open(wname,"w");
		if(ti_Resize(oldsize,worldslot))
		{
			ti_Write(nextaddr, 1, oldsize, worldslot);//restore file
		}
		ti_Close(worldslot);
		msleep(1000);
		goto reallocingworld;
	}
	//clear_file_contents(worldslot);
	ti_Seek(0, SEEK_SET, worldslot);
	tempseedshort=wseed;
	ti_Write(&tempseedshort,2,1,worldslot);
	ti_Write(sizes,2,MOBSTART,worldslot);	
	//ti_Seek(66, SEEK_SET, worldslot);
	for(int i=0; i<MOBSTART; ++i)
	{
		ti_Write(world_changes[i],2,sizes[i],worldslot);
	}
	/*
	dbg_printf("freeing world_changes\n");
	for(int i=0; i<MOBSTART; ++i)
	{
		free(world_changes[i]);
		free(prev_world_changes[i]);
	}
	*/
	//writing inventory
	//int inventory[block_num+item_num]; for reference
	//safe
	if(!is_chunk)//if is in main chunk
	{
		int num2read2[1];
		num2read2[0]=block_num+item_num;
		ti_Write(num2read2,sizeof(int),1,worldslot);
		ti_Write(inventory,sizeof(int),block_num+item_num,worldslot);
		
		ti_Write(ghotbar, sizeof(uint8_t), 8, worldslot);//saving hotbar...
		
		int tempplarray[]={plx.data,ply.data,plz.data};	
		ti_Write(tempplarray,sizeof(int),3,worldslot);//saving player's position
		
		uint32_t temptime=clock()-*gstarttime;//time elapsed
		temptime+=offsettime;
		uint32_t value=32768;
		value=value*60*20;//to avoid overflow
		temptime=temptime%value;//make repeat every 20 minutes (daylight cycle)
		ti_Write(&temptime,sizeof(uint32_t),1,worldslot);//saving time
		ti_Write(&respawnx,sizeof(int),1,worldslot);
		ti_Write(&respawny,sizeof(int),1,worldslot);
		ti_Write(&respawnz,sizeof(int),1,worldslot);
		
		ti_Write(&tchunkx,sizeof(uint8_t),1,worldslot);
		ti_Write(&tchunkz,sizeof(uint8_t),1,worldslot);
		dbg_printf("tchunkx: %d, tchunkz:%d\n",tchunkx,tchunkz);
		ti_Write(&respawnchunkx,sizeof(uint8_t),1,worldslot);
		ti_Write(&respawnchunkz,sizeof(uint8_t),1,worldslot);
		ti_Write(&nrealm,sizeof(uint8_t),1,worldslot);
		ti_Write(&playerhp,sizeof(uint8_t),1,worldslot);
		ti_Write(&playerhunger,sizeof(uint8_t),1,worldslot);
	}
	ti_Close(worldslot);
	
	dbg_printf("closed\n");

	gfx_FillScreen(bg_color);
	gfx_SwapDraw();
	gfx_FillScreen(bg_color);
	gfx_SwapDraw();
	
	reallocingworld:
	if(world==NULL)
	{
		world=(uint8_t*)malloc(32768);
		if(world==NULL)
		{
			archiveallchunks(origwname);
			set_archive(origwname,true);
			gfx_End();
			os_ClrHome();
			os_HomeUp();
			printf("sorry, unable to find enough memory to load the world. Side effects might include an outdated inventory.");
			os_GetKey();
			exit(0);
		}
	}
}
//void loadnewchunk();
void load_world(char* wname)
{
	
	unsigned short sizes2[MOBSTART];
	ti_var_t worldslotr=ti_Open(wname,"r");
	if(worldslotr==0)
		dbg_printf("not real file\n");
	short x;
	ti_Read(&x, sizeof(short),1,worldslotr);
	short seed=0;
	seed=x;
	

	memcpy(wname,origwname,6);
	wname[6]=number2char(chunkx);
	wname[7]=number2char(chunkz);
	
	if(chunkx==32&&chunkz==32)
	{
		dbg_printf("main chunk\n");
		memcpy(wname,origwname,9);
	}
	/*
	switch(wname[2])
	{
		case 'O':
			realm=0;
			break;
		case 'N':
			realm=1;
			break;
	
	*/
	wseed=seed;
	srandchunkseed(seed);
	generate_world();
	
	dbg_printf("seed %d, %s\n",seed,wname);
	//order is 2seed,32size,changes
	
	ti_Read(sizes2, sizeof(short),MOBSTART,worldslotr);
	int i=0;
	while(i<MOBSTART)//should used for but already put while
	{

		//ti_Read(world_changes[i], 2,sizes2[i],worldslotr);
		for (int j=0; j<sizes2[i];++j)
		{
			unsigned short change;
			ti_Read(&change, 2,1,worldslotr);
			if(change<WX*WY*WZ)
				world[change]=i;
		}
		++i;
	}
	if(!is_chunk)
	{
		int num2read[1];
		ti_Read(num2read,sizeof(int),1,worldslotr);//gets number of blocks when world was made (backwards compatibility)
		ti_Read(inventory,sizeof(int),num2read[0],worldslotr);
		ti_Read(ghotbar,sizeof(uint8_t),8,worldslotr);
		//reading player position
		ti_Read(&plx.data,sizeof(int),1,worldslotr);
		ti_Read(&ply.data,sizeof(int),1,worldslotr);
		ti_Read(&plz.data,sizeof(int),1,worldslotr);
		ti_Read(&offsettime,sizeof(uint32_t),1,worldslotr);
		
		ti_Read(&respawnx,sizeof(int),1,worldslotr);
		ti_Read(&respawny,sizeof(int),1,worldslotr);
		ti_Read(&respawnz,sizeof(int),1,worldslotr);
		
		ti_Read(&chunkx,sizeof(uint8_t),1,worldslotr);
		ti_Read(&chunkz,sizeof(uint8_t),1,worldslotr);
		
		ti_Read(&respawnchunkx,sizeof(uint8_t),1,worldslotr);
		ti_Read(&respawnchunkz,sizeof(uint8_t),1,worldslotr);
		ti_Read(&realm,sizeof(uint8_t),1,worldslotr);
		playerhp=0;
		playerhunger=0;
		ti_Read(&playerhp,sizeof(uint8_t),1,worldslotr);
		ti_Read(&playerhunger,sizeof(uint8_t),1,worldslotr);
		dbg_printf("chunkx: %d, chunkz:%d, respawncx %d, respawn cz %d\n",chunkx,chunkz,respawnchunkx,respawnchunkz);
	}
	
	ti_Close(worldslotr);
	is_chunk=true;
	if(chunkx==32&&chunkz==32)
	{
		is_chunk=false;
	}
	
}


void deleteallchunks(char* name)
{
	name[2]='O';
	for(int x=0; x<62;++x)
	{
		for(int z=0; z<62;++z)
		{
			char temp[9]={};
			memcpy(temp,name,6);
			temp[6]=number2char(x);
			temp[7]=number2char(z);
			if(appvar_exists(temp))
				ti_Delete(temp);
			temp[2]='N';
			if(appvar_exists(temp))
				ti_Delete(temp);
		}
	}
	name[2]='N'; ti_Delete(name);
}
void archiveallchunks(char* name)
{
	name[2]='O';
	for(int x=0; x<62;++x)
	{
		for(int z=0; z<62;++z)
		{
			if(x!=32||z!=32)
			{
				char temp[9]={};
				memcpy(temp,name,6);
				temp[6]=number2char(x);
				temp[7]=number2char(z);
				if(appvar_exists(temp))
				{
					set_archive(temp,true);
				}
				temp[2]='N';
				if(appvar_exists(temp))
					set_archive(temp,true);
			}
		}
	}
	origwname[2]='N';
	if(appvar_exists(origwname)) set_archive(origwname,true); 
	origwname[2]='O';
}

void loadnewchunk()
{
	if(bstacktop>0)
	{
		bstacktop=0;//clear the array kind of
		update_cleanup();//in case tnt was expldoing or something
	}
	while(mob_count>0)
    despawn_mob(mob_list[0]);

	updatehotbar=2;
	is_chunk=true;
	
	if(chunkx==32&&chunkz==32)
	{
		memcpy(wname,origwname,9);
	}
	else//if isn't main chunk
	{
		memcpy(wname,origwname,6);
		wname[6]=number2char(chunkx);
		wname[7]=number2char(chunkz);
	}
	// 0 1   2      3 4 5     6        7
	// M C[realm][worldnum][chunkx][chunkz]
	switch(realm)
	{
		case 0:
			wname[2]='O';//overworld
			break;
		case 1: 
			wname[2]='N';//nether
			biome=255;
			break;
	}
	
	

	ply=WY-1;
	//clear_changes();
	dbg_printf("cleared changes\n");

	if(appvar_exists(wname))//if have loaded chunk
	{
		dbg_printf("loaded chunk\n");
		load_world(wname);
	}
	else//if is new chunk
	{
		srandchunkseed(wseed);
		generate_world(); 
	}
	if(biome==0)
	{
		for(int i=0; i<4;++i)
		{
			spawn_sheep();
			spawn_pig();
		}
		dbg_printf("sheeeepp!\n");
	}
	else if (biome==255)//nether
	{
		for(int i=0; i<10;++i)
		{
			spawn_piglin();			
		}
		ply-=3;//because of nether roof
	}
	if(chunkx==32&&chunkz==32)
	{
		is_chunk=false;
	}
	srand(rtc_Time()+clock());
}
//claude wrote this v v v
void draw_portal(uint8_t sx, uint8_t sy, uint8_t sz)
{
	// 4 wide (x), 10 tall (y), 1 deep (z=sz)
	if(sy>27) sy=27;
	for (uint8_t x = sx; x < sx + 4; ++x)
	{
		for (uint8_t y = sy; y < sy + 5; ++y)
		{
			bool edge = (x == sx || x == sx + 3 || y == sy || y == sy + 4);
			vis_map(x, y, sz) = edge ? OBSIDIAN : NETHERPORTAL;
		}
	}
}
//claude wrote this v v v 
bool is_portal(uint8_t bx, uint8_t by, uint8_t bz, uint8_t* out_sx=nullptr, uint8_t* out_sy=nullptr, uint8_t* out_sz=nullptr, bool* z_oriented=nullptr)
{
	for (int dx = 0; dx < 4; ++dx)
	for (int dy = 0; dy < 5; ++dy)
	{
		if (!(dx==0||dx==3||dy==0||dy==4)) continue; // candidate must be some border cell (corner ok too)
		int sx = bx-dx, sy = by-dy;
		if (sx<0||sy<0||sx+3>=WX||sy+4>=WY) continue;

		bool ok=true;
		for (int x=0; x<4 && ok; ++x)
		for (int y=0; y<5 && ok; ++y)
		{
			bool corner = (x==0||x==3) && (y==0||y==4);
			bool edge   = (x==0||x==3||y==0||y==4) && !corner;
			uint8_t b = vis_map(sx+x,sy+y,bz);
			if (edge && b!=OBSIDIAN) ok=false;
			else if (!edge && !corner && b!=AIR) ok=false; // interior only
		}
		if (ok)
		{
			if(out_sx)*out_sx=sx; if(out_sy)*out_sy=sy; if(out_sz)*out_sz=bz;
			if(z_oriented)*z_oriented=false;
			return true;
		}
	}

	for (int dz = 0; dz < 4; ++dz)
	for (int dy = 0; dy < 5; ++dy)
	{
		if (!(dz==0||dz==3||dy==0||dy==4)) continue;
		int sz = bz-dz, sy = by-dy;
		if (sz<0||sy<0||sz+3>=WZ||sy+4>=WY) continue;

		bool ok=true;
		for (int z=0; z<4 && ok; ++z)
		for (int y=0; y<5 && ok; ++y)
		{
			bool corner = (z==0||z==3) && (y==0||y==4);
			bool edge   = (z==0||z==3||y==0||y==4) && !corner;
			uint8_t b = vis_map(bx,sy+y,sz+z);
			if (edge && b!=OBSIDIAN) ok=false;
			else if (!edge && !corner && b!=AIR) ok=false;
		}
		if (ok)
		{
			if(out_sx)*out_sx=bx; if(out_sy)*out_sy=sy; if(out_sz)*out_sz=sz;
			if(z_oriented)*z_oriented=true;
			return true;
		}
	}
	return false;
}
//claude wrote this as well v v v
bool try_light_portal(uint8_t bx, uint8_t by, uint8_t bz)
{
	uint8_t sx, sy, sz;
	bool z_oriented;
	if (!is_portal(bx, by, bz, &sx, &sy, &sz, &z_oriented))
		return false;

	if (!z_oriented)
	{
		for (int x = 1; x < 3; ++x)
			for (int y = 1; y < 4; ++y)
				vis_map(sx+x, sy+y, sz) = NETHERPORTAL;
	}
	else
	{
		for (int z = 1; z < 3; ++z)
			for (int y = 1; y < 4; ++y)
				vis_map(sx, sy+y, sz+z) = NETHERPORTAL;
	}
	return true;
}
//but not v v v

void break_portal_helper(uint8_t* block)
{
	dbg_printf("Checking neighbor block ID: %d\n", *block);
	if(*block==NETHERPORTAL)
	{
		*block=0;
		break_portal_helper(block+XJ);
		break_portal_helper(block-XJ);

		break_portal_helper(block+YJ);
		break_portal_helper(block-YJ);

		break_portal_helper(block+ZJ);
		break_portal_helper(block-ZJ);
	}
}
void break_portal(uint8_t*block)
{
	dbg_printf("this is happening right: %d\n", *block);
	break_portal_helper(block+XJ);
	break_portal_helper(block-XJ);

	break_portal_helper(block+YJ);
	break_portal_helper(block-YJ);

	break_portal_helper(block+ZJ);
	break_portal_helper(block-ZJ);

}
void spawn_nether_portal(uint8_t x,uint8_t& y,uint8_t z)
{
	if(x<1)  x=1;
	if(x>27) x=27;          
	if(z<2)  z=2;
	if(z>29) z=29;

	if(plx>27) plx=27;
	if(plx<1) plx=1;
	if(plz<2) plz=2;
	if(plz>29) plz=29; 
	bool has_hit_air=false;
	for(y=31;y>0;--y)
	{
		if(vis_map(x,y,z)==AIR)
			has_hit_air=true;
		if(has_hit_air)
		{
			if(vis_map(x,y,z))//anything other than air
			{
				draw_portal(x,y,z);
				break;
			}
		}
	}
}
bool find_nether_portal(uint8_t&x,uint8_t&y,uint8_t&z)
{
	for(x=0;x<32;++x)
	{
		for(z=0;z<32;++z)
		{
			for(y=31;y>0;y--)
			{
				if(vis_map(x,y,z)==NETHERPORTAL)
				{
					return true;
				}
			}
		}
	}
	return false;
}
uint8_t realmcooldown=0;
inline bool walk_thru_block(int blockid)
{
	if(blockid==0)
		return true;
	if(blockid>MOBSTART-1)
		return true;
	if(blockid>reg_block_num&&blockid<FLOORVOXELSEND+1)//if is a floor voxel
		return true;
	if(blockid==FIRE)
		return true;
	if(blockid==SMOKE)
		return true;
	if(blockid==WATERBLOCK)
		return true;
	if(blockid==WATERFALL)
		return true;
	if(blockid==NETHERPORTAL)
	{
		if(realmcooldown==0)
		{

			realmcooldown=30;
			save_world(wname);
			if(realm==0)
			{
				realm=1;
				change_bg(NETHERBGCOLOR);
			}
			else if(realm==1)
			{
				realm=0;
			}
			//not using not because might add end dimesnion eventually
			
			loadnewchunk();
			uint8_t x,y,z;
			if(find_nether_portal(x,y,z))
			{
				plx=x;
				ply=y;
				plz=z;
			}
			else
			{
				uint8_t ry;
				spawn_nether_portal((int)plx,ry,(int)plz);
				ply=ry+1;
				plx+=1;
			}
			return false;
		}
		return true;
	}
	return false;
}
void try_walk(flint dirx, flint dirz)
{
	if(randInt(0,100)==0)
	{
		playerhunger--;
		updatehotbar=2;//once per buffer. (I am double buffering). updates hunger on screen
		if(playerhunger<0)
		{
			playerhunger=0;
		}
	}
	int nx=(int)(dirx+plx);
	int nz=(int)(dirz+plz);
	
	int iplx=(int)plx;
	int iply=(int)ply;
	int iplz=(int)plz;
	//                                               door
	if(plx+dirx>30&&chunkx<61)
	{
		save_world(wname);
		chunkx++;
		loadnewchunk();
		plx=1;
	}
	else if(plx+dirx<1&&chunkx>0)
	{
		save_world(wname);
		chunkx--;
		loadnewchunk();
		plx=30;
	}
	else if(plz+dirz>=32&&chunkz<61)//z barrier is only on 0 due to helpful properties of flattened arrays
	{
		save_world(wname);
		chunkz++;
		loadnewchunk();
		plz=1;
	}
	else if(plz+dirz<1&&chunkz>0)
	{
		save_world(wname);
		chunkz--;
		loadnewchunk();
		plz=31;
	}
	else
	{
		if ( (walk_thru_block(vis_map(nx,iply,iplz))&&walk_thru_block(vis_map(nx,iply-1,iplz))) || vis_map(nx,iply,iplz)==DOORTOPOPEN)
			plx+=dirx;
		iplx=(int)plx;//updates it
		if ( (walk_thru_block(vis_map(iplx,iply,nz))&&walk_thru_block(vis_map(iplx,iply-1,nz))) ||vis_map(iplx,iply,nz)==DOORTOPCLOSED)
			plz+=dirz;
		
	}
}

void gc_before(void)
{
	gfx_End();
}
extern "C" void init_cursor_dda();
void gc_after(void)
{
	gfx_Begin();
	gfx_SetDefaultPalette(gfx_8bpp);
	gfx_palette[1] = gfx_RGBTo1555(40, 40, 40);
	gfx_SetDrawBuffer();
	gfx_SetTextFGColor(0);
	gfx_SetTextBGColor(255);
	gfx_SetTextTransparentColor(26);
	MNCFTIMG_init();
	updatehotbar=2;
	init_cursor_dda();//5
}

int break_block(uint8_t* block)
{
	uint8_t iv;
	uint8_t bv=*block;
	iv=bv;//inventory value = block value
	if(bv>DOORTOPOPEN-1&&bv<DOORBOTTOMCLOSED+1)//door, not door top open (regular)
	{
		iv=DOORTOPOPEN;
	}
	switch(iv)
	{
		case DIAMOND:
			iv=DIAMONDITEM;
			break;
		case REDSTONE:
			iv=REDSTONEDUSTUNLIT;
			break;
		case COAL:
			iv=COALITEM;
			break;
		case FIRE:
		case SMOKE:
		case GLASS:
		case WATERBLOCK:
		case WATERFALL:
		case WATERSLAB:
		case WATERFLOOR:
			iv=0;//do nothing. i have if statement to do nothing if iv==0
			break;
		case GRAVEL:
			if(randInt(0,4)==0)//I know, it should be 1 out of 8 but that is really annoying in real minecraft so I changed it
				iv=FLINT;
			break;

		case NETHERPORTAL:
			iv=0;
			//fallthough is purposeful here
		case OBSIDIAN://break_portal will fail if isn't portal so is ok
			break_portal(block);
			break;
		case NETHERGOLDORE:
			iv=GOLDINGOT;
			break;
		
	}
	if(iv)//iv!=0
	{
		inventory[iv]++;
		add2hotbar(iv);
	}
	
	//dbg_printf("update changes...\n");
	//update_changes(0,block);
	*block=0;
	add_updates_fully(block);
	//dbg_printf("assign block...\n");
	if(bv==DOORTOPCLOSED||bv==DOORTOPOPEN||bv==DOORBOTTOMCLOSED||bv==DOORBOTTOMOPEN)//is door
	{
		if(bv==DOORTOPCLOSED||bv==DOORTOPOPEN)
		{
			block-=YJ;//moves down one in y								
		}
		else//bottom door part
			block+=YJ;
		//update_changes(0,block);
		*block=0;
	}
	return iv;
}
const char* keybinds[]=
{
"Welcome to Keybinds! (press any key to leave)",
"Controls for main gameplay:",
"    clear - save and exit (works anywhere)",
"    2nd   - move forward",
"    alpha - move backward",
"    mode  - jump",
"    XTON  - open crafting menu",
"    del   - mine block / attack a mob",
"    stat  - place block/use a block/use held item",
"    plus  - move selected block in hotbar +1",
"    minus - move selected block in hotbar -1",
"    math  - toggle fast look/turn speed",
"    arrows - changing perspective/look around",
"    apps  - open this menu",
"Controls for crafting menu:",
"    arrows - moving cursor around",
"    NOTE: THERE'S A SCROLL IN THIS MENU!",
"    plus   - move cursor to the next area",
"    minus  - move cursor to the previous area",
"    2nd    - select/move block",
"    alpha  - split block in crafting table",
"    enter  - craft",
"    XTON   - exit the inventory screen.",
"    mode   - view all crafting recipies",
"Controls for the furnace menu:",
"    arrows - moving cursor around",
"    NOTE: THERE'S A SCROLL IN THIS MENU!",
"    2nd   - select block to be smelted",
"    alpha - select block to be used as fuel",
"    XTON  - exit menu. EXIT RESETS FURNACE STATE!"
};
//gemini flash v v v
void wait_key_release(void) {
    // Scan keypad status
    kb_Scan();
    
    // Loop continuously while ANY key in any matrix row is pressed
    while (kb_Data[1] || kb_Data[2] || kb_Data[3] || 
           kb_Data[4] || kb_Data[5] || kb_Data[6] || kb_Data[7]) {
        kb_Scan();
    }
}
void disp_controls()
{
	wait_key_release();
	int y=0;
	gfx_SetDrawBuffer();
	gfx_SetTextFGColor(0);
	gfx_SetTextBGColor(255);
	gfx_FillScreen(255);
	for(int i=0; i<30;++i)
	{
		gfx_PrintStringXY(keybinds[i],0,y);
		y+=8;
	}
	
	gfx_SwapDraw();
	kb_Scan();
	//while no key is pressed: check if key is pressed
	while (!(kb_Data[1] || kb_Data[2] || kb_Data[3] || 
           kb_Data[4] || kb_Data[5] || kb_Data[6] || kb_Data[7]))
		   kb_Scan();
	wait_key_release();
}
void view_recipies()
{
	const char* choices[]={"EXIT RECIPIES","PLANKS", "STICK", "WOODPIC", "STONEPIC", "IRONPIC", "DIAMONDPIC", "WOODSWORD", "STONESWORD", 
		"IRONSWORD", "DIAMONDSWORD", "CRAFTTABLE", "DOORTOPOPEN", "FURNACE", "BEDTOP", "GOLDPIC", "GOLDSWORD", "FLINTANDSTEEL", 
		"TNT", "BUCKET", "IRONBLOCK","GOLDBLOCK", "DIAMONDBLOCK", "REDSTONEBLOCK", "IRONINGOT", "GOLDINGOT", "DIAMONDITEM", 
		"REDSTONEDUSTUNLIT"};
	const char** c=choices;
	gfx_SetDrawBuffer();
	while(true)
	{
		int choice=menu(c,RECIPIENUM+1);
		kb_Scan();
		wait_key_release();
		
		if(choice<=0)
		{
			if(choice==-1)
			{
				gfx_Begin();
				gfx_SetDefaultPalette(gfx_8bpp);
				gfx_palette[1] = gfx_RGBTo1555(40, 40, 40);
				superstop=true;
			}
			gfx_SetDrawBuffer();
			gfx_FillScreen(75);
			return;
		}
		gfx_FillScreen(75);
		gfx_SetColor(175);
		gfx_FillRectangle_NoClip(100,20,120,120);
		for(uint8_t x=0; x<3;++x)
		{
			for(uint8_t y=0; y<3;++y)
			{
				int index=recipies[choice-1][y][x];
				if(index>0)
				{
					draw_item(index, 105+x*36, 25+y*36,0);
				}
			}
		}
		gfx_PrintStringXY("Press any key to continue", 0, 0);
		gfx_SwapDraw();
		do
		{
			kb_Scan();
		} while (!(kb_Data[1] || kb_Data[2] || kb_Data[3] || 
				kb_Data[4] || kb_Data[5] || kb_Data[6] || kb_Data[7]));
	}
}	
static bool hide_in_inventory[invenblocknum+item_num]={};

static int visible_ids[invenblocknum+item_num];
static int num_visible=0;

void build_visible_ids()
{
    num_visible=0;
    for(int i=1;i<invenblocknum+item_num;++i)
        if(!hide_in_inventory[i])
            visible_ids[num_visible++]=i;
}

int main(void){
	int dt=1;
	// in main(), before the game loop:
	hide_in_inventory[BARRIER]=true;
	hide_in_inventory[UNLITLAMP]=true;
	hide_in_inventory[LITLAMP]=true;
	hide_in_inventory[UNLITBUTTON]=true;
	hide_in_inventory[LITBUTTON]=true;
	hide_in_inventory[WATERBLOCK]=true;
	hide_in_inventory[WATERFALL]=true;
	hide_in_inventory[WATERSLAB]=true;
	hide_in_inventory[WATERFLOOR]=true;
	hide_in_inventory[DOORBOTTOMOPEN]=true;
	hide_in_inventory[DOORTOPCLOSED]=true;
	hide_in_inventory[DOORBOTTOMCLOSED]=true;
	hide_in_inventory[FIRE]=true;
	hide_in_inventory[LITTNT]=true;
	hide_in_inventory[SMOKE]=true;
	hide_in_inventory[NETHERPORTAL]=true;

	auto *data_ptr = os_GetAppVarData("MNCFTIMG", NULL);
    
	if (data_ptr == NULL)//no asset file
	{
		os_ClrHome();
		os_HomeUp();
		printf("Uh oh! you (or whoever sent this game) forgot to send the assets file (it has all the item images and stuff) to the calculator! Please send the file titled MNCFTIMG.8xv");
		os_NewLine();
		os_NewLine();
		printf("Press any key to continue");
		os_GetKey();
		return 6767;
	}
		
	//init important stuff
	world=(uint8_t*)malloc(32768);
	if(world==NULL)
	{
		os_HomeUp();
		os_ClrHome();
		printf("not enough ram!!! free up some stuff");
		os_GetKey();
		return 6767;
	}
	ti_SetGCBehavior(gc_before, gc_after);
	MNCFTIMG_init();
	gfx_sprite_t* tempimgs[]={woodpic,stonepic,goldpic,ironpic,diamondpic,/*netheritepic*/NULL,stick,woodsword,stonesword,goldsword,ironsword,diamondsword,ironingot,goldingot,rawmutton,    cookedmutton,    rottenflesh,diamond,coal,flintandsteeeel,flintitem,bucket,waterbucket,rawporkchop,cookedporkchop};
	gfx_sprite_t* tempimgs2[]={emptyfurnaceflames,furnaceflames1,furnaceflames2,furnaceflames3,furnaceflames4,furnaceflames5};
	item_imgs=tempimgs;
	flames=tempimgs2;
	for (int i=0;i<64;i++)
	{
		float angle = i * (6.283185f / 64.0f);
		cached_sin_rot[i].float2flint((float)std::sin(angle));
		cached_cos_rot[i].float2flint((float)std::cos(angle));

	}
	beginning:
	dbg_printf("began!\n");
	ti_var_t worldslot;
	ti_var_t nslot = ti_Open("MNCFTD", "r");// main appvar that has list of worlds and stuff
	if (nslot==0){//not exist
					//version,number of worlds
		uint8_t header[3] = {0, 0};
		set_archive("MNCFTD",false);
		ti_var_t slot = ti_Open("MNCFTD", "w");
		ti_Resize(1024, slot);
		ti_Write(header, sizeof(uint8_t), 2, slot);
		ti_Close(slot);
		set_archive("MNCFTD",true);
		//what had before
	}
	ti_Close(nslot);
	ti_var_t slot = ti_Open("MNCFTD", "r");
	gfx_Begin();
	//ti_var_t worldslotr;
	int seed=0;
	const char *options[]={
		"Exit",
		"Create New",
		"Open World",
		"Delete World",
		"Veiw Controls (HIGHLY recommended if new)",
	};
	
	uint8_t* header=(uint8_t*)world;
	ti_Read(header, sizeof(uint8_t),2048,slot);
	ti_Close(slot);
	uint8_t nheader[22]={};//16 bytes for name, 6 for appvar
	
	/*
	ti_var_t tempslot = ti_Open("TEMPVR67", "w");
	if(tempslot==0)
	{
		gfx_End();
		return 4;
	}
	
	auto didwork=ti_Resize(40000,tempslot);
	ti_Close(tempslot);
	ti_Delete("TEMPVR67");
	if(didwork==0)
	{
		gfx_End();
		os_ClrHome();
		printf("Sorry! not enough ram to run program :(");
		os_GetKey(); 
		return 3;
	}
	*/
	int choice=menu(options,5);

	 /** save formats (wrote by me):
	 header:
	 
		 version			 [1 byte]
		 number of worlds    [1 byte]
		 (a bunch of world headers) [22 bytes each]
		 
	world headers:
		
		world name				[16 bytes]
		appvar name for world	[6 bytes]
		 
	world:
		seed	 									   [2 bytes]
		sizes of changes to seeded world 			   [64 bytes]
	    size of block_num+item_num when world was made [3 bytes]
		inventory                                      [3*(block_num+item_num) bytes]
		hotbar                                         [8 bytes]
		player's position in fixed point format        [3 bytes]
		game time (for daylight cycle)                 [1 bytes]
		
	 **/
	if(choice==-1)
	{
		gfx_End();
		return 0;
	}
	if(choice==0)
	{
		gfx_End();
		return 0;
	}
	if (choice==1){//creating new
		if(header[1]>39)
		{
			os_HomeUp();
			os_ClrHome();
			gfx_End();
			msleep(500);
			printf("Sorry, this game has a cap of 39 worlds! Please delete a world if you truly want to make another one");
			gfx_Begin();
			os_GetKey();
			goto beginning;
		}
		char buffer [17]={};
		gfx_End();
		while (kb_IsDown(kb_KeyEnter)){
			kb_Scan();
		}
		os_GetStringInput("Enter world name (max 16 chars): ",buffer,sizeof(buffer));
		for (int i=0; i<16;++i)
			nheader[i]=buffer[i];
		nheader[16]='M';
		nheader[17]='C';// appvars are in format MC (o for overworld, n for nether) world num. like MCO167.
		nheader[18]='O';
		//char* temp=int_to_chr(header[1],3);//appvar name
		//int count=header[1];//this is how many worlds there are. the catch: if one was deleted, could accidentaly overwrite last world.
		
		int count=0;
		for (;count<=header[1];++count)
		{	
			bool flag=true;
			for(int i=2; i<header[1]*22+2;i+=22)//skipping start bits, reading world
			{
				
				char tempc[4];
				//+19 because +16 for name, +3 for MCO
				memcpy(tempc,&header[i+19],3);
				tempc[3]=0;//null terminated
				if(atoi(tempc)==count)
				{
					flag=false;
					break;
				}
				
			}
			if(flag)
				break;
		}
		//ok, now count should be the highest number that won't break anything
		char temp[4];
		std::snprintf(temp, sizeof(temp), "%03d", count); 
		nheader[19]=temp[0];nheader[20]=temp[1];nheader[21]=temp[2];// adding number to header. now MCO167 or something
		header[1]=header[1]+1;
		dbg_printf("Temp: %s",temp);
		uint8_t* newheader=(uint8_t*) &world[16384];// header 1 is how many worlds, 22 bytes per world, 2 starting bytes
		int c=(header[1]-1)*22+2;//-1 bcs inc up there
		for (int i=0; i<c; i++)
			newheader[i]=header[i];//adds old header stuff
		for (int i=0;i<22;i++)
			newheader[i+c]=nheader[i];
		set_archive("MNCFTD",false);
		ti_var_t slotw = ti_Open("MNCFTD", "w");
		ti_Write(newheader,sizeof(uint8_t),2+22*40,slotw);
		ti_Close(slotw);//saves the new header
		set_archive("MNCFTD",true);
		char temp2[9]={};
		temp2[0]='M';temp2[1]='C';temp2[2]='O';temp2[3]=temp[0];temp2[4]=temp[1];temp2[5]=temp[2];temp2[6]=0;
		worldslot=ti_Open(temp2, "w");
		ti_Resize(64, worldslot);
		char buffer2[17]={};
		while (kb_IsDown(kb_KeyEnter)){
			kb_Scan();
		}
		os_GetStringInput("Enter seed: ", buffer2,sizeof(buffer2));
		seed=atoi(buffer2);
		srandchunkseed(seed);
		
		generate_world();
		wseed=seed;
		memcpy(origwname,temp2,9);
		memcpy(wname,temp2,9);
	
	unsigned short seedshort=seed;
	
	dbg_printf("seed start: %d, %s\n",seed,temp2);
	//world syntax is 1st two bytes is seed
	ti_Write(&seedshort,sizeof(unsigned short),1,worldslot);//writes seed
	wseed=seed;
	ti_Close(worldslot);
	}
	else if(choice==2)//loading world
	{
		char **opt = (char**)malloc(header[1]* sizeof(char*));
		for (int i = 0; i < header[1]; i++) 
			opt[i] = new char[17]();
		int c=0;
		for(int i=2; i<header[1]*22+2;i+=22)//skipping start bits, reading world
		{
			memcpy(opt[c],&header[i],16);
			c++;
		}
		msleep(500);
		if(header[1]==0)
			goto beginning;
		int wchoice=menu((const char**)opt,header[1]);
		if(wchoice==-1)
			return 0;
		dbg_printf("wchocie: %d",wchoice);
		
		
		memcpy(wname,header+wchoice*22+18,6);
		for (int i = 0; i < header[1]; i++) {
			delete[] opt[i];
		 }
		free(opt);
		memcpy(origwname,wname,9);
		dbg_printf("loding wrld\n");
		load_world(wname);
		dbg_printf("ply that was loaded: %d\n",(int)ply);
		flint tempply=ply;
		loadnewchunk();
		ply=tempply;
		
	}
	else if(choice==3)//delete world
	{
		if (header[1]>0){
			//gfx_Begin();
			char **opt = (char**)malloc(header[1]* sizeof(char*));
			for (int i = 0; i < header[1]; i++) 
				opt[i] = new char[17]();
			int c=0;
			for(int i=2; i<header[1]*22+2;i+=22)//skipping start bits, reading world
			{
				memcpy(opt[c],&header[i],16);
				c++;
			}
			msleep(500);
			int wchoice=menu((const char**)opt,header[1]);
			if(wchoice==-1)
				return 0;
			gfx_Begin();
			dbg_printf("wchocie: %d",wchoice);
			
			
			memcpy(wname,header+wchoice*22+18,6);
			for (int i = 0; i < header[1]; i++) {
				delete[] opt[i];
			 }
			free(opt);
			while (kb_IsDown(kb_KeyEnter))//to catch stray keydown
				kb_Scan();
			msleep(300);
			const char* tempstring[] = {
			"NEVERMIND, PLEASE DON'T DELETE MY WORLD!",
			"Proceed with world deletion?"        
			};
			int rusure=menu(tempstring,2);
			dbg_printf("rusure: %d\n",rusure);
			if (rusure==1)
			{
				dbg_printf("DELETING\n");
				int actualindex=wchoice*22+2;
				char appvarname[7]={};
				for(int i=0;i<7;++i)
				{
					appvarname[i]=header[actualindex+16+i];//see big huge freaking comment above
				}
				appvarname[6]=0;//so is null terminated
				ti_Delete(appvarname);//ok, so deleted appvar. Now need to remove it from header.
				deleteallchunks(appvarname);
				
				int length=header[1]*22+2;
				length-=actualindex;
				length-=22;
				dbg_printf("header[1]: %d, length: %d, actualindex: %d, appvarname: %s", header[1], length, actualindex, appvarname);
				memmove(&header[actualindex],&header[actualindex+22], length);
				header[1]-=1;
				set_archive("MNCFTD",false);
				ti_var_t slotw = ti_Open("MNCFTD", "w");
				ti_Write(header,sizeof(uint8_t),header[1]*22+2,slotw);
				ti_Close(slotw);
				set_archive("MNCFTD",true);
			}
		}
		gfx_End();
		dbg_printf("going to beginning...");
		goto beginning;
		
	}
	else if(choice==4)//view controls
	{
		disp_controls();
		gfx_End();
		goto beginning;
		
	}
	// stores block ids and will appear on screen
	uint8_t* hotbar =&ghotbar[0];
	{
		gfx_Begin();
		gfx_SetDrawBuffer();
		gfx_FillScreen(0);
		for(int i=0; i<reg_block_num+1;++i)   // solid blocks: cache at 16x16
		{
			gfx_FillScreen(0);
			draw_itemnobuffer(i,0,0);
			int c=i<<8;
			for(int y=0; y<32; y+=2)
			{
				for(int x=0; x<32; x+=2)
				{
					blockspritebuffer[c]=gfx_vbuffer[y][x];
					++c;
				}
			}
		}
		for(int i=CRAFTTABLE; i<invenblocknum+1;++i)   // textured blocks: cache at 8x8
		{
			gfx_FillScreen(0);
			draw_itemnobuffer(i,0,0);
			int c=(i-CRAFTTABLE)<<6;
			
			for(int y=0; y<32; y+=4)
			{
				for(int x=0; x<32; x+=4)
				{
					texturespritebuffer[c]=gfx_vbuffer[y][x];
					++c;
				}
			}
		}
		
		gfx_End();
	}
	/*
	hotbar[0]=DIAMONDPIC;
	hotbar[1]=STICK;
	inventory[DIAMONDPIC]=1;
	inventory[STICK]=100;
	for (int i=0;i<block_num+item_num;i++)
		inventory[i]=0;
	*/
	{// just to minimize caching for viewing purposes
	/*
	if (world==NULL){
		gfx_End();
		ti_Close(worldslot);
		ti_Close(worldslotr);
	return 0;}
	*/
	
	//char buffer[10];
	//gfx_End();
	
	// doing caching for speeeeed
	flint fl256=512;
	
	inv_table=inv_tabler+750;
	for (int i = -750; i < 750; i++) {
		if (i == 0) 
			inv_table[i] = 300000; 
		else 
		{
			inv_table[i] = fl256/i;// i/(i/512) = 512/i
			inv_table[i].data=fast_abs(inv_table[i].data);
			inv_table[i].data = fast_abs(inv_table[i].data)<16384? fast_abs(inv_table[i].data): 16384;
		}
	}

	point01.float2flint(.01f);//exactly what it looks like
	focal_inv.float2flint(1/(float)focal_length);

	
	flint max=0;

	
	//good
	for (int i=-160;i<160;i++){//slopes. (x1-x2)/(y1-y2)
		//points= (i,focal),(0,0)      (i-0)/(focal_length-0) xz
		cached_x_dir[i+160].float2flint(i/(float)focal_length);
		cached_x_dir[i+160]*=step_divide;

		if (i==0)
			cached_x_dir[i+160].data=0x1;//smallest flint value
		if (cached_x_dir[i+160].flint_abs()>max)
			max=cached_x_dir[i+160];
	}
	
	max=0;
	for (int i=-120;i<120;i++){//slopes. (x1-x2)/(y1-y2)
		//points= (i,focal),(0,0)      (i-0)/(focal_length-0)
		cached_y_dir[i+120].float2flint(-i/(float)focal_length);
		cached_y_dir[i+120]*=step_divide;
		if (i==0)
			cached_y_dir[i+120].data=0x1;//smallest flint value
		if (cached_y_dir[i+120].flint_abs()>max)
			max=cached_y_dir[i+120];
	}
	}

	gfx_Begin();
	gfx_SetDefaultPalette(gfx_8bpp);
	bool alive =true;
	flint dirz=1; flint dirx=0;
	int flag=0;
	flint grav=0; //player's GRAVity
	flint grav_amount=.3f;
	gfx_SetDrawBuffer();
	flint fln1pt5=-1;// flint negative 1 point 5
	//block on hotbar selected
	//void *free_ram_ptr;
    //size_t free_ram_size = os_MemChk(&free_ram_ptr);

    // This will appear in the CEmu Console (Docks > Console)

	/*
	for (int xo=0; xo<2;xo++)
	{
		for(int zo=0; zo<2;zo++)//this... doesn't work
		{
			chunk2world(xo,zo,xo,zo);
		}
	}
	outline_vis_map();
	*/
	//generate_world();
	//dbg_printf("generating world...\n");
	//generate_chunk(world);
	//dbg_printf("generated world!\n");
	//BUG IN DOOR! SHEEP
	//can't fix ^ ^ ^ fisheye distorition by noneuclidean distance (taxicab). TODO: rasterization baby!!!! but first chunking :(
	//also, need more textured blocks.
	
	gfx_SetTextBGColor(247);
	//vis_map(1,3,1)=reg_block_num+6;
	//vis_map(1,2,1)=reg_block_num+7;
	dbg_printf("starting loop\n\n");
	int mining_timer=0;
	unsigned int frame=15;//make sure starts off doing frame stuff
	int32_t start_time=clock();
	gstarttime=&start_time;
	
	//flint oneover60=1/60.0f;
	bool prevkeydel=0;
	//vis_map(2,13,2)=reg_block_num+10;
	//vis_map(2,12,2)=reg_block_num+14;
	//vis_map(2,12,3)=reg_block_num+16;
	//mob stuff!
	
	rtc_Enable(0); 
    srand(rtc_Time()); 
	//end mob stuff
	gfx_SetTextFGColor(0);
	superstop=false;
	int wtime=0;
	alive=true;
	gfx_SetTextTransparentColor(26);

	//goto end;
	gfx_palette[1] = gfx_RGBTo1555(40, 40, 40);
	clock_t last_update = clock();
	clock_t last_place = clock();
	clock_t last_world_tick=clock();
	std::clock_t t1=1;
	//uint8_t update_count=0;
	init_cursor_dda();
	while (1)
	{		
		
		if (!alive)
		{
			playerhp=20;
			playerhunger=20;
			plx=respawnx;
			ply=respawny;
			plz=respawnz;
			if(chunkx!=respawnchunkx||chunkz!=respawnchunkz||realm!=0)
			{
				save_world(wname);
				realm=0;
				chunkx=respawnchunkx;
				chunkz=respawnchunkz;
				flint tempply=ply;
				loadnewchunk();
				ply=tempply;
			}

			//add respawn chunkx and z
		}
		alive=true;
		gfx_FillScreen(bg_color);
		updatehotbar=2;
		//dbg_printf("magmablock: %d fire: %d\n",MAGMABLOCK,FIRE);
		int lspeed=0;//look speed multiplier
		if(realm==1)
			change_bg(NETHERBGCOLOR);
		uint8_t* mining_block=nullptr;
		/*
		inventory[MAGMABLOCK]=1;
		inventory[DIAMONDPIC]=1;
		inventory[TNT]=100;
		inventory[FLINTANDSTEEL]=1;
		hotbar[0]=TNT;
		hotbar[1]=FLINTANDSTEEL;
		hotbar[2]=MAGMABLOCK;
		hotbar[3]=DIAMONDPIC;
		
		uint8_t y;
		spawn_nether_portal(15,y,15);
		*/
		while (alive){
			//dbg_printf("gfx_vbuffer=%p\n", (void*)gfx_vbuffer);
			
			frame+=1;
			if(realmcooldown>0)
				realmcooldown--;
			//dbg_printf("chunkx: %d, chunkz: %d\n",chunkx,chunkz);
			//dbg_printf("plx: %d, plz: %d\n",(int)plx,(int)plz);
			
			if((frame&15)==0)//every 2 ish seconds
			{
				if(playerhunger>17&&playerhp<20)
				{
					playerhp+=2;
					playerhunger-=randInt(0,2);
					updatehotbar=2;
					if(playerhp>20)
						playerhp=20;
				}
				
				uint32_t temps=clock()-start_time;
				temps+=offsettime;
				uint32_t elapsed_seconds=(unsigned int)(temps>>15);
				//dbg_printf("elapsed_seconds: %d, %lu,%ld\n",(int)elapsed_seconds,clock(),temps);
				elapsed_seconds=(elapsed_seconds * 17477) >> 19;//same thing as dividing by ~60. done to get minutes. 
				//speed up daylight cycle due to short attenetion spans. should be >>20, but i did >>19 to make 2x as fast
				// 273/(2**14) is around .016662497, close enough to .016666666666 (1/60)
				//will hicup at 6.61 hours of gameplay and overflow after a little over 68 hours.
				//by hicup i mean skip a cycle. it will think 66 is 67 i believe. But who plays on their calc for >hour???
				wtime=((int)elapsed_seconds)%20;//what time of day in world. 0-9 is day, 10-19 is night
				dbg_printf("s %lu g %lu w %d\n",start_time,*gstarttime,wtime);
				//dbg_printf("wtime: %d\n",wtime);

				if(realm==0)
				{
					change_bg(bg_colors[wtime]);//bg_color was macro, but i decided i wanted daylight cycle so is now variable
					
					if(biome==0&&mob_count<10)
					{
						if(!randInt(0,4))//so on average every 15 seconds (0,4 has 5 outcomes)
						{
							spawn_sheep();
						}
						if(!randInt(0,4))//so on average every 15 seconds (0,4 has 5 outcomes)
						{
							spawn_pig();
						}
					}
					if(!randInt(0,2))//every 5 ish seconds
					{
						if(wtime>9)
							spawn_zombie();
					}
				}
				else if (realm==1)
				{
					if(!randInt(0,6)&&mob_count<10)//so on average every 21 seconds. this is because spawn 10 on each new chunk load. is supposed to help people build.
					{
						spawn_piglin();
					}
				}
			}


			gfx_Wait();
			notfullfillscreen(bg_color,&gfx_vbuffer[0][0]);
			kb_Scan(); // Update the key status
			if(kb_IsDown(kb_KeyMath))
			{
				keyup(kb_KeyMath);//wait until release
				lspeed=!lspeed;
			}
			flag=1;
			if(superstop)
			{
				goto end;
			}
			if (kb_IsDown(kb_KeyRight)) {
				rotxz-=2<<lspeed;
				rotxz&=63;
				
				
			}
			else if (kb_IsDown(kb_KeyLeft)) {
					  
				rotxz+=2<<lspeed;
				if(rotxz>63)
					rotxz-=64;
			}
			//15 is bottom, 0 is middle, 49 is top
			else if (kb_IsDown(kb_KeyDown)){
				if(rotyz<15||rotyz>48) {
					  
				rotyz+=1<<lspeed;

				if(rotyz>15&&rotyz<49) rotyz=15;

				if(rotyz>63)
					rotyz-=64;
				}
			}
			else if (kb_IsDown(kb_KeyUp)){
				if (rotyz<16||rotyz>49) 
				{				
					if (rotyz<1)
						rotyz=64;				
					rotyz-=1<<lspeed;
				}
				if(rotyz==16)
					rotyz=15;
				if(rotyz<0)
					rotyz=0;
				if(rotyz==48)
					rotyz=49;
			}
			else
				flag=0;
			if (flag)
			{
				dirx=0;dirz=1;//for movement. movement vector if move.
				rot_point_2d(dirx,dirz,0,0,rotxz);
				if(dirx>1)
					dirx=1;
				if(dirx<-1)
					dirx=-1;
				if(dirz>1)
					dirz=1;
				if(dirz<-1)
					dirz=-1;
			}
			//dbg_printf("X: %d, Y: %d, Z: %d\n",(int)plx,(int)ply,(int)plz);
			auto ct=clock();
			if(ct-last_world_tick> CLOCKS_PER_SEC / 4)
			{
				if(realm==0)
				{
					manage_nocturnal_vmobs(vmob_pool, VMOB_POOL_SIZE,  wtime, 3);
				}
				update_all_mobs();
				call_update();
				//player damage stuff
				{					
					uint8_t x,y,z;
					x=(int)plx;
					y=(int)ply;
					z=(int)plz;
					uint8_t underblock=vis_map(x,y-2,z);//remeber: barrier at bottom so prob no wrap around
					switch(underblock)
					{
						case MAGMABLOCK:
							playerhp--;
							updatehotbar=2;
							break;
					}
					uint8_t feetblock=vis_map(x,y-1,z);//remeber: barrier at bottom so prob no wrap around
					uint8_t headblock=vis_map(x,y,z);//remeber: barrier at bottom so prob no wrap around
					if(headblock==FIRE||feetblock==FIRE)
					{
						playerhp--;
						updatehotbar=2;
					}
				}
				last_world_tick=ct;
			}
			
				
			if (kb_IsDown(kb_Key2nd)) 
			{
				int ndt=dt>>2;
				/*for(int i=0;i<(1<<MOVESHIFT);++i) */try_walk((dirx*ndt)>>(12-MOVESHIFT), (dirz*ndt)>>(12-MOVESHIFT));   // and the -dirx version for alpha
			}
			else if (kb_IsDown(kb_KeyAlpha)) {
				int ndt=-(dt>>2);
				/*for(int i=0;i<(1<<MOVESHIFT);++i) */try_walk((dirx*ndt)>>(12-MOVESHIFT), (dirz*ndt)>>(12-MOVESHIFT));   // and the -dirx version for alpha
			}
			
			if(ply>WY-1)
				ply=WY-1;
			if(ply<0)
				ply=0;
			if(ct-last_update> 4096)//happens 8 times a second
			{
				
				auto ltexturedata = (texturedata - ((reg_block_num+1) << 2));
				constexpr int tempid=LITTNT<<2;
				if((frame&3)==0)
				{
					ltexturedata[tempid+0]=tntxz;
					ltexturedata[tempid+1]=tnty;
					ltexturedata[tempid+2]=tntxz;
				}
				else
				{
					ltexturedata[tempid+0]=grey;
					ltexturedata[tempid+1]=grey;
					ltexturedata[tempid+2]=grey;
				}
				
				 if ((kb_Data[3] & kb_GraphVar)||is_in_crafting_table) {//xton
					while (kb_Data[3] & kb_GraphVar)
					{
						kb_Scan();//do nothing, wait until they release
					}
					int crafting_table[3][3][2]={};// all should be 0. syntax is x,y,(num,id)
					
					bool prevup=0;
					bool prevdown=0;
					bool prevright=0;
					bool prevleft=0;
					bool prevadd=0;
					bool prevminus=0;
					bool prevalpha=0;
					bool prev2nd=0;
					
					int cursor=0;
					uint8_t cursorcolor=231;//231 is yellow
					int cursorblock=0;
					int from_where=0;//where item is being moved from
					int cursornum=0;// for crafting table item splitting
					int where=0;//0 is inventory, 1 is hotbar, 2 is crafting table
					int scroll=0;
					build_visible_ids();
					while (!(kb_Data[3] & kb_GraphVar||kb_IsDown(kb_KeyClear)))// if press it again, break
					{
						
						gfx_SwapDraw();
						gfx_FillScreen(75);
						gfx_SetDrawBuffer();

						kb_Scan();
						if(kb_IsDown(kb_KeyMode))
						{
							view_recipies();
						}
						int c=0;
						if (where==1){
							
							gfx_SetColor(cursorcolor);
							gfx_FillRectangle(cursor*40,200,40,40);
							if(cursor>7)
							{
								cursor=0;
								where++;
							}
							if(cursor<0){
								where--;
								cursor=num_visible-1;
							}
						}
						for (int i=5; i<320;i+=40)// draws hotbar
						{						
							int temp=hotbar[c];
							draw_item(temp,i,205,1);
							/*
							if(temp<block_num)//if block
							{
								gfx_SetColor(block_colors_y[temp]);
								gfx_FillRectangle_NoClip(i,205,30,30);
								gfx_SetColor(0);
								gfx_SetTextXY(i+20, 220);
								gfx_PrintInt(inventory[temp],0);
							}
							else//if item
							{
								gfx_Sprite(item_imgs[temp-block_num], i, 205);
							}*/
							++c;
							
						}
						int x=2;
						int y=2;
						if((uint8_t)scroll%12)
							y=6;
						if(where==0)
						{
							if(cursor-scroll<36)
								scroll-=6;
							if(cursor-scroll>35)
								scroll+=6;
							if(scroll<0)
								scroll=0;
						}
						else
							scroll=0;
						dbg_printf("Scroll: %d, Cursor: %d\n",scroll,cursor);
						int count=0;
						for(int vi=scroll; vi<num_visible; ++vi){
							if(count>35) break;
							
							count++;
							int i=visible_ids[vi];
							int flag=1;
							for(int j=0;j<8;++j){
								if (i==hotbar[j])// if item in hotbar don't draw it
									flag=0;
							}
							for(int x=0;x<3;x++)
							{
								for(int y=0;y<3;y++)
								{
									if(i==crafting_table[x][y][0])
										flag=0;
								}
							}
							gfx_SetColor(0);
							if(where==0)
							{
								if(vi==cursor)
								{                 // was i==cursor+1
									gfx_SetColor(cursorcolor);
									gfx_FillRectangle(x-3,y-3,36,36);
									gfx_SetColor(0);
								}
								if(cursor>num_visible-1)       // was invenblocknum+item_num-1
								{
									where++;
									cursor=0;
								}
							if(cursor<0)
							{
								where=2;
								cursor=8;
								if(!is_in_crafting_table)
									cursor=4;
							}
							}
							if (inventory[i]==0)
								flag=0;// don't draw if nothing there
							
							gfx_FillRectangle_NoClip(x,y,30,30);
							if (flag){
								draw_item(i,x,y,1);
							}
							/*
							if(i<DOORBOTTOMOPEN||i>DOORBOTTOMCLOSED)
								x+=33;
							*/
							x+=33;
							if (x+30>200){
								x=2;
								y+=33;
							}
							
						}
					// now drawing crafting portion
					gfx_SetColor(175);
					gfx_FillRectangle_NoClip(200,0,120,120);//lime green part
					if (!is_in_crafting_table)
					{
						gfx_SetColor(140);
						gfx_FillRectangle_NoClip(275,0,45,75);
						gfx_FillRectangle_NoClip(200,75,120,45);
					}
					gfx_SetColor(64);
					
					gfx_FillRectangle_NoClip(200,35,120,10);// horizantal ones			
					gfx_FillRectangle_NoClip(200,75,120,10);
					
					gfx_FillRectangle_NoClip(235,0,10,120);//vertical ones.
					gfx_FillRectangle_NoClip(275,0,10,120);
					int size=3;
					if (!is_in_crafting_table)
					{
						size=2;
						draw_trans_rect_fake(275,0,45,75,74);
						draw_trans_rect_fake(200,75,120,45,74);
						if(where==2)//crafting table
						{
							if(cursor%3>1)//to far right
								cursor++;//move it down one
							if(cursor>5){//to far down
								where=0;
								cursor=0;
							}							
						}
					}
					if(where==2){
						if(cursor<0)
						{
							where--;
							cursor=7;
						}
						if(cursor>=9)
						{
							where=0;
							cursor=0;
						}
					}
					for(int x=0; x<size;++x){
						for(int y=0;y<size;++y)
						{
							if (crafting_table[x][y][1]<=0)
								crafting_table[x][y][0]=0;
							int temp=crafting_table[x][y][0];

							if(where==2){
								if(cursor==x+y*3)
								{
									gfx_SetColor(cursorcolor);
									gfx_FillRectangle_NoClip(205+x*40,5+y*40,30,30);
								}
								
							}
							if(temp)//!=0
							{
								int draw_x=205+x*40;
								int draw_y=5+y*40;
								draw_item(temp,draw_x,draw_y,0);
								gfx_SetColor(255);
								gfx_SetTextXY(draw_x+20,draw_y+20);
								gfx_PrintInt(crafting_table[x][y][1],0);
								if(cursor==x+y*3)
								{
									if(where==2&&crafting_table[x][y])//!=0
									{
										draw_trans_rect_fake_less_dark(205+x*40,5+y*40,30,30,cursorcolor);
									}
								}
							}
							
						}
					}
					//dbg_printf("cursor pos: %d, where: %d\n",cursor,where);
					if (kb_IsDown(kb_KeyEnter))
					{
						int num;
						int id=recipie_to_id(crafting_table,num);
						if (id!=-1)
						{
							for(int x=0; x<3;x++)
							{
								for(int y=0; y<3;y++)
								{
									if (crafting_table[x][y][0]!=0){
										decrease_item(crafting_table[x][y][0]);
										crafting_table[x][y][0]=0;
									}
								}
							}
							inventory[id]+=num;
							crafting_table[1][1][0]=id;
							crafting_table[1][1][1]=inventory[id];
							if(cursorblock==id)
							{
								cursornum=0;
								cursorblock=0;
							}
						}
						keyup(kb_KeyEnter);
					}
					
					if (kb_IsDown(kb_KeyDown))
					{
						if(prevdown){
							if (where==0)
							{
								//int pcursor=cursor;
								cursor+=6;
								/*
								if(pcursor<DOORBOTTOMCLOSED+1&&cursor>DOORTOPOPEN)
									cursor+=3;
								*/
							}
							if(where==2)
								cursor+=3;
							//msleep(200);
						}
						prevdown=0;
					}					
					else
						prevdown=1;
					

					if (kb_IsDown(kb_KeyUp))
					{
						if(prevup){
							if (where==0)
							{
								//int pcursor=cursor;
								cursor-=6;
								/*
								if(pcursor>DOORBOTTOMCLOSED&&cursor<DOORTOPOPEN+1)
									cursor-=3;
								*/
							}
							if(where==2)
								cursor-=3;
							//msleep(200);
						}
						prevup=0;
					}					
					else 
						prevup=1;
					
					if (kb_IsDown(kb_KeyAlpha))//split if on crafting table
					{
						if(where==2&&prevalpha){
							if(cursorcolor==135)//already is in alpha
							{
							goto key2ndforce;
							}
							cursorblock=crafting_table[cursor%3][cursor/3][0];
							cursornum=crafting_table[cursor%3][cursor/3][1]/2;
							crafting_table[cursor%3][cursor/3][1]-=cursornum;//splits in half
							cursorcolor=135;
							from_where=2;
						}
						prevalpha=0;
					}
					else
						prevalpha=1;
					if (kb_IsDown(kb_KeyRight))// increase hotbarblock
					{
						if(prevright){
						cursor++;
						//msleep(200);
						}
						prevright=0;
						if(where==0)
						{
							/*
							if(cursor>DOORTOPOPEN&&cursor<DOORBOTTOMCLOSED+1)
								cursor=DOORBOTTOMCLOSED+1;
							*/
						}
					}
					else
						prevright=1;
					
					if (kb_IsDown(kb_KeyLeft))
					{

						if(prevleft){
						cursor--;
						//msleep(200);
						}
						prevleft=0;
						if(where==0)
						{
							/*
							if(cursor<DOORBOTTOMCLOSED+1&&cursor>DOORTOPOPEN)
								cursor=DOORTOPOPEN;
							*/
						}
					}					
					else
						prevleft=1;
					
					if(kb_IsDown(kb_KeyAdd))
					{
						if(prevadd){
						where++;
						where%=3;
						//msleep(200);
						cursor=0;
						}
						prevadd=0;
					}
					else
						prevadd=1;
					
					if(kb_IsDown(kb_KeySub))
					{
						if(prevminus){
							cursor=0;
							where--;
							if(where<0)
								where=2;
							//msleep(200);
						}
						prevminus=0;
					}
					else
						prevminus=1;
					
					if (kb_IsDown(kb_Key2nd))
					{
						if(prev2nd){
						key2ndforce:
						//msleep(300);
						switch(where){
							case 0:
								//dbg_printf("num: %d, cursor: %d, cursorblock: %d\n",inventory[cursor],cursor,cursorblock);
								if (inventory[visible_ids[cursor]]>0&&cursorblock==0){
									cursorblock=visible_ids[cursor];// 0 is air
									cursornum=inventory[cursorblock];//sets item holding to one it is on
								}
								else if (cursorblock)//!=0
								{
									//inventory is not ordered so don't matter where put item
									if(from_where==2)// if on crafting table
									{
										for (int x=0; x<3;++x)
										{
											for(int y=0; y<3;++y)
											{
												if(crafting_table[x][y][0]==cursorblock)// if item is same as cursorblock
													crafting_table[x][y][0]=0;//clears item and *moves* it to inventory
											}
										}
									}
									cursorblock=0;
								}
								//dbg_printf("new cursorblock: %d\n",cursorblock);
								break;
								
							case 1:
								if (cursorblock==0){
									if(hotbar[cursor]){// !=0
										cursorblock=hotbar[cursor];
										hotbar[cursor]=0;
										cursornum=inventory[cursorblock];
									}
								}						
								else//cursorblock!=0
								{
									if(from_where==2)// if on crafting table
									{
										for (int x=0; x<3;++x){
											for(int y=0; y<3;++y){
												if(crafting_table[x][y][0]==cursorblock)// if item is same as cursorblock
													crafting_table[x][y][0]=0;//clears item so no duplicates are in hotbar
											}
										}
									}
									hotbar[cursor]=cursorblock;
									cursorblock=0;
									cursornum=0;
								}
								break;
							case 2://crafting table
								if (cursorblock)//!=0. if stuff in cursor
								{
									if(crafting_table[cursor%3][cursor/3][0]==cursorblock){//if put same item on stuff
										crafting_table[cursor%3][cursor/3][1]+=cursornum;
										cursorblock=0;
										cursornum=0;
									}
									else if (crafting_table[cursor%3][cursor/3][0])//if stuff in crafting table but not same stuff
									{
										int temp=crafting_table[cursor%3][cursor/3][0];
										crafting_table[cursor%3][cursor/3][0]=cursorblock;//swap block type
										cursorblock=temp;
										
										temp=crafting_table[cursor%3][cursor/3][1];//swap number of blocks
										crafting_table[cursor%3][cursor/3][1]=cursornum;
										cursornum=temp;//sorry no fancy xor swap :( this part can be slow though
									}
									else{
										crafting_table[cursor%3][cursor/3][0]=cursorblock;// if nothing there just put stuff in cursor there
										crafting_table[cursor%3][cursor/3][1]=cursornum;
										cursorblock=0;
										cursornum=0;
									}
									
								}
								else{
									cursorblock=crafting_table[cursor%3][cursor/3][0];
									cursornum=crafting_table[cursor%3][cursor/3][1];//inventory[cursorblock];
									crafting_table[cursor%3][cursor/3][0]=0;
								}break;
						}
						if (cursorblock){//!=0 if something in cursorblock
							cursorcolor=127;//cyan. light up cursor
							from_where=where;//where they got block from
						}
						else
						{
							cursorcolor=231;
						}
					}
					prev2nd=0;
					}
					else
						prev2nd=1;
					
				}
				gfx_FillScreen(bg_color);
				is_in_crafting_table=false;
				updatehotbar=2;
				}
				
				if (kb_IsDown(kb_KeyDel)) {
					dbg_printf("ply %d (int %d)\n", ply.data, (int)ply);
					last_update=clock();
					uint8_t* foo;
					uint8_t* block =cross_hair_pt(foo);
					
					if(block!=NULL)//going to do hit logic for combat
					{
						if(*block>MOBSTART-1)//is a mob
						{
							/*
							int indx=*block-(reg_block_num+1);
							if(block_is_usable[indx]!=NULL)// is usable. Should be though.
							{
								dbg_printf("using!");
								block_is_usable[indx](block);
								goto endplace2;
							}
							*/
							hurtmob_at(block);
							goto endplace2;
						}
					}
					int bv;
					int temp=1;
					int temp2=hotbar[hotbarblock];//wood,stone,gold,iron,diamond,netherite (optional)
					if (temp2>invenblocknum && temp2<invenblocknum+6){//if picaxe
						switch(temp2)
						{
							case WOODPIC:
							case GOLDPIC:
								temp=2;
								break;
							case STONEPIC:
								temp=3;
								break;
							case IRONPIC:
								temp=4;
								break;
							case DIAMONDPIC:
								temp=5;
								break;
						}
					}
					//dbg_printf("player hard: %d, block hard: %d, temp2: %d block: %p\n",temp,hardness[*block],temp2,block);
					if (block!=NULL&&*block!=BARRIER&&hardness[*block]<255){// if hit block and block is not barrier
						
						mining_timer-=dt;
						if(block!=mining_block)
							prevkeydel=true;
						bv=*block;//block value
						mining_block=block;
						if(prevkeydel)
							mining_timer=((hardness[bv])/temp)<<15;//sorry about using division!
						prevkeydel=0;
							if(mining_timer<=0){
								prevkeydel=1;
								mining_block=nullptr;
								int id=break_block(block);
								if(temp<hardness[bv])//only add to inventory if have strong enough picaxe
								{
									decrease_item(id);
									
								}
								else
								{
									*block=0;
								}
								
							}
					}
				}
					
				else{
					 mining_timer=0;
					 prevkeydel=1;
				}
				endplace2:
				
				if (kb_IsDown(kb_KeyAdd))// increase hotbarblock
				{
					last_update=clock();
					hotbarblock++;
					hotbarblock&=7;
					updatehotbar=2;
				}
				else if (kb_IsDown(kb_KeySub))
				{
					last_update=clock();
					hotbarblock--;
					if(hotbarblock<0)
						hotbarblock=7;
					updatehotbar=2;
				}
				//update_count++;
			}
			if(clock()-last_place>CLOCKS_PER_SEC/4)
			{
				if (kb_IsDown(kb_KeyStat))//place or use or use item
				{
					last_place=clock();
					int id=hotbar[hotbarblock];
					updatehotbar=2;
					if (id>invenblocknum)//item
					{
						if(use_item[id-invenblocknum-1]!=NULL)//if is usable (like cooked mutton)
						{
							use_item[id-invenblocknum-1]();
							keyup(kb_KeyStat);
							goto endplace;						
						}
					}
					uint8_t* block;
					uint8_t* temp=cross_hair_pt(block);
					
					if(temp==NULL)
						goto endplace;
					
					if(*temp>reg_block_num&&*temp<MOBSTART)//textured block (often are usable, like crafting table or door)
					{
						int indx=*temp-(reg_block_num+1);
						if(block_is_usable[indx]!=NULL)// is usable
						{
							dbg_printf("using!");
							block_is_usable[indx](temp);
							goto endplace;
						}
					}
					if (id<invenblocknum+1){// if not item

						
						if (id){
							
							
							//update_changes(id,block);
							uint8_t x, y,z;
							address2coords(block,x,y,z);
							bool samexz=(int)plx==x&&(int)plz==z;
							if(!((vis_map((int)plx,(int)ply+1,(int)plz)&&y==(int)ply-1&&samexz)||(samexz&&ply==y)))//if there is not (block above player's head and they are placing block at feet)
							{
								if(id==DOORTOPOPEN)
								{
									uint8_t* bottomblock=block-YJ;//down one in y
									if(*bottomblock)//is not zero (aka can't place door bcs block is there or trying to place door at base)
									{
										dbg_printf("base/no space detected!\n");
										block+=YJ;//up one in y, seeing if was placing at base
										bottomblock+=YJ;
										if(*block)//wasn't placing at base								
											goto endplace;
										dbg_printf("base detected!\n");
									}
									//if here can place door.
									//will only place bottom because down there will place top.
									//update_changes(DOORBOTTOMOPEN,bottomblock);
									*bottomblock=DOORBOTTOMOPEN;
								}
								*block=id;
								add_updates_fully(block);
								inventory[id]--;
								if(inventory[id]<=0)
									hotbar[hotbarblock]=0;
							}
							
						}
						
					}
					
				}
			}
			endplace:
			if (kb_IsDown(kb_KeyClear)) {
				goto end;
			}
			
			int temp2=vis_map((int)plx,(int)ply-1,(int)plz);
			if (!walk_thru_block(temp2))// if feet stuck in ground
			{
				if(!(temp2==DOORBOTTOMCLOSED||temp2==DOORBOTTOMOPEN))//demorganed it!
					ply+=1;
			}
			if (walk_thru_block(vis_map((int)plx,(int)ply-2,(int)plz))||grav<0){
				
				grav+=(grav_amount*dt)>>12;
				ply-=grav;
				temp2=vis_map((int)plx,(int)ply,(int)plz);
				if (!walk_thru_block(temp2))//if head stuck in wall
				{
					if(!(temp2==DOORTOPCLOSED||temp2==DOORTOPOPEN))//not in door
						ply-=1;
				}
			}
			else{
				if (kb_IsDown(kb_KeyMode))
				{
					grav=fln1pt5;
					if(randInt(0,40)==0)
					{
						playerhunger--;
						updatehotbar=2;
						if(playerhunger<0)
						{
							playerhunger=0;
						}

					}
				}
				else
				{
					grav=0;
					ply.data=(((ply.data)>>9)<<9)+256;
				}
			}
			//dbg_printf("frame!,%d,%d",rotxz,rotyz);
			if(kb_IsDown(kb_KeyApps))
			{
				disp_controls();
				gfx_FillScreen(bg_color);
				updatehotbar=2;
			}
			
			dbg_printf("raycast: ply %d (int %d)\n", ply.data, (int)ply);
			raycast_screen();
			
			std::clock_t t2 = std::clock();
			
			
			//gfx_SetTextXY(0,100);
			//gfx_PrintString("FPS: ");
			dt=(t2-t1);
			
			//uint8_t fps=(int)((float)32768/dt*10);
			t1 = std::clock();
			/*
			gfx_PrintInt(fps/10,1);
			gfx_PrintString(".");
			gfx_PrintInt(fps%10,1);
			//dbg_printf("time: %d\n",(t2-t1));
			*/
			gfx_SetColor(75);
			gfx_HorizLine_NoClip(0, 184, 320);//For some reason, there is a line here so I "patched" it ;)
			if(updatehotbar>0)
			{
				updatehotbar--;
				
				//hotbar
				gfx_FillRectangle_NoClip(0,184,320,56);
				gfx_SetColor(231);
				gfx_FillRectangle_NoClip(hotbarblock*40,200,40,40);

				int c=0;
				int temp;
				for (int i=5; i<320;i+=40)// draws hotbar
				{
					temp=hotbar[c];
					draw_item(temp,i,205,1);
					++c;
				}
				int x=0;
				int val=(playerhp>>1)*15;
				for(; x<val;x+=15)
				{
					gfx_Sprite_NoClip(heart,x,185);
				}
				int oldx=x;
				for(; x<150;x+=15)
				{
					gfx_Sprite_NoClip(emptyheart,x,185);
				}
				if (playerhp & 1)
				{
					gfx_Sprite_NoClip(halfheart,oldx,185);
				}

				int a=(10-(playerhunger>>1))*15;
				//dbg_printf("playerhunger: %d", playerhunger);
				for(int x=169+a; x<305;x+=15)
				{
					gfx_Sprite_NoClip(hunger,x,185);
				}
				
				for(int x=169; x<169+a;x+=15)
				{
					gfx_Sprite_NoClip(emptyhunger,x,185);
				}
			}
			gfx_SetColor(0);
			gfx_FillRectangle_NoClip(157,119,6,2);//crosshair
			gfx_FillRectangle_NoClip(159,117,2,6);
			
			//now drawing x,y,z coords and chunk x y coords
			gfx_SetTextBGColor(26);
			uint8_t c=0;
			if(wtime>12)
				c=255;
			gfx_SetTextFGColor(c);
			gfx_SetTextXY(0,0);
			gfx_PrintString("X: ");
			gfx_PrintInt((int)plx,1);
			gfx_PrintString(", Y: ");
			gfx_PrintInt((int)ply,1);
			gfx_PrintString(", Z: ");
			gfx_PrintInt((int)plz,1);

			gfx_SetTextXY(0,10);
			gfx_PrintString("chunkX: ");
			gfx_PrintInt((int)chunkx,1);
			gfx_SetTextXY(0,20);
			gfx_PrintString("chunkZ: ");
			gfx_PrintInt((int)chunkz,1);
			gfx_SetTextBGColor(255);
			gfx_SetTextFGColor(0);
			gfx_SwapDraw();
			
			if(playerhp<1)
			{
				alive=false;				
			}
		}
	}
	end:
	
	bool bflag=0;
	for(int i=0; i<8;++i)
	{
		if(wname[i]!=origwname[i])
		{
			bflag=1;
			break;
		}
	}
	save_world(wname);
	dbg_printf("pbflag wname: %s, origwname: %s, bflag: %d\n",wname,origwname,bflag);
	if(realm==1)
	{
		realm=0;
		tchunkx=chunkx; tchunkz=chunkz;
		chunkx=32; chunkz=32;
		flint tempply=ply;
		loadnewchunk();
		ply=tempply;
		
		save_world(origwname,1);
	}
	else if(bflag)//wname!=origwname
	{
		dbg_printf("bflag!!!\n");
		tchunkx=chunkx;//tchunkx and z are temp chunkx for saving in the save_world function
		tchunkz=chunkz;
		chunkx=32;
		chunkz=32;
		flint tempply=ply;//loadnewchunk resets ply to 30 or something.
		loadnewchunk();
		ply=tempply;
		save_world(origwname);
		
		
	}
	set_archive(origwname,true);
	archiveallchunks(origwname);
	gfx_End();
	if (world!=NULL)
		free(world);
	//usb_Cleanup();
    return 0;
}